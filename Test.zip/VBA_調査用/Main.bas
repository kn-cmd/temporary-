Attribute VB_Name = "Main"
Option Explicit

' マクロトリガー（ボタンや図形など）の情報を保持する構造体
Public Type MacroTriggerInfo
    SheetName As String
    ObjectName As String
    ObjectType As String
    OnActionRaw As String
    ModuleName As String
    FunctionName As String
End Type

'''
' メイン実行ルーチン
'''
Public Sub Main()
    ' 1. 情報の取得 (ThisWorkbookを対象とする)
    Dim triggers() As MacroTriggerInfo
    triggers = GetAllMacroTriggers(ThisWorkbook)
    
    ' 2. 情報の表示（新規ブックに出力）
    If (Not Not triggers) <> 0 Then
        DisplayMacroTriggers triggers
        MsgBox "マクロトリガーの調査が完了しました。新規作成されたブックを確認してください。", vbInformation
    Else
        MsgBox "マクロが設定されているオブジェクトは見つかりませんでした。", vbExclamation
    End If
End Sub

'''
' 指定されたワークブック内の全シートからマクロが設定されたオブジェクト情報を収集する
'''
Public Function GetAllMacroTriggers(wb As Workbook) As MacroTriggerInfo()
    Dim results() As MacroTriggerInfo
    Dim count As Long
    count = 0
    
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        Dim shp As Shape
        For Each shp In ws.Shapes
            ' OnAction プロパティを確認（マクロが割り当てられている場合のみ）
            Dim rawAction As String
            rawAction = ""
            On Error Resume Next
            rawAction = shp.OnAction
            On Error GoTo 0
            
            If rawAction <> "" Then
                ReDim Preserve results(count)
                
                results(count).SheetName = ws.Name
                results(count).ObjectName = shp.Name
                results(count).ObjectType = GetShapeTypeName(shp.Type)
                results(count).OnActionRaw = rawAction
                
                ' OnAction文字列を解析してモジュール名と関数名に分離を試みる
                ParseOnAction rawAction, results(count).ModuleName, results(count).FunctionName
                
                count = count + 1
            End If
        Next shp
    Next ws
    
    GetAllMacroTriggers = results
End Function

'''
' 取得した情報を新規ブックの先頭シートに出力する
'''
Public Sub DisplayMacroTriggers(triggers() As MacroTriggerInfo)
    ' 新規ブックを作成
    Dim wbNew As Workbook
    Set wbNew = Workbooks.Add
    
    Dim wsReport As Worksheet
    Set wsReport = wbNew.Worksheets(1)
    
    ' ヘッダーの作成
    With wsReport
        .Cells(1, 1).Value = "シート名"
        .Cells(1, 2).Value = "オブジェクト名"
        .Cells(1, 3).Value = "種類"
        .Cells(1, 4).Value = "モジュール名"
        .Cells(1, 5).Value = "関数名"
        .Cells(1, 6).Value = "OnAction(生データ)"
        
        ' スタイル設定
        With .Range("A1:F1")
            .Interior.Color = RGB(200, 200, 200)
            .Font.Bold = True
        End With
    End With
    
    ' データの書き込み
    Dim rowNum As Long
    rowNum = 2
    
    Dim i As Long
    For i = LBound(triggers) To UBound(triggers)
        wsReport.Cells(rowNum, 1).Value = triggers(i).SheetName
        wsReport.Cells(rowNum, 2).Value = triggers(i).ObjectName
        wsReport.Cells(rowNum, 3).Value = triggers(i).ObjectType
        wsReport.Cells(rowNum, 4).Value = triggers(i).ModuleName
        wsReport.Cells(rowNum, 5).Value = triggers(i).FunctionName
        wsReport.Cells(rowNum, 6).Value = triggers(i).OnActionRaw
        rowNum = rowNum + 1
    Next i
    
    ' 列幅の自動調整
    wsReport.Columns("A:F").AutoFit
End Sub

'''
' OnAction文字列を解析して、モジュール名と関数名に分割する
'''
Private Sub ParseOnAction(rawAction As String, ByRef outModule As String, ByRef outFunction As String)
    ' ブック名の部分 ('Book1.xlsm'!) を除去
    Dim cleanAction As String
    Dim lastBang As Long
    lastBang = InStrRev(rawAction, "!")
    
    If lastBang > 0 Then
        cleanAction = Mid(rawAction, lastBang + 1)
    Else
        cleanAction = rawAction
    End If
    
    ' モジュール名と関数名の分離 (Module1.MyMacro)
    Dim lastDot As Long
    lastDot = InStrRev(cleanAction, ".")
    
    If lastDot > 0 Then
        outModule = Left(cleanAction, lastDot - 1)
        outFunction = Mid(cleanAction, lastDot + 1)
    Else
        outModule = "(不明/標準)"
        outFunction = cleanAction
    End If
End Sub

'''
' ShapeType 列挙型を読みやすい文字列に変換する
'''
Private Function GetShapeTypeName(st As Long) As String
    Select Case st
        Case 1: GetShapeTypeName = "AutoShape"
        Case 4: GetShapeTypeName = "Canvas"
        Case 5: GetShapeTypeName = "Chart"
        Case 6: GetShapeTypeName = "Comment"
        Case 8: GetShapeTypeName = "FormControl"
        Case 12: GetShapeTypeName = "Group"
        Case 13: GetShapeTypeName = "Picture"
        Case 14: GetShapeTypeName = "OLEObject"
        Case 17: GetShapeTypeName = "TextBox"
        Case Else: GetShapeTypeName = "Other (" & st & ")"
    End Select
End Function
