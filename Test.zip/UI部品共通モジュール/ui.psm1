﻿# =============================================================================
# UI Module (ui.psm1)
# 汎用的なWindows Forms UI要素を生成する関数群
# =============================================================================

#region 定数 (モジュールスコープ)

$DEFAULT_PADDING = [System.Windows.Forms.Padding]::new(10, 10, 10, 10)
$DEFAULT_MARGIN = [System.Windows.Forms.Padding]::new(3, 3, 3, 3)
$BUTTON_MIN_SIZE = [System.Drawing.Size]::new(80, 25)
$TEXTBOX_DEFAULT_HEIGHT = 25
$SPACER_HEIGHT_SMALL = 3
$SPACER_WIDTH_SMALL = 3
$DEFAULT_FONT = [System.Drawing.Font]::new("Yu Gothic UI", 12)
$DATAGRIDVIEW_DEFAULT_SIZE = [System.Drawing.Size]::new(600, 300)


#endregion

#region 汎用UI生成関数

function New-UiForm {
<#
.SYNOPSIS
    標準的なWindows Formsフォームを生成します。
#>
    param (
        [string]$Title = "PowerShell GUI Application",
        [switch]$AutoSize,
        [System.Windows.Forms.AutoSizeMode]$AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink,
        [System.Windows.Forms.FormStartPosition]$StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    )
    $form = [System.Windows.Forms.Form]::new()
    $form.Text = $Title
    if ($AutoSize) {
        $form.AutoSize = $true
        $form.AutoSizeMode = $AutoSizeMode
    }
    $form.StartPosition = $StartPosition
    return $form
}

function New-UiFlowLayoutPanel {
<#
.SYNOPSIS
    標準的なFlowLayoutPanelを生成します。
#>
    param (
        [System.Windows.Forms.FlowDirection]$FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown,
        [switch]$AutoSize,
        [System.Windows.Forms.AutoSizeMode]$AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink,
        [System.Windows.Forms.Padding]$Padding = $DEFAULT_PADDING,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN,
        [System.Drawing.Size]$Size,
        [ScriptBlock]$Controls
    )
    $panel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $panel.FlowDirection = $FlowDirection
    if ($AutoSize) {
        $panel.AutoSize = $true
        $panel.AutoSizeMode = $AutoSizeMode
    }
    $panel.Padding = $Padding
    $panel.Margin = $Margin
    if ($Size) {
        $panel.Size = $Size
    }

    if ($Controls) {
        # スクリプトブロック内の処理を実行し、返されたコントロールをパネルに追加
        & $Controls | ForEach-Object {
            if ($_ -is [System.Windows.Forms.Control]) {
                $panel.Controls.Add($_)
            }
        }
    }

    return $panel
}

function New-UiButton {
<#
.SYNOPSIS
    標準的なボタンを生成します。
#>
    param (
        [string]$Text = "Button",
        [System.Drawing.Size]$Size,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $button = [System.Windows.Forms.Button]::new()
    $button.Text = $Text
    $button.Font = $DEFAULT_FONT
    $button.Margin = $Margin
    
    # 自動サイズ調整
    $button.AutoSize = $true
    $button.MinimumSize = $BUTTON_MIN_SIZE

    if ($Size) {
        $button.Size = $Size
    }
    
    return $button
}

function New-UiLabel {
<#
.SYNOPSIS
    標準的なラベルを生成します。
#>
    param (
        [string]$Text = "Label",
        [switch]$AutoSize,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $label = [System.Windows.Forms.Label]::new()
    $label.Text = $Text
    $label.Font = $DEFAULT_FONT
    if ($AutoSize) {
        $label.AutoSize = $true
    }
    $label.Margin = $Margin
    return $label
}

function New-UiTextBox {
<#
.SYNOPSIS
    標準的なテキストボックスを生成します。
#>
    param (
        [string]$Text = "",
        [switch]$ReadOnly,
        [switch]$Multiline,
        [bool]$TabStop = $false,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $textBox = [System.Windows.Forms.TextBox]::new()
    $textBox.Text = $Text
    $textBox.Font = $DEFAULT_FONT
    if ($ReadOnly) {
        $textBox.ReadOnly = $true
    }
    if ($Multiline) {
        $textBox.Multiline = $true
        $textBox.ScrollBars = 'Vertical'
        $textBox.WordWrap = $true
        $textBox.AcceptsReturn = $true
    }
    $textBox.Margin = $Margin
    $textBox.TabStop = $TabStop
    return $textBox
}
    
function New-UiPanel {
<#
.SYNOPSIS
    標準的なPanelを生成します。
#>
    param (
        [System.Windows.Forms.Padding]$Padding = $DEFAULT_PADDING,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN,
        [System.Drawing.Size]$Size
    )
    $panel = [System.Windows.Forms.Panel]::new()
    $panel.Padding = $Padding
    $panel.Margin = $Margin
    if ($Size) {
        $panel.Size = $Size
    }
    return $panel
}

function New-UiDataGridView {
<#
.SYNOPSIS
    標準的なDataGridViewを生成します。データと列定義を基に手動で列と行を追加します。
#>
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject[]]$Data,
        [Parameter(Mandatory=$true)]
        [string[]]$Columns,
        [System.Drawing.Size]$Size = $DATAGRIDVIEW_DEFAULT_SIZE,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )

    $dataGridView = [System.Windows.Forms.DataGridView]::new()
    $dataGridView.Size = $Size
    $dataGridView.Margin = $Margin
    $dataGridView.Font = $DEFAULT_FONT
    $dataGridView.AllowUserToAddRows = $false
    $dataGridView.AllowUserToDeleteRows = $false
    $dataGridView.ReadOnly = $true
    $dataGridView.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
    $dataGridView.MultiSelect = $false
    $dataGridView.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
    $dataGridView.AutoSizeRowsMode = [System.Windows.Forms.DataGridViewAutoSizeRowsMode]::AllCells
    $dataGridView.ColumnHeadersHeightSizeMode = [System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode]::AutoSize
    $dataGridView.DefaultCellStyle.WrapMode = [System.Windows.Forms.DataGridViewTriState]::True
    $dataGridView.RowHeadersVisible = $false
    $dataGridView.AllowUserToResizeRows = $false
    $dataGridView.AllowUserToResizeColumns = $false

    # -Columns引数を基に、DataGridViewの列を手動で生成
    foreach ($columnName in $Columns) {
        $dataGridView.Columns.Add($columnName, $columnName) | Out-Null
    }

    # 行を手動で追加
    foreach ($item in $Data) {
        # $Columnsの順序通りに値の配列を作成
        $rowValues = foreach ($colName in $Columns) {
            $item.$colName
        }
        # 行を追加
        $dataGridView.Rows.Add($rowValues) | Out-Null
    }

    # ソートを無効化
    foreach ($column in $dataGridView.Columns) {
        $column.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
    }

    return $dataGridView
}
    
function New-UiVerticalSpacer {
<#
.SYNOPSIS
    指定された高さの垂直スペーサーを生成します。省略時はデフォルトの高さを使用します。
#>
    param (
        [int]$Height = $SPACER_HEIGHT_SMALL
    )
    $spacer = [System.Windows.Forms.Panel]::new()
    $spacer.Size = [System.Drawing.Size]::new(1, $Height) # 幅は最小限、高さは指定
    $spacer.Margin = [System.Windows.Forms.Padding]::new(0, 0, 0, 0) # マージンなし
    return $spacer
}

function New-UiHorizontalSpacer {
<#
.SYNOPSIS
    指定された幅の水平スペーサーを生成します。省略時はデフォルトの幅を使用します。
#>
    param (
        [int]$Width = $SPACER_WIDTH_SMALL
    )
    $spacer = [System.Windows.Forms.Panel]::new()
    $spacer.Size = [System.Drawing.Size]::new($Width, 1) # 幅は指定、高さは最小限
    $spacer.Margin = [System.Windows.Forms.Padding]::new(0, 0, 0, 0) # マージンなし
    return $spacer
}

#endregion

# 公開する関数をエクスポート
Export-ModuleMember -Function New-UiForm, New-UiFlowLayoutPanel, New-UiButton, New-UiLabel, New-UiTextBox, New-UiPanel, New-UiDataGridView, New-UiVerticalSpacer, New-UiHorizontalSpacer
