﻿
# =============================================================================
# MainForm Module
# =============================================================================

# 外部モジュールとクラス定義をインポート
Import-Module ".\ui.psm1" -Force
. "$PSScriptRoot\EventHandlers.ps1"

#region 定数 (モジュールスコープ)
$MAIN_FORM_TITLE = "社員を選択"
#endregion

#region 公開関数
function New-MainForm {
<#
.SYNOPSIS
    メインフォームを生成し、設定済みのフォームオブジェクトを返します。
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject[]]$Data,

        [Parameter(Mandatory=$true)]
        [string[]]$Columns
    )

    # 1. ロジッククラスのインスタンス化
    $logic = [EventHandlers]::new()

    # 2. メインフォームの作成
    $form = New-UiForm -Title $MAIN_FORM_TITLE -AutoSize
    $logic.Form = $form

    # 3. UIレイアウトの定義とコントロールの生成
    $rootPanel = New-UiFlowLayoutPanel -AutoSize -Padding 0 -Controls {
        # DataGridView
        New-UiFlowLayoutPanel -AutoSize -Controls {
            $logic.DataGridView = New-UiDataGridView -Data $Data -Columns $Columns
            $logic.DataGridView
        }

        # ボタン用パネル (削除/ダウンロード)
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            $deleteButton = New-UiButton -Text "削除"
            $deleteButton.Add_Click({ 
                param($sender, $e)
                $sender.FindForm().Tag.OnDeleteButtonClick()
            })
            $deleteButton

            $downloadButton = New-UiButton -Text "ダウンロード"
            $downloadButton.Add_Click({ 
                param($sender, $e)
                $sender.FindForm().Tag.OnDownloadButtonClick()
            })
            $downloadButton

        }
    
        # 入力行パネル
        New-UiFlowLayoutPanel -AutoSize -FlowDirection TopDown -Controls {
            New-UiVerticalSpacer
            New-UiLabel -Text "ファイル選択" -AutoSize
            $logic.TextBox = New-UiTextBox -ReadOnly -TabStop $false
            $logic.TextBox
        }
    
        # 追加ボタン行パネル (ファイル選択/アップロード)
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            $selectFileButton = New-UiButton -Text "ファイル選択"
            $selectFileButton.Add_Click({ 
                param($sender, $e)
                $sender.FindForm().Tag.OnSelectFileButtonClick()
            })
            $selectFileButton

            
            $uploadButton = New-UiButton -Text "アップロード"
            $uploadButton.Add_Click({ 
                param($sender, $e)
                $sender.FindForm().Tag.OnUploadButtonClick()
            })
            $uploadButton
        }
    }

    # 4. コントロール間の調整
    $logic.TextBox.Width = $logic.DataGridView.Size.Width

    # 5. フォームにルートパネルを追加
    $form.Controls.Add($rootPanel) | Out-Null

    # 4. 完成した「頭脳」をフォームのTagに格納
    $form.Tag = $logic

    return $form


    
    
}
#endregion

# 公開する関数をエクスポート
Export-ModuleMember -Function New-MainForm

