﻿class EventHandlers {
    # --- UIコントロール/状態 ---
    [System.Windows.Forms.Form] $Form
    [System.Windows.Forms.DataGridView] $DataGridView
    [System.Windows.Forms.TextBox] $TextBox

    # --- イベントハンドラメソッド ---
    
    # 削除ボタン押下処理
    OnDeleteButtonClick() {
        Write-Host "削除ボタンがクリックされました。"
    }

    # ダウンロードボタン押下処理
    OnDownloadButtonClick() {
        Write-Host "ダウンロードボタンがクリックされました。"
    }

    # ファイル選択ボタン押下処理
    OnSelectFileButtonClick() {
        $openFileDialog = [System.Windows.Forms.OpenFileDialog]::new()
        try {
            $openFileDialog.Title = "ファイルを選択してください"
            if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
                $this.TextBox.Text = $openFileDialog.FileName
            }
        }
        finally {
            $openFileDialog.Dispose()
        }
    }

    # アップロードボタン押下処理
    OnUploadButtonClick() {
        $filePath = $this.TextBox.Text
        if (-not [string]::IsNullOrEmpty($filePath)) {
            [System.Console]::WriteLine("'{0}' をアップロードします。" -f $filePath)
        } else {
            [System.Console]::WriteLine("ファイルが選択されていません。")
        }
    }
}
