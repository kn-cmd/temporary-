﻿<#
.SYNOPSIS
    UI関連の共通関数の動作を対話形式でテストします。
#>

# --- 1. 準備 ---

# 関数ライブラリのパスを指定 (このスクリプトと同じフォルダにある前提)
$modulePath = Join-Path $PSScriptRoot "CommonDialogs.psm1"

# ライブラリファイルの存在確認と読み込み
if (-not (Test-Path $modulePath)) {
    # 読み込みに失敗した場合は、標準のメッセージボックスでエラーを通知して終了
    Add-Type -AssemblyName System.Windows.Forms
    [System.Windows.Forms.MessageBox]::Show("モジュール '$modulePath' が見つかりません。", "起動エラー", "OK", "Error")
    exit
}
Import-Module $modulePath -Force


# --- 2. テストの実行 ---

# テスト開始の案内
Clear-Host
Write-Host "--- UI関数の動作テストを開始します ---" -ForegroundColor Green
Write-Host "表示されるダイアログの指示に従って操作してください。"

# --- Test Case 1: Show-UIMessage (通知) のテスト ---
Write-Host "`n--- 1. Show-UIMessage (通知) のテスト ---" -ForegroundColor Cyan

Show-UIMessage -Message "これは「情報 (Info)」アイコンのテストです。" -Title "テスト 1-1" -IconType "Info"
Write-Host "  [OK] 「情報」アイコンが表示されました。"

Show-UIMessage -Message "これは「警告 (Warn)」アイコンのテストです。" -Title "テスト 1-2" -IconType "Warn"
Write-Host "  [OK] 「警告」アイコンが表示されました。"

Show-UIMessage -Message "これは「エラー (Error)」アイコンのテストです。" -Title "テスト 1-3" -IconType "Error"
Write-Host "  [OK] 「エラー」アイコンが表示されました。"


# --- Test Case 2: Confirm-UIAction (確認) のテスト ---
Write-Host "`n--- 2. Confirm-UIAction (確認) のテスト ---" -ForegroundColor Cyan

# Test 2-1: 情報アイコンで「OK」を選択
Write-Host "`n  テスト 2-1: 「情報」アイコンで [OK] を押してください..."
$result1 = Confirm-UIAction -Message "これは「情報 (Info)」アイコンのテストです。`n[OK] を押してください。" -Title "テスト 2-1" -IconType "Info"
Write-Host "  -> 結果: $result1 (`$true` が返されれば成功)"

# Test 2-2: 警告アイコンで「キャンセル」を選択
Write-Host "`n  テスト 2-2: 「警告」アイコンで [キャンセル] を押してください..."
$result2 = Confirm-UIAction -Message "これは「警告 (Warn)」アイコンのテストです。`n[キャンセル] を押してください。" -Title "テスト 2-2" -IconType "Warn"
Write-Host "  -> 結果: $result2 (`$false` が返されれば成功)"

# Test 2-3: エラーアイコンで任意に選択
Write-Host "`n  テスト 2-3: 「エラー」アイコンで好きなボタンを押してください..."
$result3 = Confirm-UIAction -Message "これは「エラー (Error)」アイコンのテストです。`nどちらかのボタンを押してください。" -Title "テスト 2-3" -IconType "Error"
Write-Host "  -> あなたの選択結果: $result3"


# --- Test Case 3: ファイルダイアログのテスト ---
Write-Host "`n--- 3. ファイルダイアログ関数のテスト ---" -ForegroundColor Cyan

# Test 3-1: ファイルを開く
Write-Host "`n  テスト 3-1: ファイル選択ダイアログでいずれかのファイルを選択してください..."
$openPath = Show-OpenFile -Title "テスト 3-1: ファイルを開く" -Filter "PowerShellスクリプト (*.ps1)|*.ps1|すべてのファイル (*.*)|*.*"
if ($openPath) {
    Write-Host "  -> 選択されたファイル: $openPath"
} else {
    Write-Host "  -> ダイアログがキャンセルされました。"
}

# Test 3-2: ファイルを保存
Write-Host "`n  テスト 3-2: ファイル保存ダイアログで「test.txt」という名前で保存してください..."
$savePath = Show-SaveFile -Title "テスト 3-2: 名前を付けて保存" -Filter "テキストファイル (*.txt)|*.txt|すべてのファイル (*.*)|*.*"
if ($savePath) {
    Write-Host "  -> 指定された保存パス: $savePath"
} else {
    Write-Host "  -> ダイアログがキャンセルされました。"
}

# --- Test Case 4: フォルダ選択ダイアログのテスト ---
Write-Host "`n--- 4. フォルダ選択ダイアログのテスト ---" -ForegroundColor Cyan
Write-Host "`n  テスト 4-1: フォルダ選択ダイアログでいずれかのフォルダを選択してください..."
$folderPath = Show-FolderBrowserDialog -Description "テスト 4-1: フォルダを選択"
if ($folderPath) {
    Write-Host "  -> 選択されたフォルダ: $folderPath"
} else {
    Write-Host "  -> ダイアログがキャンセルされました。"
}


# --- 5. 終了 ---
Write-Host "`n--- すべてのテストが完了しました ---" -ForegroundColor Green
Read-Host "Enter キーを押してプログラムを終了します。"