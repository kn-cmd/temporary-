﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ====================================================================
# 1. 定数・設定値の定義 (スクリプトスコープ)
#    - GUIの挙動や外観に関するすべての設定値はここに集中
# ====================================================================

$APP_TITLE = "URL選択ツール" 

$URL_MAP = @{
    'url_1' = 'https://www.google.com'
    'url_2' = 'https://www.yahoo.co.jp'
    'url_3' = 'https://www.bing.com'
}

# --- レイアウト関連の定数 ---
$MIN_BUTTON_WIDTH = 80 # 最小ボタン幅

# --- 余白関連の定数 (Padding/Margin) ---
$MAIN_PANEL_PADDING = [System.Windows.Forms.Padding]::new(10, 10, 10, 10)
$LABEL_BOTTOM_MARGIN = 10
$RADIO_BUTTON_INDENT = 20
$RADIO_BUTTON_GAP = 5
$BUTTON_TOP_MARGIN = 20
$BUTTON_GAP = 10


# ====================================================================
# 2. GUIコンポーネント作成関数
# ====================================================================

<#
.SYNOPSIS
メインとなるWindowsフォームを作成し、自動サイズ調整を設定します。
#>
function New-MainForm {
    $form = New-Object System.Windows.Forms.Form
    $form.Text = $APP_TITLE
    $form.AutoSize = $true 
    $form.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    $form.FormBorderStyle = [System.Windows.Forms.FormBorderStyle]::FixedSingle
    $form.MaximizeBox = $false
    return $form
}

<#
.SYNOPSIS
フォームの全領域を占める縦方向の FlowLayoutPanel を作成します。
#>
function New-MainPanel {
    $panel = New-Object System.Windows.Forms.FlowLayoutPanel
    $panel.Dock = [System.Windows.Forms.DockStyle]::Fill
    $panel.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
    $panel.AutoSize = $true 
    $panel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $panel.Padding = $MAIN_PANEL_PADDING
    return $panel
}

<#
.SYNOPSIS
指定されたテキストでラベルを作成し、余白を設定します。
#>
function New-CustomLabel ($Text) {
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Text
    $label.AutoSize = $true
    $label.Margin = [System.Windows.Forms.Padding]::new(0, 0, 0, $LABEL_BOTTOM_MARGIN)
    return $label
}

<#
.SYNOPSIS
$URL_MAPに基づいてラジオボタンの配列を作成し、最初の要素を選択状態にします。
#>
function New-RadioButtons {
    $RBs = @()
    $URL_MAP.Keys | ForEach-Object -Begin { $i = 0 } -Process {
        $key = $_
        $rb = New-Object System.Windows.Forms.RadioButton
        $rb.Text = $key
        $rb.Name = $key
        $rb.AutoSize = $true 
        $rb.Margin = [System.Windows.Forms.Padding]::new($RADIO_BUTTON_INDENT, 0, 0, $RADIO_BUTTON_GAP) 
        
        if ($i -eq 0) { $rb.Checked = $true }
        
        $RBs += $rb
        $i++
    } -End { return $RBs }
}

<#
.SYNOPSIS
指定されたテキストとアクションでボタンを作成し、最小幅を設定します。
#>
function New-CustomButton {
    param(
        [string]$Text,
        $Action,
        [int]$MarginRight = 0
    )
    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = $Text
    
    $btn.MinimumSize = [System.Drawing.Size]::new($MIN_BUTTON_WIDTH, 30)
    $btn.AutoSize = $true
    $btn.UseVisualStyleBackColor = $true
    
    $btn.Add_Click($Action) | Out-Null
    if ($MarginRight -gt 0) {
        $btn.Margin = [System.Windows.Forms.Padding]::new(0, 0, $MarginRight, 0)
    }
    return $btn
}


# ====================================================================
# 3. メインロジック
# ====================================================================

<#
.SYNOPSIS
GUIウィンドウを構築し、表示します。
#>
function Show-MainForm {
    # --- 1. フォームとメインパネルの作成 ---
    $form = New-MainForm
    $mainPanel = New-MainPanel
    $form.Controls.Add($mainPanel) | Out-Null

    # --- 2. ラベルの追加 ---
    $mainPanel.Controls.Add((New-CustomLabel -Text "選択してください")) | Out-Null

    # --- 3. ラジオボタンの追加 ---
    $radioButtons = New-RadioButtons
    $radioButtons | ForEach-Object { 
        $mainPanel.Controls.Add($_) | Out-Null 
    }

    # --- 4. ボタンペアパネルの作成 ---
    $buttonPanel = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttonPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
    $buttonPanel.AutoSize = $true
    $buttonPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $buttonPanel.Margin = [System.Windows.Forms.Padding]::new(0, $BUTTON_TOP_MARGIN, 0, 0)
    $mainPanel.Controls.Add($buttonPanel) | Out-Null

    # --- 5. 閉じるボタンの追加 ---
    $CloseAction = { $form.Close() }
    $CloseButton = New-CustomButton -Text "閉じる" -Action $CloseAction -MarginRight $BUTTON_GAP
    $buttonPanel.Controls.Add($CloseButton) | Out-Null

    # --- 6. 実行ボタンの追加 ---
    $ExecuteAction = {
        $selectedButton = $radioButtons | Where-Object { $_.Checked }
        
        if ($selectedButton) {
            $key = $selectedButton.Name
            $url = $URL_MAP[$key]
            
            try {
                # Internet Explorer (IE) を使用してURLを開く
                Start-Process iexplore.exe -ArgumentList $url -ErrorAction Stop
            }
            catch {
                # IEが利用不可の場合は既定のブラウザで開く
                [System.Windows.Forms.MessageBox]::Show("IE起動に失敗。既定のブラウザで開きます。", "エラー", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
                Start-Process $url
            }
        }
    }
    $ExecuteButton = New-CustomButton -Text "実行" -Action $ExecuteAction
    $buttonPanel.Controls.Add($ExecuteButton) | Out-Null
    
    # --- 7. フォームの表示 ---
    $form.ShowDialog() | Out-Null
}

# --- スクリプト実行開始 ---
Show-MainForm