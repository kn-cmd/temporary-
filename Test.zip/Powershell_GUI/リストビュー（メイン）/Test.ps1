﻿# =============================================================================
# PowerShell GUI - 社員選択デモ
#
# 規約(readme.md)に準拠したリファクタリング版
# =============================================================================

# -----------------------------------------------------------------------------
# スクリプト全体の実行設定
# -----------------------------------------------------------------------------
# .NETコンソール自体の出力エンコーディングをUTF-8に設定
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# PowerShellの出力エンコーディングをUTF-8に設定
$OutputEncoding = [System.Text.Encoding]::UTF8

# Windows Forms アセンブリをロード
Add-Type -AssemblyName System.Windows.Forms


#region 定数
# =============================================================================
# 定数定義ブロック
# =============================================================================

# --- フォームとレイアウト関連 --- 
$MAIN_FORM_TITLE = "社員を選択"
$DEFAULT_PADDING = [System.Windows.Forms.Padding]::new(10, 10, 10, 10)
$DEFAULT_MARGIN = [System.Windows.Forms.Padding]::new(3, 3, 3, 3)

# --- コントロール関連 --- 
$LISTVIEW_SIZE = [System.Drawing.Size]::new(540, 200) # リストビューのサイズ (幅, 高さ)
$BUTTON_PANEL_HEIGHT = 40 # ボタンパネルの高さ

$DEFAULT_BUTTON_SIZE = [System.Drawing.Size]::new(75, 23) # 汎用ボタンのサイズ (幅, 高さ)


$FILE_LABEL_TEXT = "ファイル選択" # ファイル選択ラベルのテキスト
$TEXTBOX_SIZE = [System.Drawing.Size]::new(534, 23) # テキストボックスのサイズ (幅, 高さ)
$SELECT_FILE_BUTTON_TEXT = "ファイル選択" # ファイル選択ボタンのテキスト
$UPLOAD_BUTTON_TEXT = "アップロード" # アップロードボタンのテキスト

#endregion


#region 関数
# =============================================================================
# 関数定義ブロック
# =============================================================================

function New-ItemListView {
<#
.SYNOPSIS
    項目一覧を表示するListViewを作成します。
#>
    param (
        [System.Windows.Forms.ListViewItem[]]$Items
    )

    $listView = [System.Windows.Forms.ListView]::new()
    $listView.View = [System.Windows.Forms.View]::Details
    $listView.FullRowSelect = $true
    $listView.GridLines = $true
    $listView.HideSelection = $false
    $listView.Size = $LISTVIEW_SIZE
    $listView.Margin = $DEFAULT_MARGIN

    # 列の定義（※ここはデータ構造に依存するため、具体的な記述を許容）
    $listView.Columns.Add("項目名", 200) | Out-Null
    $listView.Columns.Add("状態", 80) | Out-Null
    $listView.Columns.Add("入力者", 120) | Out-Null
    # 幅に-2を指定すると、残りの表示領域をすべて使用するよう自動調整される
    $listView.Columns.Add("承認者", -2) | Out-Null

    # データ項目の追加
    if ($null -ne $Items) {
        $listView.Items.AddRange($Items)
    }

    return $listView
}

function New-SelectorDialog {
<#
.SYNOPSIS
    データを受け取り、汎用的な選択用GUIフォームオブジェクトを返します。
#>
    param (
        [array]$Data
    )

    # 1. データを行アイテムに変換（※ここはデータ構造に依存）
    $listItems = foreach ($entry in $Data) {
        $item = [System.Windows.Forms.ListViewItem]::new($entry.項目名)
        $item.SubItems.Add($entry.状態) | Out-Null
        $item.SubItems.Add($entry.入力者) | Out-Null
        $item.SubItems.Add($entry.承認者) | Out-Null
        $item.Tag = $entry
        $item
    }

    # 2. GUIコントロールの作成と設定
    
    # メインフォーム
    $form = [System.Windows.Forms.Form]::new()
    $form.Text = $MAIN_FORM_TITLE
    $form.AutoSize = $true
    $form.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen

    # ルートパネル
    $rootPanel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $rootPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
    $rootPanel.AutoSize = $true
    $rootPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $rootPanel.Padding = $DEFAULT_PADDING

    # ListView
    $listView = New-ItemListView -Items $listItems

    # ボタン用パネル (OK/Cancel)
    $buttonPanel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $buttonPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
    $buttonPanel.Width = $LISTVIEW_SIZE.Width
    $buttonPanel.Height = $BUTTON_PANEL_HEIGHT
    $buttonPanel.Margin = $DEFAULT_MARGIN

    # 削除ボタン
    $deleteButton = New-Object System.Windows.Forms.Button
    $deleteButton.Text = "削除"
    $deleteButton.Size = $DEFAULT_BUTTON_SIZE
    $deleteButton.Margin = $DEFAULT_MARGIN
    $deleteButton.Add_Click({
        $form = $this.FindForm()
        if ($null -eq $form) { return } # 念のため
        Write-Host "削除ボタンがクリックされました。"
        $form.ListView.Focus()
    })

    # ダウンロードボタン
    $downloadButton = New-Object System.Windows.Forms.Button
    $downloadButton.Text = "ダウンロード"
    $downloadButton.Size = $DEFAULT_BUTTON_SIZE
    $downloadButton.Margin = $DEFAULT_MARGIN
    $downloadButton.Add_Click({
        $form = $this.FindForm()
        if ($null -eq $form) { return } # 念のため
        Write-Host "ダウンロードボタンがクリックされました。"
        $form.ListView.Focus()
    })
    
    # --- 追加コントロール ---
    
    # 入力行パネル
    $inputRowPanel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $inputRowPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
    $inputRowPanel.AutoSize = $true
    $inputRowPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $inputRowPanel.Width = $LISTVIEW_SIZE.Width
    $inputRowPanel.Margin = $DEFAULT_MARGIN

    # ラベル「ファイル選択」
    $fileLabel = [System.Windows.Forms.Label]::new()
    $fileLabel.Text = $FILE_LABEL_TEXT
    $fileLabel.AutoSize = $true
    $fileLabel.Margin = [System.Windows.Forms.Padding]::new(3, 6, 3, 3)

    # テキスト入力欄
    $textBox = [System.Windows.Forms.TextBox]::new()
    $textBox.Size = $TEXTBOX_SIZE
    $textBox.Margin = $DEFAULT_MARGIN
    $textBox.ReadOnly = $true
    $textBox.TabStop = $false

    # 追加ボタン行パネル
    $newButtonsPanel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $newButtonsPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::LeftToRight
    $newButtonsPanel.AutoSize = $true
    $newButtonsPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $newButtonsPanel.Width = $LISTVIEW_SIZE.Width
    $newButtonsPanel.Margin = $DEFAULT_MARGIN

    # ファイル選択ボタン
    $selectFileButton = [System.Windows.Forms.Button]::new()
    $selectFileButton.Text = $SELECT_FILE_BUTTON_TEXT
    $selectFileButton.Size = $DEFAULT_BUTTON_SIZE # 汎用ボタンサイズを使用
    $selectFileButton.Margin = $DEFAULT_MARGIN
    $selectFileButton.add_Click({
        # イベントの sender ($this) から親フォームを探す
        $form = $this.FindForm()
        if ($null -eq $form) { return } # 念のため

        $openFileDialog = [System.Windows.Forms.OpenFileDialog]::new()
        $openFileDialog.Title = "ファイルを選択してください"
        if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            # フォームのカスタムプロパティ経由でTextBoxにアクセスする
            $form.PathTextBox.Text = $openFileDialog.FileName
        }
        $openFileDialog.Dispose()
        $form.ListView.Focus()
    })

    # アップロードボタン
    $uploadButton = [System.Windows.Forms.Button]::new()
    $uploadButton.Text = $UPLOAD_BUTTON_TEXT
    $uploadButton.Size = $DEFAULT_BUTTON_SIZE # 汎用ボタンサイズを使用
    $uploadButton.Margin = $DEFAULT_MARGIN
    $uploadButton.add_Click({
        $form = $this.FindForm()
        if ($null -eq $form) { return }

        $filePath = $form.PathTextBox.Text
        if (-not [string]::IsNullOrEmpty($filePath)) {
            [System.Console]::WriteLine("'{0}' をアップロードします。" -f $filePath)
        } else {
            [System.Console]::WriteLine("ファイルが選択されていません。")
        }
        $form.ListView.Focus()
    })

    # 3. レイアウトの構築
    # OK/Cancelボタンをパネルに追加
    $buttonPanel.Controls.Add($deleteButton) | Out-Null
    $buttonPanel.Controls.Add($downloadButton) | Out-Null

    # 入力行をパネルに追加
    $inputRowPanel.Controls.Add($fileLabel) | Out-Null
    $inputRowPanel.Controls.Add($textBox) | Out-Null

    # 追加ボタンをパネルに追加
    $newButtonsPanel.Controls.Add($selectFileButton) | Out-Null
    $newButtonsPanel.Controls.Add($uploadButton) | Out-Null

    # 全てのパネルをルートパネルに追加
    $rootPanel.Controls.Add($listView) | Out-Null
    $rootPanel.Controls.Add($buttonPanel) | Out-Null
    $rootPanel.Controls.Add($inputRowPanel) | Out-Null
    $rootPanel.Controls.Add($newButtonsPanel) | Out-Null
    
    $form.Controls.Add($rootPanel) | Out-Null
    $form.AcceptButton = $deleteButton
    $form.CancelButton = $null

    # 4. 呼び出し元がコントロールにアクセスできるよう、カスタムプロパティとして追加
    $form | Add-Member -MemberType NoteProperty -Name 'ListView' -Value $listView
    $form | Add-Member -MemberType NoteProperty -Name 'PathTextBox' -Value $textBox

    # 5. 組み立てたフォームオブジェクトを返す
    return $form
}

#endregion


#region メイン処理
# =============================================================================
# メイン処理ブロック
# =============================================================================

# 1. 表示するサンプルデータを作成
$sampleData = @(
    [PSCustomObject]@{ "項目名" = "経費申請-001"; "状態" = "承認済"; "入力者" = "山田 太郎"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "休暇申請-002"; "状態" = "申請中"; "入力者" = "鈴木 一郎"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "備品購入依頼-003"; "状態" = "差戻"; "入力者" = "田中 美咲"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "経費申請-004"; "状態" = "承認済"; "入力者" = "山田 太郎"; "承認者" = "佐藤 部長" }
)

# 2. GUIフォームオブジェクトを作成
$dialog = New-SelectorDialog -Data $sampleData

# 3. フォームを表示し、ユーザーの操作を待つ
$dialogResult = $dialog.ShowDialog()



#endregion