﻿# =============================================================================
# PowerShell GUI - 社員選択デモ
#
# 規約(readme.md)に準拠したリファクタリング版
# =============================================================================

# -----------------------------------------------------------------------------
# スクリプト全体の実行設定
# -----------------------------------------------------------------------------
# .NETコンソール自体の出力エンコーディングをUTF-8に設定
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# PowerShellの出力エンコーディングをUTF-8に設定
$OutputEncoding = [System.Text.Encoding]::UTF8

# Windows Forms アセンブリをロード
Add-Type -AssemblyName System.Windows.Forms


#region 定数
# =============================================================================
# 定数定義ブロック
# =============================================================================

# --- フォームとレイアウト関連 --- 
$MAIN_FORM_TITLE = "社員を選択"
$DEFAULT_PADDING = [System.Windows.Forms.Padding]::new(10, 10, 10, 10)
$DEFAULT_MARGIN = [System.Windows.Forms.Padding]::new(3, 3, 3, 3)

# --- コントロール関連 --- 
$LISTVIEW_SIZE = [System.Drawing.Size]::new(360, 200)
$BUTTON_PANEL_HEIGHT = 40
$OK_BUTTON_TEXT = "OK"
$OK_BUTTON_SIZE = [System.Drawing.Size]::new(75, 23)

#endregion


#region 関数
# =============================================================================
# 関数定義ブロック
# =============================================================================

function New-ItemListView {
<#
.SYNOPSIS
    項目一覧を表示するListViewを作成します。
#>
    param (
        [System.Windows.Forms.ListViewItem[]]$Items
    )

    $listView = [System.Windows.Forms.ListView]::new()
    $listView.View = [System.Windows.Forms.View]::Details
    $listView.FullRowSelect = $true
    $listView.GridLines = $true
    $listView.Size = $LISTVIEW_SIZE
    $listView.Margin = $DEFAULT_MARGIN

    # 列の定義（※ここはデータ構造に依存するため、具体的な記述を許容）
    $listView.Columns.Add("社員番号", 80) | Out-Null
    $listView.Columns.Add("氏名", 120) | Out-Null
    # 幅に-2を指定すると、残りの表示領域をすべて使用するよう自動調整される
    $listView.Columns.Add("部署", -2) | Out-Null

    # データ項目の追加
    if ($null -ne $Items) {
        $listView.Items.AddRange($Items)
    }

    return $listView
}

function New-SelectorDialog {
<#
.SYNOPSIS
    データを受け取り、汎用的な選択用GUIフォームオブジェクトを返します。
#>
    param (
        [array]$Data
    )

    # 1. データを行アイテムに変換（※ここはデータ構造に依存）
    $listItems = foreach ($entry in $Data) {
        $item = [System.Windows.Forms.ListViewItem]::new($entry.社員番号)
        $item.SubItems.Add($entry.氏名) | Out-Null
        $item.SubItems.Add($entry.部署) | Out-Null
        $item.Tag = $entry
        $item
    }

    # 2. GUIコントロールの作成と設定
    
    # メインフォーム
    $form = [System.Windows.Forms.Form]::new()
    $form.Text = $MAIN_FORM_TITLE
    $form.AutoSize = $true
    $form.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen

    # ルートパネル
    $rootPanel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $rootPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown
    $rootPanel.AutoSize = $true
    $rootPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $rootPanel.Padding = $DEFAULT_PADDING

    # ListView
    $listView = New-ItemListView -Items $listItems

    # ボタン用パネル
    $buttonPanel = [System.Windows.Forms.FlowLayoutPanel]::new()
    $buttonPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::RightToLeft
    $buttonPanel.Width = $LISTVIEW_SIZE.Width
    $buttonPanel.Height = $BUTTON_PANEL_HEIGHT
    $buttonPanel.Margin = $DEFAULT_MARGIN

    # OKボタン
    $okButton = [System.Windows.Forms.Button]::new()
    $okButton.Text = $OK_BUTTON_TEXT
    $okButton.Size = $OK_BUTTON_SIZE
    $okButton.Margin = $DEFAULT_MARGIN
    $okButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
    
    # 3. レイアウトの構築
    $buttonPanel.Controls.Add($okButton) | Out-Null
    $rootPanel.Controls.Add($listView) | Out-Null
    $rootPanel.Controls.Add($buttonPanel) | Out-Null
    $form.Controls.Add($rootPanel) | Out-Null
    $form.AcceptButton = $okButton

    # 4. 呼び出し元がListViewにアクセスできるよう、カスタムプロパティとして追加
    $form | Add-Member -MemberType NoteProperty -Name 'ListView' -Value $listView

    # 5. 組み立てたフォームオブジェクトを返す
    return $form
}

#endregion


#region メイン処理
# =============================================================================
# メイン処理ブロック
# =============================================================================

# 1. 表示するサンプルデータを作成
$sampleData = @(
    [PSCustomObject]@{ "社員番号" = "001"; "氏名" = "山田 太郎"; "部署" = "営業部" }
    [PSCustomObject]@{ "社員番号" = "002"; "氏名" = "佐藤 花子"; "部署" = "開発部" }
    [PSCustomObject]@{ "社員番号" = "003"; "氏名" = "鈴木 一郎"; "部署" = "人事部" }
    [PSCustomObject]@{ "社員番号" = "004"; "氏名" = "田中 美咲"; "部署" = "開発部" }
)

# 2. GUIフォームオブジェクトを作成
$dialog = New-SelectorDialog -Data $sampleData

# 3. フォームを表示し、ユーザーの操作を待つ
$dialogResult = $dialog.ShowDialog()

# 4. 結果を処理
if ($dialogResult -eq [System.Windows.Forms.DialogResult]::OK -and $dialog.ListView.SelectedItems.Count -gt 0) {
    # Tagプロパティから元のオブジェクトを取得
    $selectedItem = $dialog.ListView.SelectedItems[0].Tag

    [System.Console]::WriteLine("以下の項目が選択されました：")
    # 出力（※ここはデータ構造に依存）
    $output = "社員番号: {0}, 氏名: {1}, 部署: {2}" -f $selectedItem.社員番号, $selectedItem.氏名, $selectedItem.部署
    [System.Console]::WriteLine($output)
} else {
    [System.Console]::WriteLine("項目は選択されませんでした。")
}

#endregion