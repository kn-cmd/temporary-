﻿
# 表形式で表示したいデータを作成します（カスタムオブジェクトの配列）
$data = @(
    [PSCustomObject]@{ "社員番号" = "001"; "氏名" = "山田 太郎"; "部署" = "営業部" }
    [PSCustomObject]@{ "社員番号" = "002"; "氏名" = "佐藤 花子"; "部署" = "開発部" }
    [PSCustomObject]@{ "社員番号" = "003"; "氏名" = "鈴木 一郎"; "部署" = "人事部" }
    [PSCustomObject]@{ "社員番号" = "004"; "氏名" = "田中 美咲"; "部署" = "開発部" }
)

# Out-GridViewでデータを表示し、ユーザーが選択した項目を受け取ります
# Ctrlキーを押しながらクリックすることで複数行を選択できます
$selection = $data | Out-GridView -Title "社員一覧" -PassThru

# 選択された項目があれば、その内容をコンソールに表示します
if ($selection) {
    Write-Host "以下の社員が選択されました："
    $selection | Format-Table
} else {
    Write-Host "社員は選択されませんでした。"
}
