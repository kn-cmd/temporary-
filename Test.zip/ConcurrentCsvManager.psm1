﻿#region Exception Classes
class SchemaValidationException : System.Exception {
    SchemaValidationException([string]$message) : base($message) {}
}

class DuplicateKeyException : System.Exception {
    DuplicateKeyException([string]$message) : base($message) {}
}

class OptimisticLockingException : System.Exception {
    OptimisticLockingException([string]$message) : base($message) {}
}

class LockTimeoutException : System.Exception {
    LockTimeoutException([string]$message) : base($message) {}
}
#endregion

#region Helper Functions for File Locking
function _Acquire-CsvFileLock {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$FilePath,

        [Parameter(Mandatory=$true)]
        [int]$MaxRetries,

        [Parameter(Mandatory=$true)]
        [int]$RetryIntervalMs
    )

    for ($i = 0; $i -lt $MaxRetries; $i++) {
        try {
            # FileShare.None で排他ロックを取得
            $fileStream = [System.IO.FileStream]::new(
                $FilePath,
                [System.IO.FileMode]::OpenOrCreate, # ファイルが存在しない場合は作成
                [System.IO.FileAccess]::ReadWrite,
                [System.IO.FileShare]::None
            )
            return $fileStream # ロック取得成功
        } catch [System.IO.IOException] {
            # ロック取得失敗、リトライ
            Start-Sleep -Milliseconds $RetryIntervalMs
        }
    }
    # 最大リトライ回数を超えてもロック取得失敗
    throw [LockTimeoutException]::new("指定されたリトライ回数 $($MaxRetries) 後もファイル $($FilePath) のロックを取得できませんでした。")
}

function _Invoke-WithCsvFileLock {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$FilePath,

        [Parameter(Mandatory=$true)]
        [int]$MaxRetries,

        [Parameter(Mandatory=$true)]
        [int]$RetryIntervalMs,

        [Parameter(Mandatory=$true)]
        [scriptblock]$Action
    )

    $fileStream = $null
    try {
        $fileStream = _Acquire-CsvFileLock -FilePath $FilePath -MaxRetries $MaxRetries -RetryIntervalMs $RetryIntervalMs
        # ScriptBlockにFileStreamを引数として渡して実行し、結果を返す
        return & $Action $fileStream
    } finally {
        if ($fileStream) {
            $fileStream.Dispose()
        }
    }
}
#endregion

#region Public Functions
function New-CsvManagerSession {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string]$FilePath,

        [Parameter(Mandatory=$true)]
        [string[]]$Columns,

        [System.Text.Encoding]$Encoding = (New-Object System.Text.UTF8Encoding($false)), # UTF8 BOMなし

        [int]$MaxRetries = 10,

        [int]$RetryIntervalMs = 100
    )

    # セッションオブジェクトを作成
    $session = [PSCustomObject]@{
        FilePath        = $FilePath
        Columns         = $Columns
        Encoding        = $Encoding
        MaxRetries      = $MaxRetries
        RetryIntervalMs = $RetryIntervalMs
    }

    # ファイル/ヘッダーの初期検証 (排他ロック下で実行)
    _Invoke-WithCsvFileLock -FilePath $FilePath -MaxRetries $MaxRetries -RetryIntervalMs $RetryIntervalMs -Action {
        param($fileStream)

        if ($fileStream.Length -eq 0) {
            # ファイルが新規作成された場合、ヘッダーを書き込む
            $headerLine = '"' + ($session.Columns -join '","') + '"' + "`r`n"
            $bytes = $session.Encoding.GetBytes($headerLine)
            $fileStream.Write($bytes, 0, $bytes.Length)
            $fileStream.Flush() # 確実に書き込みを反映
            $fileStream.Seek(0, [System.IO.SeekOrigin]::Begin) # ストリーム位置を先頭に戻す
        } else {
            # ファイルが存在する場合、ヘッダーを検証する
            $fileStream.Seek(0, [System.IO.SeekOrigin]::Begin) # 読み取り前にストリーム位置を先頭に戻す
            $reader = [System.IO.StreamReader]::new($fileStream, $session.Encoding, $true, 1024, $true) # leaveOpen を true に設定
            $existingHeader = $reader.ReadLine()
            $existingColumns = $existingHeader.Trim('"') -split '","'

            if ($null -eq $existingColumns -or (Compare-Object -ReferenceObject $session.Columns -DifferenceObject $existingColumns)) {
                throw [SchemaValidationException]::new("CSVヘッダーが一致しません。期待されるヘッダー: $($session.Columns | ConvertTo-Json -Compress) / 実際のヘッダー: $($existingColumns | ConvertTo-Json -Compress)")
            }
        }
    }
    
    return $session
}

function Invoke-CsvUpsert {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$SessionObject,

        [Parameter(Mandatory=$true)]
        [hashtable]$Data,

        [Parameter(Mandatory=$true)]
        [string[]]$KeyColumns,

        [switch]$Unique,

        [hashtable]$Assume
    )

    _Invoke-WithCsvFileLock -FilePath $SessionObject.FilePath -MaxRetries $SessionObject.MaxRetries -RetryIntervalMs $SessionObject.RetryIntervalMs -Action {
        param($fs)
        $allRecords = New-Object System.Collections.Generic.List[PSObject]

        # 既存データを読み込む
        $fs.Seek(0, [System.IO.SeekOrigin]::Begin)
        $reader = [System.IO.StreamReader]::new($fs, $SessionObject.Encoding, $true, 1024, $true)
        $reader.ReadLine() | Out-Null # ヘッダー行をスキップ

        while (-not $reader.EndOfStream) {
            $line = $reader.ReadLine()
            if (-not [string]::IsNullOrEmpty($line)) {
                $values = $line.Trim('"') -split '","'
                $record = [PSCustomObject]::new()
                for ($i = 0; $i -lt $SessionObject.Columns.Length; $i++) {
                    if ($i -ge $values.Length) {
                        $record | Add-Member -MemberType NoteProperty -Name $SessionObject.Columns[$i] -Value ""
                    } else {
                        $record | Add-Member -MemberType NoteProperty -Name $SessionObject.Columns[$i] -Value $values[$i]
                    }
                }
                $allRecords.Add($record)
            }
        }
        
        $matchedRecords = New-Object System.Collections.Generic.List[PSObject]
        foreach ($record in $allRecords) {
            $isMatch = $true
            foreach ($keyCol in $KeyColumns) {
                # KeyColumnsに含まれるプロパティが存在しない場合は比較対象外とする
                if (-not ($record.PSObject.Properties.Name -contains $keyCol)) {
                    $isMatch = $false
                    break
                }
                if ($record.$keyCol -ne $Data.$keyCol) {
                    $isMatch = $false
                    break
                }
            }
            if ($isMatch) {
                $matchedRecords.Add($record)
            }
        }

        if ($Unique -and $matchedRecords.Count -gt 1) {
            throw [DuplicateKeyException]::new("キーカラム ($($KeyColumns -join ',')) とデータ: $($Data | ConvertTo-Json -Compress) に複数のレコードが見つかりました。ユニークなUpsertは実行できません。")
        }

        if ($matchedRecords.Count -gt 0) {
            # 既存のレコードを更新します。
            foreach ($existingRecord in $matchedRecords) {
                # 楽観的ロックのチェック
                if ($Assume) {
                    $assumeMatch = $true
                    foreach ($assumeKey in $Assume.Keys) {
                        # Assumeキーがレコードに存在しない場合、または値が一致しない場合
                        if (-not ($existingRecord.PSObject.Properties.Name -contains $assumeKey) -or $existingRecord.$assumeKey -ne $Assume.$assumeKey) {
                            $assumeMatch = $false
                            break
                        }
                    }
                    if (-not $assumeMatch) {
                        throw [OptimisticLockingException]::new("キーカラム ($($KeyColumns -join ',')) とデータ: $($Data | ConvertTo-Json -Compress) のレコードに対する楽観的ロックに失敗しました。想定された状態: $($Assume | ConvertTo-Json -Compress)")
                    }
                }

                foreach ($prop in $Data.Keys) {
                    # $Data に含まれるキーのみを更新
                    # (部分更新をサポートするため、$SessionObject.Columns は使用しない)
                    # 列が存在しない場合は新規追加
                    if ($existingRecord.PSObject.Properties.Name -contains $prop) {
                        $existingRecord.$prop = $Data.$prop
                    } else {
                        $existingRecord | Add-Member -MemberType NoteProperty -Name $prop -Value $Data.$prop
                    }
                }
            }
        } else {
            # 新しいレコードを挿入します。
            $newRecord = [PSCustomObject]::new()
            foreach ($col in $SessionObject.Columns) {
                $value = if ($Data.ContainsKey($col)) { $Data.$col } else { "" }
                $newRecord | Add-Member -MemberType NoteProperty -Name $col -Value $value
            }
            $allRecords.Add($newRecord)
        }

        # ファイルに全データを書き戻す
        $fs.SetLength(0) # ファイルの内容をクリア
        $writer = [System.IO.StreamWriter]::new($fs, $SessionObject.Encoding)

        # ヘッダーを書き込む
        $writer.WriteLine(('"' + ($SessionObject.Columns -join '","') + '"'))

        # レコードを書き込む
        foreach ($record in $allRecords) {
            $lineValues = @()
            foreach ($col in $SessionObject.Columns) {
                # null値や未定義のプロパティを空文字列として扱う
                $value = if ($record.PSObject.Properties.Name -contains $col -and ($null -ne $record.$col)) {
                    $record.$col.ToString()
                } else {
                    ""
                }
                $lineValues += $value
            }
            $writer.WriteLine(('"' + ($lineValues -join '","') + '"'))
        }
        $writer.Flush()
    }
}

function Get-CsvData {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [PSCustomObject]$SessionObject,

        [hashtable]$Filter = @{},

        [switch]$Unique,

        [switch]$AllowDirtyRead
    )

    $allRecords = New-Object System.Collections.Generic.List[PSObject]

    $readAction = {
        param($fs)
        $fs.Seek(0, [System.IO.SeekOrigin]::Begin) # ストリーム位置を先頭に戻す
        $reader = [System.IO.StreamReader]::new($fs, $SessionObject.Encoding, $true, 1024, $true)
        
        # ヘッダー行をスキップ
        $reader.ReadLine() | Out-Null

        while (-not $reader.EndOfStream) {
            $line = $reader.ReadLine()
            if (-not [string]::IsNullOrEmpty($line)) {
                $values = $line.Trim('"') -split '","'
                $record = [PSCustomObject]::new()
                for ($i = 0; $i -lt $SessionObject.Columns.Length; $i++) {
                    # CSVの列数とヘッダーの列数が一致しない場合のエラーハンドリング
                    if ($i -ge $values.Length) {
                        # データがヘッダーより少ない場合、空文字列を設定
                        $record | Add-Member -MemberType NoteProperty -Name $SessionObject.Columns[$i] -Value ""
                    } else {
                        $record | Add-Member -MemberType NoteProperty -Name $SessionObject.Columns[$i] -Value $values[$i]
                    }
                }
                $allRecords.Add($record)
            }
        }
        # リストから各レコードを明示的に出力します。
        $allRecords | ForEach-Object { $_ }
    }

    if ($AllowDirtyRead) {
        $dirtyReadFs = $null
        try {
            $dirtyReadFs = [System.IO.FileStream]::new(
                $SessionObject.FilePath,
                [System.IO.FileMode]::Open,
                [System.IO.FileAccess]::Read,
                [System.IO.FileShare]::ReadWrite # ダーティリードを許可
            )
            $records = & $readAction $dirtyReadFs
        } catch {
            throw $_
        } finally {
            if ($dirtyReadFs) {
                $dirtyReadFs.Dispose()
            }
        }
    } else {
        $records = _Invoke-WithCsvFileLock -FilePath $SessionObject.FilePath -MaxRetries $SessionObject.MaxRetries -RetryIntervalMs $SessionObject.RetryIntervalMs -Action $readAction
    }

    # フィルタリング
    $filteredRecords = @()
    if ($Filter.Count -gt 0) {
        foreach ($record in $records) {
            $match = $true
            foreach ($key in $Filter.Keys) {
                if (-not ($record.PSObject.Properties.Name -contains $key) -or $record.$key -ne $Filter.$key) {
                    $match = $false
                    break
                }
            }
            if ($match) {
                $filteredRecords += $record
            }
        }
    } else {
        $filteredRecords = $records
    }

    # Uniqueスイッチの処理
    if ($Unique) {
        if ($filteredRecords.Count -eq 1) {
            return $filteredRecords[0]
        } elseif ($filteredRecords.Count -eq 0) {
            return $null
        } else {
            throw [DuplicateKeyException]::new("フィルター: $($Filter | ConvertTo-Json -Compress) を使用したユニーク読み取りで複数のレコードが見つかりました。")
        }
    } else {
        return $filteredRecords
    }
}
#endregion
