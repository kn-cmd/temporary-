
# Spring Batch 低コスト導入・開発ガイドライン

本資料では、学習コストを最小限に抑えつつ、保守性の高いバッチ基盤を構築するための構成指針を定義します。

## 0. 前提知識：Spring Batchの基本構造
Spring Batchを理解するための最小限のキーワードです。これだけ知っていれば開発を始められます。

*   **Job（ジョブ）**: バッチ処理の全体単位（例：月次売上集計ジョブ）。
*   **Step（ステップ）**: Jobを構成する個別の処理単位。1つのJobは1つ以上のStepを持ちます。
*   **Tasklet（タスクレット）**: 「1つの処理をまとめて書く」最もシンプルなStepの実装方式。**本ガイドではこの方式を推奨します。**
*   **Chunk（チャンク）**: 「読み込み・加工・書き込み」を繰り返す、大量データ処理向けの高度な方式。
*   **メタデータテーブル**: Jobの実行履歴や結果を記録するSpring Batch専用の管理テーブル。
*   **トランザクション管理**: 処理が失敗した際に、そのStep内で行ったDB操作を自動的にロールバック（取り消し）する仕組み。


## 1. 基本方針：学習コストを削る3原則
1.  **「Tasklet」から始める**: 複雑なChunk（Reader/Processor/Writer）は、大量データ処理が必要になるまで後回しにする。
2.  **標準機能に頼る**: 自作ループを避け、Spring Boot 3.x の標準設定（Auto Configuration）を最大限活用する。
3.  **高度な機能は捨てる**: 「リトライ」「スキップ」「並行処理」は最初から組み込まない。エラー時は「停止してログを見る」を基本とする。

## 2. インフラ・DB構成（メタデータ管理）
Spring Batchは実行状態を管理するテーブル（メタデータ）を必須とします。

*   **スキーマ分離戦略**: 業務テーブルとの混同を避けるため、同一DBインスタンス内に **`spring_metadata`** スキーマを作成し、そこに管理テーブルを集約します。
*   **設定（application.properties）**:
    ```properties
    # 接続設定（環境変数による上書きを許容）
    spring.datasource.url=${DB_URL:jdbc:postgresql://localhost:5432/mydb}
    spring.datasource.username=${DB_USER:user}
    spring.datasource.password=${DB_PASS:pass}

    # メタデータDBの自動初期化（初回のみalways、以降はnever）
    spring.batch.jdbc.initialize-schema=always
    
    # メタデータのスキーマ指定（重要）
    # テーブル名の前にスキーマ名を付与する設定
    spring.batch.jdbc.table-prefix=spring_metadata.BATCH_
    ```

## 3. 共通基盤として最低限実装すべき4機能
これら以外の機能（リスナー、インターセプター等）は、必要になるまで実装不要です。

### ① 環境変数の利用
`application.properties` と `@Value` アノテーションを使い、接続先やファイルパスを外部から注入可能にします。
```java
@Value("${app.batch.input-path:/tmp/input}")
private String inputPath;
```

### ② 動的パラメータ（@StepScope）
実行ごとに変わる「日付」や「ファイル名」を扱うために必須です。これを使わないと、バッチ実行中にパラメータを動的に変更できません。
```java
@Bean
@StepScope
public Tasklet myTasklet(@Value("#{jobParameters['targetDate']}") String targetDate) {
    return (contribution, chunkContext) -> {
        // targetDate を使った処理
        return RepeatStatus.FINISHED;
    };
}
```

### ③ ログ出力
「どこまで進んだか」を把握するため、SLF4J (Lombok) を使用してステップの開始・終了、処理件数を出力します。

### ④ 標準Reader / Writer
ファイル読み込みやDB書き込みが必要な場合のみ、以下の標準部品を呼び出します（自作しない）。
*   `FlatFileItemReader`（CSV読み込み）
*   `JdbcBatchItemWriter`（DB一括書き込み）

## 4. 推奨される開発ステップ

| ステップ | 内容 | 学習のポイント |
| :--- | :--- | :--- |
| **Step 1: 疎通** | Taskletで「Hello World」とログを出す | `Job` と `Step` の関係を理解する |
| **Step 2: DB接続** | `spring_metadata` スキーマにテーブルが作られるか確認 | 接続設定とプレフィックスの理解 |
| **Step 3: パラメータ** | 実行引数（JobParameters）をTaskletで受け取る | `@StepScope` の使い方を習得 |
| **Step 4: 業務ロジック** | 既存のJavaロジックをTasklet内に移植する | 成功/失敗のステータス管理を理解 |

## 5. 補足：トラブルシューティング
*   **「同じJobを2回実行できない」**: Spring Batchはデフォルトで「同じ引数での成功済みJob」の再実行を拒否します。開発時は引数に `run.id=${random.long}` などを付与して回避します。
*   **「テーブルがない」エラー**: `spring.batch.jdbc.initialize-schema=always` が効いているか、スキーマ `spring_metadata` が事前に作成されているかを確認してください。

---
**結論:**
最初は **「Tasklet + 環境変数 + スキーマ分離」** だけ。
これだけで業務バッチの8割は安全・低コストに構築可能です。
