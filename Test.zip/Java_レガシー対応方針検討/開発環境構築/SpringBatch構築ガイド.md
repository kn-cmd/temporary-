# Spring Batch 構築ガイド

本資料では、Spring Batchを用いたバッチアプリケーションの具体的な設定方法とコード例について定義します。
導入の考え方については [SpringBatch導入方針.md](./SpringBatch導入方針.md) を参照してください。

## 1. 準備：依存関係の追加
Spring Bootプロジェクトに以下の依存関係を追加することで、Spring Batchの全機能とSpring Bootによる自動設定（Auto Configuration）が有効になります。

*   **依存関係**:
    *   **Maven**: `spring-boot-starter-batch`
    *   **Gradle**: `implementation 'org.springframework.boot:spring-boot-starter-batch'`
*   **注意**: 接続するDBに対応したJDBCドライバ（`postgresql` など）も別途必要です。
*   **ポイント**: Spring Boot 3.x 以降では `@EnableBatchProcessing` アノテーションは **不要** です。

## 2. インフラ・DB構成（メタデータ管理）
Spring Batchは実行履歴を管理するメタデータテーブルを必要とします。

*   **スキーマ分離戦略**: 業務データとフレームワークの管理データを分けるため、同一DBインスタンス内に **`spring_metadata`** スキーマを作成し、そこに管理テーブルを集約します。
*   **設定例（application.properties）**:
    ```properties
    # 接続設定
    spring.datasource.url=${DB_URL:jdbc:postgresql://localhost:5432/mydb}
    spring.datasource.username=${DB_USER:user}
    spring.datasource.password=${DB_PASS:pass}

    # メタデータDBの自動初期化（初回のみalways、以降はnever）
    spring.batch.jdbc.initialize-schema=always
    
    # メタデータのスキーマ指定（重要）
    spring.batch.jdbc.table-prefix=spring_metadata.BATCH_
    ```

## 3. 共通基盤として最低限実装すべき4機能

### ① 環境変数の利用
`@Value` アノテーションを使い、接続先やファイルパスを外部から注入可能にします。

### ② 動的パラメータ（@StepScope）
実行ごとに変わる「日付」や「ファイル名」を扱うために必須の設定です。

### ③ ログ出力
SLF4J (Lombokの@Slf4j) を使用して、ステップの開始・終了や処理結果を出力します。

### ④ 既存ロジックの利用
Tasklet内から既存のServiceやRepository、JdbcTemplateをそのまま呼び出すことができます。

## 4. 最小構成のコード例

```java
@Configuration
@Slf4j
@RequiredArgsConstructor
public class MyBatchConfig {
    private final JobRepository jobRepository;
    private final PlatformTransactionManager transactionManager;

    @Bean
    public Job myJob(Step myStep) {
        return new JobBuilder("myJob", jobRepository)
                .start(myStep)
                .build();
    }

    @Bean
    public Step myStep(Tasklet myTasklet) {
        return new StepBuilder("myStep", jobRepository)
                .tasklet(myTasklet, transactionManager)
                .build();
    }

    @Bean
    @StepScope
    public Tasklet myTasklet(@Value("#{jobParameters['targetDate']}") String targetDate) {
        return (contribution, chunkContext) -> {
            log.info("処理対象日: {}", targetDate);
            // ここに業務ロジックを記述（既存Serviceの呼び出しなど）
            return RepeatStatus.FINISHED;
        };
    }
}
```

## 5. バッチの起動方法

### 基本的な実行
```bash
# JARを実行（引数を渡す）
java -jar my-batch.jar targetDate=20240325
```

### 自動実行の制御（application.properties）
```properties
# 起動時の自動実行をオフにする
spring.batch.job.enabled=false

# 特定のJob名のみを実行対象にする
spring.batch.job.name=myJob
```

## 6. 補足：トラブルシューティング
*   **「同じJobを2回実行できない」**: 引数が同じ成功済みJobは再実行できません。開発時は引数に `run.id=${random.long}` などを付与して回避します。
*   **「テーブルがない」エラー**: `spring.batch.jdbc.initialize-schema=always` が効いているか、スキーマ `spring_metadata` が事前に作成されているかを確認してください。
