Attribute VB_Name = "Main"
Option Explicit

'''
' メイン実行ルーチン
'''
Public Sub Main()
    ' 対象となるワークブックを指定
    Dim targetBook As Workbook
    Set targetBook = ThisWorkbook

    ' ログ出力
    Debug.Print "調査開始対象ブック: " & targetBook.Name

    ' 1. 情報の取得
    Dim triggers() As TriggerInvestigator.MacroTriggerInfo
    triggers = TriggerInvestigator.GetAllMacroTriggers(targetBook)

    ' 2. 情報の表示（新規ブックに出力）
    If IsArrayInitialized(triggers) Then
        Call CreateReportSheet(triggers)
        MsgBox "マクロトリガーの調査が完了しました。新規作成されたブックを確認してください。", vbInformation
    Else
        MsgBox "マクロが設定されているオブジェクトは見つかりませんでした。", vbExclamation
    End If
End Sub

'''
' 取得した情報を新規ブックのシートに出力し、そのシートオブジェクトを返す
'''
Public Function CreateReportSheet(triggers() As TriggerInvestigator.MacroTriggerInfo) As Worksheet
    ' 新規ブックを作成
    Dim wbNew As Workbook
    Set wbNew = Workbooks.Add

    Dim wsReport As Worksheet
    Set wsReport = wbNew.Worksheets(1)

    ' ヘッダーの作成
    With wsReport
        .Cells(1, 1).Value = "シート名"
        .Cells(1, 2).Value = "オブジェクト名"
        .Cells(1, 3).Value = "表示テキスト"
        .Cells(1, 4).Value = "種類"
        .Cells(1, 5).Value = "モジュール名"
        .Cells(1, 6).Value = "関数名"
        .Cells(1, 7).Value = "OnAction(生データ)"

        ' スタイル設定
        With .Range("A1:G1")
            .Interior.Color = RGB(200, 200, 200)
            .Font.Bold = True
        End With
    End With

    ' データの書き込み
    Dim rowNum As Long
    rowNum = 2

    Dim i As Long
    For i = LBound(triggers) To UBound(triggers)
        wsReport.Cells(rowNum, 1).Value = triggers(i).SheetName
        wsReport.Cells(rowNum, 2).Value = triggers(i).ObjectName
        wsReport.Cells(rowNum, 3).Value = triggers(i).DisplayText
        wsReport.Cells(rowNum, 4).Value = triggers(i).ObjectType
        wsReport.Cells(rowNum, 5).Value = triggers(i).ModuleName
        wsReport.Cells(rowNum, 6).Value = triggers(i).FunctionName
        wsReport.Cells(rowNum, 7).Value = triggers(i).OnActionRaw
        rowNum = rowNum + 1
    Next i

    ' 列幅の自動調整
    wsReport.Columns("A:G").AutoFit
    
    ' 作成されたシートを返す
    Set CreateReportSheet = wsReport
End Function

'''
' 動的配列が初期化されているか（要素を持っているか）を判定する
'''
Private Function IsArrayInitialized(arr() As TriggerInvestigator.MacroTriggerInfo) As Boolean
    On Error Resume Next
    ' LBoundを試みてエラーが発生しなければ初期化済みとみなす
    IsArrayInitialized = (LBound(arr) <= UBound(arr))
    On Error GoTo 0
End Function

