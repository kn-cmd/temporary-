Attribute VB_Name = "TriggerInvestigator"
Option Explicit

' マクロトリガー（ボタンや図形など）の情報を保持する構造体
Public Type MacroTriggerInfo
    SheetName As String
    ObjectName As String
    DisplayText As String
    ObjectType As String
    OnActionRaw As String
    ModuleName As String
    FunctionName As String
End Type

'''
' 指定されたワークブック内の全シートからマクロが設定されたオブジェクト情報を収集する
'''
Public Function GetAllMacroTriggers(wb As Workbook) As MacroTriggerInfo()
    Dim results() As MacroTriggerInfo
    Dim count As Long
    count = 0
    
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        Dim shp As Shape
        For Each shp In ws.Shapes
            ' OnAction プロパティを確認（マクロが割り当てられている場合のみ）
            Dim rawAction As String
            rawAction = ""
            On Error Resume Next
            rawAction = shp.OnAction
            On Error GoTo 0
            
            If rawAction <> "" Then
                ReDim Preserve results(count)
                
                results(count).SheetName = ws.Name
                results(count).ObjectName = shp.Name
                results(count).DisplayText = GetShapeText(shp)
                results(count).ObjectType = GetShapeTypeName(shp.Type)
                results(count).OnActionRaw = rawAction
                
                ' OnAction文字列を解析してモジュール名と関数名に分離を試みる
                ParseOnAction rawAction, results(count).ModuleName, results(count).FunctionName
                
                count = count + 1
            End If
        Next shp
    Next ws
    
    GetAllMacroTriggers = results
End Function

'''
' Shapeからテキストを取得する
'''
Private Function GetShapeText(shp As Shape) As String
    Dim txt As String
    txt = ""
    On Error Resume Next
    
    ' フォームコントロール等のテキスト取得を試みる
    txt = shp.TextFrame.Characters.Text
    
    ' 取得できなかった場合、TextFrame2（新しい形式の図形）を試みる
    If Err.Number <> 0 Or txt = "" Then
        Err.Clear
        If shp.HasTextFrame Then
            If shp.TextFrame2.HasText Then
                txt = shp.TextFrame2.TextRange.Text
            End If
        End If
    End If
    On Error GoTo 0
    
    ' テキストをそのまま返す（前後の空白のみ除去）
    GetShapeText = Trim(txt)
End Function

'''
' OnAction文字列を解析して、モジュール名と関数名に分割する
'''
Private Sub ParseOnAction(rawAction As String, ByRef outModule As String, ByRef outFunction As String)
    ' ブック名の部分 ('Book1.xlsm'!) を除去
    Dim cleanAction As String
    Dim lastBang As Long
    lastBang = InStrRev(rawAction, "!")
    
    If lastBang > 0 Then
        cleanAction = Mid(rawAction, lastBang + 1)
    Else
        cleanAction = rawAction
    End If
    
    ' モジュール名と関数名の分離 (Module1.MyMacro)
    Dim lastDot As Long
    lastDot = InStrRev(cleanAction, ".")
    
    If lastDot > 0 Then
        outModule = Left(cleanAction, lastDot - 1)
        outFunction = Mid(cleanAction, lastDot + 1)
    Else
        outModule = "(不明/標準)"
        outFunction = cleanAction
    End If
End Sub

'''
' ShapeType 列挙型を読みやすい文字列に変換する
'''
Private Function GetShapeTypeName(st As Long) As String
    Select Case st
        Case 1: GetShapeTypeName = "AutoShape"
        Case 4: GetShapeTypeName = "Canvas"
        Case 5: GetShapeTypeName = "Chart"
        Case 6: GetShapeTypeName = "Comment"
        Case 8: GetShapeTypeName = "FormControl"
        Case 12: GetShapeTypeName = "Group"
        Case 13: GetShapeTypeName = "Picture"
        Case 14: GetShapeTypeName = "OLEObject"
        Case 17: GetShapeTypeName = "TextBox"
        Case Else: GetShapeTypeName = "Other (" & st & ")"
    End Select
End Function
