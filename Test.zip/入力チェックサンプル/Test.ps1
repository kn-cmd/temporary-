﻿Import-Module (Join-Path $PSScriptRoot "ui.psm1")

# --- 設定値の集中管理 (定数) ---

# アプリケーション全般
$APP_TITLE = "ID検索ツール"

# フォームサイズ (最小サイズとして使用)
$FORM_WIDTH = 450
$FORM_HEIGHT = 350


# DataGridView設定
$COL_ID_HEADER = "ID"
$COL_VALUE_HEADER = "値"
$gridViewSize = [System.Drawing.Size]::new(200, 500)
$READONLY_BACKCOLOR = [System.Drawing.Color]::LightGray
$INITIAL_ROWS = 30

# データファイルパス
$CSV_FILE_PATH = Join-Path $PSScriptRoot "id_data.csv" # CSVファイルのパス

# --- ID-値の辞書 (ハッシュテーブル) ---
$data = @{
    "ID001" = "Apple"
    "ID002" = "Banana"
    "ID003" = "Cherry"
    "ID004" = "Date"
}



function New-MainForm {
<#
.SYNOPSIS
メインとなるWindowsフォームを作成し、コントロールを配置します。
#>
    $form = New-UiForm -Title $APP_TITLE -StartPosition CenterScreen -AutoSize
    $form.MinimumSize = [System.Drawing.Size]::new($FORM_WIDTH, $FORM_HEIGHT)
    
    # UIレイアウト
    $rootPanel = New-UiFlowLayoutPanel -AutoSize -Controls {

        # DataGridViewの作成と追加
        $dataGridView = New-UIDataGridView -FromCount $INITIAL_ROWS -Columns @("ID", "Value") -Size $gridViewSize
        $dataGridView

        # 値列を読み取り専用に設定
        $dataGridView.Columns["Value"].ReadOnly = $true
        $dataGridView.Columns["Value"].DefaultCellStyle.BackColor = $READONLY_BACKCOLOR
        $dataGridView.Columns["ID"].HeaderText = $COL_ID_HEADER
        $dataGridView.Columns["Value"].HeaderText = $COL_VALUE_HEADER
        

        # CSVからデータを読み込み、DataGridViewを補完
        Load-CsvToDataGridView -DataGridView $dataGridView | Out-Null
        
        # --- DataGridViewのCellValueChangedイベントハンドラ ---
        $dataGridView.Add_CellValueChanged({
            param($sender, $e)

            # ID列の変更のみを処理
            if ($e.ColumnIndex -ne $this.Columns["ID"].Index -or $e.RowIndex -lt 0) { return }
            
            # 変更されたID列の値を取得
            $id = $this.Rows[$e.RowIndex].Cells["ID"].Value

            # 対応する値を取得
            if ($id -ne $null -and $id.ToString().Trim() -ne "") {
                $trimmedId = $id.ToString().Trim()
                if ($data.ContainsKey($trimmedId)) {
                    $value = $data[$trimmedId]
                } else {
                    $value = ""
                }
            }
            else {
                $value = ""
            }
            # 対応するValue列の値を更新
            $this.Rows[$e.RowIndex].Cells["Value"].Value = $value
        })

        $form.Tag = $dataGridView

        # ボタンパネルの作成 (FlowLayoutPanelを使用)
        $buttonPanel = New-UiFlowLayoutPanel -FlowDirection RightToLeft -AutoSize -Controls {

            # OKボタン
            $buttonOk = New-UiButton -Text "OK"
            $buttonOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $buttonOk.Add_Click({ Save-DataGridViewToCsv -DataGridView $this.FindForm().Tag })
            $buttonOk

            # キャンセルボタン
            $buttonCancel = New-UiButton -Text "キャンセル"
            $buttonCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
            $buttonCancel
        }
        $buttonPanel
    }

    # フォームにルートパネルを追加
    $form.Controls.Add($rootPanel)
    return $form
}

# --- データ保存関数 ---
function Save-DataGridViewToCsv {
<#
.SYNOPSIS
DataGridViewの内容をCSVファイルに保存します。
#>
    param(
        [Parameter(Mandatory=$true)]
        [System.Windows.Forms.DataGridView]$DataGridView
    )

    $csvContent = @()
    # ヘッダー行を追加
    $csvContent += "`"ID`",`"Value`""

    foreach ($row in $DataGridView.Rows) {
        # 新規行で、ID列が空の場合はスキップ
        if ($row.IsNewRow -or [string]::IsNullOrEmpty($row.Cells["ID"].Value)) {
            continue
        }

        $id = ($row.Cells["ID"].Value | Out-String).Trim()
        $value = ($row.Cells["Value"].Value | Out-String).Trim()

        # CSV形式で追加
        $csvContent += "`"$id`",`"$value`""
    }

    try {
        $csvContent | Set-Content -Path $CSV_FILE_PATH -Encoding UTF8
        Write-Host "Data saved to $CSV_FILE_PATH"
    } catch {
        Write-Error "Failed to save data to CSV: $($_.Exception.Message)"
    }
}

# --- データ読み込み関数 ---
function Load-CsvToDataGridView {
<#
.SYNOPSIS
CSVファイルからデータを読み込み、DataGridViewを補完します。
#>
    param(
        [Parameter(Mandatory=$true)]
        [System.Windows.Forms.DataGridView]$DataGridView
    )

    if (Test-Path $CSV_FILE_PATH) {
        try {
            $csvData = Import-Csv -Path $CSV_FILE_PATH -Encoding UTF8

            # DataGridViewをクリア
            $DataGridView.Rows.Clear()

            foreach ($row in $csvData) {
                $DataGridView.Rows.Add($row.ID, $row.Value)
            }
            # 少なくともINITIAL_ROWSの行を確保
            while ($DataGridView.Rows.Count -lt $INITIAL_ROWS) {
                $DataGridView.Rows.Add() | Out-Null
            }

            Write-Host "Data loaded from $CSV_FILE_PATH"
        } catch {
            Write-Error "Failed to load data from CSV: $($_.Exception.Message)"
        }
    } else {
        Write-Host "CSV file not found: $CSV_FILE_PATH. Starting with empty DataGridView."
    }
}

# --- メインロジック ---
$mainForm = New-MainForm
$mainForm.ShowDialog() | Out-Null