import subprocess
import os
from pathlib import Path

def create_test_file(path, content_bytes):
    Path(path).write_bytes(content_bytes)

def run_tool(args):
    # 'python' コマンドで実行
    result = subprocess.run(['python', 'resize_fixedlength.py'] + args, capture_output=True, text=True)
    return result

def test_all():
    input_file = "test_resize_in.dat"
    output_file = "test_resize_out.dat"
    
    # 1. 拡張テスト (10 -> 15)
    # 2レコード: "ABCDEFGHIJ" (10), "0123456789" (10)
    content = b"ABCDEFGHIJ0123456789"
    create_test_file(input_file, content)
    
    print("--- Test 1: Extend (10 -> 15) ---")
    run_tool([input_file, output_file, "--li", "10", "--lo", "15"])
    out_content = Path(output_file).read_bytes()
    print(f"Output: {out_content}")
    # 各レコードの末尾に5つのスペースが入るはず
    assert out_content == b"ABCDEFGHIJ     0123456789     "
    print("OK: Extended with spaces.")

    # 2. 縮小テスト (10 -> 5)
    print("--- Test 2: Shrink (10 -> 5) ---")
    run_tool([input_file, output_file, "--li", "10", "--lo", "5"])
    out_content = Path(output_file).read_bytes()
    print(f"Output: {out_content}")
    assert out_content == b"ABCDE01234"
    print("OK: Shrinked correctly.")

    # 3. 不完全な終端のテスト
    # 10バイト必要なのに、最後に5バイト余計なデータがある場合 ("EXTRA")
    content_incomplete = content + b"EXTRA" 
    create_test_file(input_file, content_incomplete)
    
    print("--- Test 3: Incomplete Ending (ignore) ---")
    run_tool([input_file, output_file, "--li", "10", "--lo", "10", "-i", "ignore"])
    out_content = Path(output_file).read_bytes()
    # 最後の5バイトは無視され、元の2レコード分 (20バイト) のみ出力されるはず
    assert len(out_content) == 20
    print("OK: Ignored extra bytes.")

    print("--- Test 4: Incomplete Ending (error) ---")
    res = run_tool([input_file, output_file, "--li", "10", "--lo", "10", "-i", "error"])
    print(f"Error output: {res.stderr}")
    assert "不完全なレコード" in res.stderr
    print("OK: Caught error.")

    print("--- Test 5: Incomplete Ending (fill, 10 -> 12) ---")
    # "EXTRA"(5) を lo=12 まで埋める -> "EXTRA" + 7spaces
    run_tool([input_file, output_file, "--li", "10", "--lo", "12", "-i", "fill"])
    out_content = Path(output_file).read_bytes()
    print(f"Output: {out_content}")
    # 3レコード目は "EXTRA" + "       " (7 spaces)
    assert out_content.endswith(b"EXTRA       ")
    print("OK: Filled and processed last record.")

    # 後片付け
    for f in [input_file, output_file]:
        if os.path.exists(f): os.remove(f)

if __name__ == "__main__":
    test_all()
    print("\nAll resize tests passed successfully!")
