## はじめに

本記事は、読みやすさ・一貫性・保守性を重視した PowerShell のスタイルガイドです。クリーンでメンテナンスしやすいスクリプトを書くためのベストプラクティスを紹介します。本ガイドは [PowerShell Practice and Style Guide](https://github.com/PoshCode/PowerShellPracticeAndStyle/tree/master/Style-Guide) に基づいています。


## 命名規則

### 大文字小文字の規則

#### 目的・背景
PowerShell 自体は大文字小文字を区別しませんが、.NET 慣習や標準的なコマンドレットとの一貫性を保ち、可読性を向上させるために PascalCase を推奨します。また、言語キーワードや演算子を小文字にすることで、識別子との区別が容易になります。

#### 規約
* 公開識別子（関数名、パラメータ名、プロパティ、クラス、モジュール名）、グローバル変数、定数には **PascalCase** を使用する。ただし、2文字の単語は両方を大文字（例： `$PSBoundParameters`）とする。
* 言語キーワード（`if`, `foreach` など）および演算子（`-eq`, `-match`, `-and` など）には **小文字（lowercase）** を使用する。
* コメントベースのヘルプ（`.SYNOPSIS`, `.EXAMPLE` など）には **大文字（UPPERCASE）** を使用する。
* 関数内のみで使用するプライベートな変数には、パラメータと区別するために **camelCase** を使用してもよい（「好みの問題」としての許容）。

#### 規約の例外

以下の2語は2文字であるため両方を大文字で記載する規約となっていますが、例外的に2文字目を小文字とすることを許容します。
これは Microsoft の設計指針や歴史的な慣例に基づくものです。

| 単語 | 表記 | 備考 |
| :--- | :--- | :--- |
| ID | `Id` | Identificationの略として扱う。最も頻出する例外。 |
| OK | `Ok` | 確認応答などのステータスで使用。 |

#### 良い例
推奨される命名規則に従った例です。関数名やパラメータ名が読みやすく、識別子と言語キーワードが明確に区別されています。

```powershell
function Get-ServiceStatus {
    [CmdletBinding()]
    param(
        [string]$ServiceName
    )
    $currentStatus = Get-Service -Name $ServiceName
    if ($currentStatus -eq 'Running') {
        Write-Output $currentStatus
    }
}
```

#### 悪い例
キーワードが大文字であったり、識別子がすべて小文字であったりする例です。これらは可読性を下げ、標準的な PowerShell スクリプトの慣習から外れます。

```powershell
FUNCTION get-servicestatus {
    PARAM($servicename)
    IF ($servicename) {
        get-service -name $servicename
    }
}
```

### コマンド名・パラメータ名は省略しない

#### 目的・背景
エイリアス（`ls`, `ps` など）は対話型操作には便利ですが、スクリプト内では可読性を著しく下げます。また、他者の環境でエイリアスが変更されている可能性も考慮し、常に正式名称（フルネーム）を使用します。

#### 規約
* エイリアスは避け、コマンドレットおよびパラメータの正式名称を使用する。

#### 良い例
フルネームを使用しており、誰が見ても動作が明確です。

```powershell
Get-Process -Name Explorer
```

#### 悪い例
エイリアスを使用しており、初見での理解を妨げます。

```powershell
ps Explorer
```


## コードのレイアウトとフォーマット

### One True Brace Style (1TBS)

#### 目的・背景
PowerShell のパーサーは、行末に `{` がある場合に「まだコマンドが続いている」と判断します。`{` を次の行の先頭に置くと、特定の構文（特に `if` や `else`）において、パーサーが前の行を完結したものと誤認し、エラーや予期せぬ動作を引き起こす可能性があります。

#### 規約
* 開きブレース `{` は行末に配置する。
* 閉じブレース `}` は新しい行の先頭に配置する。
* `else`, `catch`, `finally` キーワードは閉じブレース `}` と同じ行に配置する。

#### 良い例
PowerShell の推奨されるスタイルです。行末のブレースにより、継続行として正しく認識されます。

```powershell
if ($condition) {
    # 処理
} else {
    # 別の処理
}
```

#### 悪い例
C# などで見られる形式ですが、PowerShell では `else` の前でステートメントが終了したとみなされるリスクがあります。

```powershell
if ($condition)
{
    # 処理
}
else
{
    # 別の処理
}
```

### インデント

#### 目的・背景
コードの階層構造を視覚的に分かりやすくし、メンテナンス時のミスを減らします。PowerShell コミュニティではスペース4つが標準的です。

#### 規約
* インデントにはスペース4つを使用する。
* タブ文字の使用は避ける。

#### 良い例
スペース4つで階層が整えられており、一目で構造が理解できます。

```powershell
foreach ($item in $list) {
    if ($item.IsActive) {
        Do-Something -Param $item
    }
}
```

#### 悪い例
インデントが浅すぎたり、不揃いであったりすると、ロジックの範囲が把握しづらくなります。

```powershell
foreach ($item in $list) {
  if ($item.IsActive) {
        Do-Something -Param $item
  }
}
```

### 最大行長

#### 目的・背景
1行が長すぎると、横スクロールが必要になり可読性が低下します。スプラッティングなどを活用して適切に改行しましょう。

#### 規約
* 1行は115文字以内に収める。

#### 良い例
ハッシュテーブル（スプラッティング）を使用して、長いコマンドを複数行に分割しています。

```powershell
$Params = @{
    Name    = "Explorer"
    Verbose = $true
}
Get-Process @Params
```

### 空行とホワイトスペース

#### 目的・背景
適切な余白を設けることで、コードの論理的な区切りを明確にし、視認性を高めます。

#### 規約
* 関数の定義前後には1行の空行を入れる。
* 行末の不要なスペースは削除する。
* 演算子（`=`, `+`, `-` など）やパラメータの前後にスペースを入れる。

#### 良い例
関数の前後に1行の空行を入れることで、視覚的な区切りを明確にした例です。

```powershell
function Get-Value {
    $Result = 5 + 3
    Write-Output $Result
}

Get-Value
```

### セミコロンを避ける

#### 目的・背景
PowerShell では改行がステートメントの区切りとして機能するため、行末のセミコロンは冗長です。

#### 規約
* 行末のセミコロンを使用しない。

#### 良い例
セミコロンを使わず、シンプルに記述されています。

```powershell
$Options = @{
    Margin  = 2
    Padding = 2
}
```

#### 悪い例
不要なセミコロンが含まれており、コードがノイズで汚れて見えます。

```powershell
$Options = @{
    Margin = 2;
    Padding = 2;
};
```


## 関数

### CmdletBinding とブロック順序

#### 目的・背景
`[CmdletBinding()]` を付与することで、関数は「高度な関数」となり、`-Verbose`, `-Debug`, `-ErrorAction` などの共通パラメータを自動的に継承します。ツールとして公開する関数や、パイプライン入力を処理する関数では、これらを使用して標準コマンドレットと同じ操作性を提供することが推奨されます。

#### 規約
* モジュールで公開する関数や、共通パラメータのサポートが必要な関数では `[CmdletBinding()]` で開始する。
* パイプライン入力を処理し、`process {}` ブロックを使用する場合は `[CmdletBinding()]` を付与する。
* `param()`, `begin`, `process`, `end` の順で記述する。

#### 良い例
高度な関数の標準的な構造です。共通パラメータが有効になり、パイプライン処理にも対応可能です。

```powershell
function Invoke-Task {
    [CmdletBinding()]
    param()
    begin { }
    process { }
    end { }
}
```

#### 悪い例
`CmdletBinding` がないため、共通パラメータが利用できず、ロジックが適切なブロックに分かれていないため保守性が低下します。

```powershell
function Invoke-Task {
    param()
    Write-Host "Doing something"
}
```

### 基本的な関数

#### 目的・背景
PowerShell は「パイプライン」を通じてオブジェクトを逐次渡していく設計（ストリーミング）になっています。他言語の `return` は「値を返して即座に終了」しますが、PowerShell では **キャプチャされなかったすべての出力** がパイプラインに送られます。
「データを出力する行為（Write-Output）」と「関数を終了する行為（return）」を使い分けることで、意図が明確になり、予期せぬ戻り値の混入を防ぐことができます。

#### 規約
* 明示的にデータを出力したい場合は **`Write-Output`** を使用する。
* **`return`** は、条件分岐などによる **「早期終了（関数を抜けること）」** を目的とする場合にのみ使用する。
* 関数名とパラメータの括弧の間にはスペースを入れる。

#### 良い例
早期終了のための `return` と、明示的な出力のための `Write-Output` が使い分けられています。

```powershell
function Get-UserStatus ($UserId) {
    if (-not $UserId) {
        return
    }

    $Status = Get-RemoteStatus -Id $UserId
    Write-Output $Status
}
```

#### 悪い例
`return` を出力目的で使用しており、PowerShell の出力挙動と混同しやすくなっています。また、パラメータのスペースが欠落しています。

```powershell
function Get-UserStatus($UserId){
    if ($UserId) {
        $Status = Get-RemoteStatus -Id $UserId
        return $Status
    }
}
```

### 高度な関数

#### 目的・背景
標準的なコマンドレットと同じ挙動をさせるために、承認済みの動詞を使用し、`OutputType` で出力型を明示します。これにより、**エディタ上での入力補完（IntelliSense）の精度が向上し、関数の戻り値を呼び出し側で予測しやすくなります。**

#### 規約
* 名前は `<承認済みの動詞>-<名詞>` 形式にする（`Get-Verb` で確認可能）。
* 公開関数や再利用可能なツール、パイプライン入力を処理する関数では、原則として `[CmdletBinding()]` を使用する。
* `process {}` ブロック内でオブジェクトを返す。
* `OutputType` を指定する。

#### 良い例
承認済みの動詞を使い、出力型が明示された高品質な関数の例です。

```powershell
function Get-SampleData {
    [CmdletBinding()]
    [OutputType([psobject])]
    param (
        [Parameter(Mandatory=$true)]
        [int]$Id
    )
    process {
        [PSCustomObject]@{
            ID   = $Id
            Time = Get-Date
        }
    }
}
```

#### 悪い例
承認されていない動詞の使用や、出力型が不明瞭な例です。

```powershell
function Do-Data {
    param ($Id)
    New-Object -TypeName psobject -Property @{ ID = $Id }
}
```


## ドキュメントとコメント

### コメントの基本

#### 目的・背景
コメントは「何をしているか」ではなく「なぜそうしているか（意図）」を伝えるために使用します。コードそのものが「何」を説明するように書き、どうしても説明が必要な複雑なロジックに対して補足を行います。

#### 規約
* コメントは常に最新に保つ。
* 理由（なぜそうしたか）を簡潔に書く。

#### 良い例
コードからは読み取れない「理由（意図）」が説明されています。

```powershell
# 特定のデバイスドライバとの競合を避けるため、再試行の間隔を3秒に設定
Start-Sleep -Seconds 3
```

#### 悪い例
コードの内容をそのままなぞっており、付加価値のないコメントです。

```powershell
# 3秒待機する
Start-Sleep -Seconds 3
```

### コメントベースのヘルプ

#### 目的・背景
標準的な形式（`<# ... #>`）で記述することで、**VS Code などのエディタ上で関数の説明やパラメータの意味がポップアップ表示（IntelliSense）されるようになります。** これにより、関数の定義箇所を都度確認しに行く手間が省け、呼び出し側での開発効率が大幅に向上します。

#### 規約
* 関数には必ず `<# ... #>` 形式のコメントベースのヘルプを記載する。
* 記述位置は **「関数の直前（外部）」** または **「関数の先頭（内部）」** とし、**プロジェクト内で統一** する。
* 概要（`.SYNOPSIS`）やパラメータの説明（`.PARAMETER`）を優先して記述する。

#### 良い例
エディタの支援機能を最大限に活用できる記述形式です。プロジェクトの規約に合わせて位置を統一します。

**パターン A: 関数の直前（外部）に記載**
```powershell
<#
.SYNOPSIS
    APIからデータを取得します。
#>
function Get-Data {
    param($Id)
}
```

**パターン B: 関数の先頭（内部）に記載**
```powershell
function Get-Data {
    <#
    .SYNOPSIS
        APIからデータを取得します。
    #>
    param($Id)
}
```

#### 悪い例
独自のコメント形式（`#`）では、エディタの入力補完機能が働きません。利用者は関数の定義場所までソースコードをスクロールして内容を確認する必要があります。

```powershell
# APIからデータを取得する関数です
# 取得対象のユニークなIDを指定します
function Get-Data {
    param($Id)
}
```

### インラインコメント

#### 目的・背景
設定値やパラメータの意図を簡潔に補足します。乱用を避け、整列させることで視認性を保ちます。

#### 規約
* インラインコメントは、ハッシュテーブルのプロパティ説明などに限定し、整列させて記述する。

```powershell
$Options = @{
    Margin  = 2      # UI調整用の余白
    Padding = 2      # テキスト周りの余白
}
```


## ベストプラクティスと安全性

### バッククォートを避ける

#### 目的・背景
バッククォート（`）による行連結は、末尾に目に見えないスペースが入るだけで機能しなくなり、デバッグが非常に困難なバグの原因となります。スプラッティング（ハッシュテーブルによるパラメータ渡し）を使用することで、安全かつ構造的に長いコマンドを記述できます。

#### 規約
* 改行目的でのバッククォート（`）の使用を避ける。

#### 良い例
スプラッティングにより、安全かつ視認性高く記述されています。

```powershell
$Params = @{
    ClassName   = "Win32_LogicalDisk"
    Filter      = "DriveType=3"
    ErrorAction = "Stop"
}
Get-CimInstance @Params
```

#### 悪い例
バッククォートを使用しており、末尾にスペースが混入すると動作しなくなる不安定なコードです。

```powershell
Get-CimInstance `
    -ClassName "Win32_LogicalDisk" `
    -Filter "DriveType=3"
```

### パスは明示的に記述する

#### 目的・背景
相対パスは実行時のカレントディレクトリに依存するため、スクリプトの配置場所が変わると壊れる可能性があります。`$PSScriptRoot` を使うことで、スクリプト自身の場所を起点とした確実なパス指定が可能です。

#### 規約
* 相対パス（`.\`）ではなく `$PSScriptRoot` を使用してパスを明示する。

#### 良い例
自身の配置場所を基準にしているため、どこから実行しても正しく動作します。

```powershell
Get-Content -Path "$PSScriptRoot\config.json"
```

#### 悪い例
実行時のカレントディレクトリに依存するため、実行環境によってエラーになるリスクがあります。

```powershell
Get-Content -Path ".\config.json"
```

### ~ の使用を避ける

#### 目的・背景
チルダ（`~`）は PowerShell のプロバイダーやホストによって解釈が異なる場合があり、予期せぬディレクトリを指す可能性があります。環境変数や `$HOME` 変数を使う方が確実です。

#### 規約
* ホームディレクトリの指定には `${Env:UserProfile}` や `$HOME` を使用する。

#### 良い例
変数を介してホームディレクトリを確実に指定しています。

```powershell
cd $HOME
```

#### 悪い例
解釈が環境に左右される可能性がある記号を使用しています。

```powershell
cd ~
```


## 結論

このスタイルガイドに従うことで、PowerShell スクリプトの可読性と保守性が向上し、チームでの共同作業がスムーズになります。

詳細は [PowerShell Practice and Style Guide](https://github.com/PoshCode/PowerShellPracticeAndStyle/tree/master/Style-Guide) を参照してください。
