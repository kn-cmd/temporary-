set BASEDIR=%~dp0


set PS1=%BASEDIR%Test.ps1

REM powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%PS1%" -Verbose 
REM powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%PS1%"
    powershell.exe -NoProfile -STA -ExecutionPolicy Bypass -File "%PS1%"

pause

