﻿# 1. モジュールのインポート
Import-Module ".\UnitFolder\UnitFolder.psd1"

# 2. テスト環境の設定
$testRootDir = Join-Path $PSScriptRoot "TestEnv"
if (-not (Test-Path $testRootDir)) { 
    Write-Error "テスト環境が初期化されていません。先に InitTestEnv.bat を実行してください。"
    return
}

$dirSettings = @{
    Work        = Join-Path $testRootDir "01_Work"
    Pending     = Join-Path $testRootDir "11_Pending"
    Returned    = Join-Path $testRootDir "12_Returned"
    Approved    = Join-Path $testRootDir "21_Approved"
    BatchQueue  = Join-Path $testRootDir "22_BatchQueue"
    Processing  = Join-Path $testRootDir "23_Processing"
    Completed   = Join-Path $testRootDir "31_Completed"
    BatchResult = Join-Path $testRootDir "32_BatchResult"
    Archive     = Join-Path $testRootDir "33_Archive"
}

$structure = @{ 
    SourceFile    = "raw.csv"
    ProcessedFile = "data.csv" 
    ArchiveFile   = "result.csv"
    MetadataFile  = "fileinfo.json"
}
$template = "{Timestamp}__{UserID}__{Category}__{UnitID}"

# ダミーファイルの作成
$dummySource = Join-Path $testRootDir "mydata.csv"
"Col1,Col2`nVal1,Val2" | Out-File $dummySource -Encoding UTF8

# 3. 新規作成（初期化コマンドを使用）
Write-Host "`n--- 3. 新規作成 ---"
$orchestrator = New-UnitFolderOrchestrator -Config $dirSettings -Structure $structure -NamingTemplate $template
$unit = $orchestrator.NewUnitFolder(@{ UserID="UserA"; Category="経費精算" })
Write-Host "Created: $($unit.Path)"

$unit.Upload($dummySource, "SourceFile")
# 仕様変更：承認（Batch投入）には加工済みデータが必須なため、アップロードをシミュレート
$unit.Upload($dummySource, "ProcessedFile")
Write-Host "Uploaded source and processed files."

# アップロードに使用したダミーファイルの削除
Remove-Item $dummySource -Force
Write-Host "Deleted local dummy file: $dummySource"


# 4. 申請実行
Write-Host "`n--- 4. 申請実行 ---"
$unit.ExecuteAction("Submit", "申請完了", $null)
Write-Host "Status: $($unit.Status), Path: $($unit.Path)"

# 5. 承認操作
Write-Host "`n--- 5. 承認操作 ---"
$batchManager = $orchestrator.GetBatchManager()
$sideEffect = { $batchManager.AddToBatch($unit) }.GetNewClosure()
$unit.ExecuteAction("Approve", "管理者承認完了", $sideEffect)
Write-Host "Status: $($unit.Status), Path: $($unit.Path)"
Write-Host "Batch Queue: $(Get-ChildItem $dirSettings.BatchQueue | Select-Object -ExpandProperty Name)"

# 6. 管理フロー（返却テスト用にもう一つ作成）
Write-Host "`n--- 6. 管理フロー（返却） ---"
$unit2 = $orchestrator.NewUnitFolder(@{ UserID="UserB"; Category="備品購入" })
$unit2.ExecuteAction("Submit", "申請します", $null)

$pendingList = $orchestrator.GetUnitInfoList("Pending")
Write-Host "Pending List count: $($pendingList.Count)"
$target = $pendingList | Where-Object { $_.UserID -eq "UserB" } | Select-Object -First 1

if ($null -ne $target) {
    $operator = $orchestrator.GetUnitFolder($target._Path)
    $operator.ExecuteAction("Return", "書類不備のため差し戻します", $null)
    Write-Host "Returned: $($operator.FolderName), Status: $($operator.Status)"
}

# 7. 完了同期
Write-Host "`n--- 7. 完了同期 ---"
$completedFile = Join-Path $dirSettings.Completed ($unit.FolderName + ".csv")
"dummy result" | Out-File $completedFile

Write-Host "Simulated batch completion for $($unit.FolderName)"
$batchManager.SyncArchive()

$archiveList = Get-ChildItem $dirSettings.Archive
Write-Host "Archive count: $($archiveList.Count)"
if ($archiveList.Count -gt 0) {
    Write-Host "Archived folder: $($archiveList[0].Name)"
}

Write-Host "`n--- Test Finished ---"
