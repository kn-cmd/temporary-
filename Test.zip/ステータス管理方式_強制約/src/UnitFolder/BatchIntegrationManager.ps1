﻿class BatchIntegrationManager {
    [StatusConfig]$Config
    [UnitFolderStructure]$Structure

    BatchIntegrationManager([StatusConfig]$config, [UnitFolderStructure]$structure) {
        $this.Config    = $config
        $this.Structure = $structure
    }
    
[void] AddToBatch($unit) {
    $destDir = $this.Config.BatchQueue
    if (-not (Test-Path $destDir)) {
        throw [UnitRelationException]::new("Batch queue directory not found: $destDir", "SYSTEM")
    }

    $sourcePath = Join-Path $unit.Path $this.Structure.ProcessedFile

    # 内部的な準備不足は UnitStatusException とする
    if (-not (Test-Path $sourcePath)) {
        throw [UnitStatusException]::new("Processed data file not found. Unit is not ready for batch integration.", $unit.FolderName)
    }

    $extension = [System.IO.Path]::GetExtension($sourcePath)
    $destName = $unit.FolderName + $extension
    $destPath = Join-Path $destDir $destName

    Copy-Item $sourcePath $destPath -Force
}

    [void] RemoveFromBatch($unit) {
        $destDir = $this.Config.BatchQueue
        if (-not (Test-Path $destDir)) {
            throw [UnitRelationException]::new("Batch queue directory not found: $destDir", "SYSTEM")
        }
        
        $pattern = Join-Path $destDir ($unit.FolderName + ".*")
        if (Test-Path $pattern) {
            Remove-Item $pattern -Force
        }
    }

    [void] SyncArchive() {
        $completedDir = $this.Config.Completed
        if (-not (Test-Path $completedDir)) { 
            throw [UnitRelationException]::new("Batch completion directory not found: $completedDir", "SYSTEM")
        }

        # アーカイブ先の存在確認（厳格な構成管理のため、自動作成せず例外をスロー）
        $archiveParent = $this.Config.Archive
        if (-not (Test-Path $archiveParent)) { 
            throw [UnitRelationException]::new("Archive storage directory not found: $archiveParent", "SYSTEM")
        }

        $faults = [System.Collections.Generic.List[string]]::new()

        # 1. Completed を基準にループ
        foreach ($completedFile in Get-ChildItem $completedDir -File) {
            $unitName = [System.IO.Path]::GetFileNameWithoutExtension($completedFile.Name)
            if ([string]::IsNullOrWhiteSpace($unitName)) { continue }

            try {
                # 2. Approved から対応するユニットを探す
                $approvedPath = Join-Path $this.Config.Approved $unitName
                if (-not (Test-Path $approvedPath)) {
                    $faults.Add("Relation broken: matching unit folder not found in Approved: $unitName")
                    continue
                }

                # 3. Archive へ移動 (System sync) - 直接物理操作
                $newPath = Join-Path $archiveParent $unitName
                Move-Item $approvedPath $newPath -Force -ErrorAction Stop
                
                # 4. Completed ファイルをユニットフォルダ内（ArchiveFile の場所）へ戻す
                $resultDestPath = Join-Path $newPath $this.Structure.ArchiveFile
                Move-Item $completedFile.FullName $resultDestPath -Force
            }
            catch {
                $faults.Add("System error during archiving unit '$unitName': $($_.Exception.Message)")
            }
        }

        # すべての処理完了後に、不備があった場合はまとめてエラーをスロー
        if ($faults.Count -gt 0) {
            $combinedMessage = "SyncArchive completed with errors:`n" + ($faults -join "`n")
            throw [UnitRelationException]::new($combinedMessage, "SYSTEM")
        }
    }
}
