﻿# =============================================================================
# ユーティリティ関数の定義
# =============================================================================

<#
.SYNOPSIS
    テンプレートとハッシュテーブルから文字列を組み立てます。
#>
function Format-TemplateString {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Template,

        [Parameter(Mandatory=$true)]
        [hashtable]$Values
    )

    $result = $Template
    # ハッシュテーブルのキーを使って、テンプレートの {Key} を順番に置換する
    foreach ($key in $Values.Keys) {
        $result = $result.Replace("{$key}", $Values[$key])
    }

    return $result
}

<#
.SYNOPSIS
    プレースホルダを含むテンプレートから、パース用の正規表現オブジェクトを生成します。
#>
function New-TemplateRegex {
    param (
        [Parameter(Mandatory=$true)]
        [string]$Template
    )

    # 1. テンプレート文字列を正規表現用にエスケープ
    $escaped = [regex]::Escape($Template)

    # 2. プレースホルダ {Key} を名前付きキャプチャ (?<Key>.*?) に変換
    # ※ \? は環境による } のエスケープ差異を吸収するため
    $pattern = "^" + ($escaped -replace '\\\{(\w+)\\?\}', '(?<$1>.*?)') + "$"
    
    # 3. コンパイルオプションを付与して正規表現オブジェクトを生成・返却
    $regexObject = [regex]::new($pattern, [System.Text.RegularExpressions.RegexOptions]::Compiled)
    
    return $regexObject
}

<#
.SYNOPSIS
    正規表現オブジェクトを使用して文字列をパースし、キャプチャ結果を返します。
#>
function ConvertFrom-TemplateString {
    param (
        [Parameter(Mandatory=$true)]
        [regex]$Regex,

        [Parameter(Mandatory=$true)]
        [string]$Text
    )

    $match = $Regex.Match($Text)
    $result = @{}

    # マッチした場合、キャプチャした値をハッシュテーブルに詰める
    if ($match.Success) {
        foreach ($groupName in $Regex.GetGroupNames()) {
            if ($groupName -ne "0") {
                $result[$groupName] = $match.Groups[$groupName].Value
            }
        }
    }

    return $result
}
