﻿class UnitFolderException : System.Exception {
    UnitFolderException([string]$message) : base($message) {}
    UnitFolderException([string]$message, [System.Exception]$innerException) : base($message, $innerException) {}
}

class UnitOperationException : UnitFolderException {
    [string]$UnitName
    UnitOperationException([string]$message, [string]$unitName) : base($message) {
        $this.UnitName = $unitName
    }
    UnitOperationException([string]$message, [string]$unitName, [System.Exception]$innerException) : base($message, $innerException) {
        $this.UnitName = $unitName
    }
}

class UnitArgumentException : UnitFolderException {
    UnitArgumentException([string]$message) : base($message) {}
}

class UnitStatusException : UnitOperationException {
    UnitStatusException([string]$message, [string]$unitName) : base($message, $unitName) {}
}

class UnitRelationException : UnitOperationException {
    UnitRelationException([string]$message, [string]$unitName) : base($message, $unitName) {}
}
