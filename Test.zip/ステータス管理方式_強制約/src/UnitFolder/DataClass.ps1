﻿class DataClassBase {
    DataClassBase([hashtable]$data) {
        $properties = $this.psobject.Properties | Where-Object { $_.MemberType -eq 'Property' }
        foreach ($prop in $properties) {
            $name = $prop.Name
            try {
                $this.$name = $data[$name]
            }
            catch {
                throw "Property validation error [$name]: $($_.Exception.Message)"
            }
        }
    }
    DataClassBase() {}
}

class StatusConfig : DataClassBase {
    [ValidateNotNullOrEmpty()][string]$Work
    [ValidateNotNullOrEmpty()][string]$Pending
    [ValidateNotNullOrEmpty()][string]$Returned
    [ValidateNotNullOrEmpty()][string]$Approved
    [ValidateNotNullOrEmpty()][string]$Completed
    [ValidateNotNullOrEmpty()][string]$Archive

    [string]$BatchQueue
    [string]$Processing
    [string]$BatchResult

    StatusConfig([hashtable]$data) : base($data) {}
}

class UnitFolderStructure : DataClassBase {
    [ValidateNotNullOrEmpty()][string]$SourceFile
    [ValidateNotNullOrEmpty()][string]$MetadataFile

    [string]$ProcessedFile
    [string]$ArchiveFile

    UnitFolderStructure([hashtable]$data) : base($data) {}
}
