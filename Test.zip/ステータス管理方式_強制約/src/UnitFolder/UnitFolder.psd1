﻿@{
    ModuleVersion = '1.0.0'
    GUID = 'a6b8c9d0-1234-5678-90ab-cdef12345678'
    Author = 'Gemini CLI'
    CompanyName = 'Unknown'
    Copyright = '(c) 2026 Gemini CLI. All rights reserved.'
    RootModule = ''
    
    # 依存関係順にすべて読み込む（クラス定義が関数を参照するため、関数定義もここに含める）
    ScriptsToProcess = @(
        'UnitFolderException.ps1',
        'DataClass.ps1',
        'ParsableTemplate.ps1',
        'BatchIntegrationManager.ps1',
        'UnitFolderEngine.ps1'
    )

    # シンプルマニフェスト方針：内部関数はエクスポートせず、API（クラスと公開関数）のみ利用可能にする
    FunctionsToExport = @('New-UnitFolderOrchestrator')
    CmdletsToExport   = @()
    VariablesToExport = @()
    AliasesToExport   = @()
}
