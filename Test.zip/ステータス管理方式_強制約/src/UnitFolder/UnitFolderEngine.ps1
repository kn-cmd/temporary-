﻿class UnitFolderOperator {
    [string]$FolderName
    [PSCustomObject]$FolderInfo
    [string]$Status
    [string]$Path
    [StatusConfig]$Config
    [UnitFolderStructure]$Structure

    # 状態遷移ルールの定数管理
    static [hashtable]$Transitions = @{
        Submit      = @{ From = @("Work");               To = "Pending" }
        Approve     = @{ From = @("Pending");            To = "Approved" }
        Return      = @{ From = @("Pending");            To = "Returned" }
        Resubmit    = @{ From = @("Returned");           To = "Pending" }
        Withdraw    = @{ From = @("Pending", "Returned"); To = $null }
        UndoApprove = @{ From = @("Approved");           To = "Pending" }
    }

    UnitFolderOperator([string]$path, [StatusConfig]$config, [UnitFolderStructure]$structure, [PSCustomObject]$info) {
        $this.Path = $path
        $this.FolderName = [System.IO.Path]::GetFileName($path)
        $this.Config = $config
        $this.Structure = $structure
        $this.FolderInfo = $info
        
        # Resolve Status from Config paths
        $parentPath = [System.IO.Path]::GetDirectoryName($path)
        $this.Status = "Unknown"
        
        # 属性情報を事前に抽出して繰り返し処理（リフレクション回数を最小化）
        $statusProps = $config.psobject.Properties.Where({ $_.MemberType -eq 'Property' -and $_.Value })
        foreach ($prop in $statusProps) {
            if ($parentPath -eq $prop.Value) {
                $this.Status = $prop.Name
                break
            }
        }
    }

    [PSCustomObject] GetMetadata() {
        $metaPath = Join-Path $this.Path $this.Structure.MetadataFile
        if (Test-Path $metaPath) {
            try {
                $content = Get-Content $metaPath -Raw -Encoding UTF8
                return $content | ConvertFrom-Json
            } catch {
                return $null
            }
        }
        return $null
    }

    [void] Upload([string]$filePath, [string]$role) {
        $destName = switch ($role) {
            "SourceFile" { $this.Structure.SourceFile }
            "ProcessedFile" { $this.Structure.ProcessedFile }
            "MetadataFile" { $this.Structure.MetadataFile }
            default { throw [UnitArgumentException]::new("Invalid role: $role") }
        }
        $destPath = Join-Path $this.Path $destName
        Copy-Item $filePath $destPath -Force
    }

    [void] ExecuteAction([string]$action, [string]$comment, [scriptblock]$sideEffect) {
        # ルールの取得
        $rule = [UnitFolderOperator]::Transitions[$action]
        if ($null -eq $rule) { throw [UnitArgumentException]::new("Invalid action: $action") }

        # ステータス遷移の妥当性チェック
        if ($this.Status -notmatch $rule.From) {
            throw [UnitStatusException]::new("Invalid status transition for $action from $($this.Status)", $this.FolderName)
        }

        $targetStatus = $rule.To
        $isDelete = ($null -eq $targetStatus)

        $oldPath = $this.Path
        $oldStatus = $this.Status

        # 2. Physical Operation (Move or Isolate for Delete)
        try {
            if ($isDelete) {
                # 削除前に Work フォルダへ退避（ロールバック可能性を担保）
                $tempName = "$($this.FolderName).$([System.Guid]::NewGuid().ToString().Substring(0,8)).deleting"
                $tempPath = Join-Path $this.Config.Work $tempName
                Move-Item $this.Path $tempPath -Force -ErrorAction Stop
                $this.Path = $tempPath
            } else {
                $targetDir = $this.Config.$targetStatus
                if (-not (Test-Path $targetDir)) { New-Item -ItemType Directory -Path $targetDir -Force | Out-Null }
                $newPath = Join-Path $targetDir $this.FolderName
                Move-Item $this.Path $newPath -Force -ErrorAction Stop
                $this.Path = $newPath
                $this.Status = $targetStatus
            }
        } catch {
            throw [UnitOperationException]::new("Physical operation failed: $($_.Exception.Message)", $this.FolderName, $_.Exception)
        }

        # 3. Side Effect
        if ($null -ne $sideEffect) {
            try {
                $sideEffect.Invoke()
            } catch {
                # 失敗時は元の場所・名前に戻す（ロールバック）
                Move-Item $this.Path $oldPath -Force
                $this.Path = $oldPath
                $this.Status = $oldStatus
                throw [UnitOperationException]::new("Side effect failed: $($_.Exception.Message)", $this.FolderName, $_.Exception)
            }
        }

        # 4. Cleanup or Logging
        if ($isDelete) {
            # サイドエフェクト成功後、Work フォルダから物理削除
            try {
                Remove-Item $this.Path -Recurse -Force -ErrorAction Stop
            } catch {
                # 最終削除の失敗は例外にせず、孤立ファイルとして Housekeeping に任せる
            }
        } else {
            try {
                $this.AddLog($action, $comment, [System.Environment]::UserName)
            } catch { }
        }
    }

    [void] AddLog([string]$action, [string]$comment, [string]$executor) {
        $now = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
        $hostName = [System.Net.Dns]::GetHostName()
        
        $metaPath = Join-Path $this.Path $this.Structure.MetadataFile
        $metadata = $this.GetMetadata()

        # 1. メタデータが未存在の場合は初期構造を作成
        if ($null -eq $metadata) {
            $metadata = [PSCustomObject]@{
                UnitID        = $this.FolderInfo.UnitID
                Category      = $this.FolderInfo.Category
                CreatedAt     = $now
                Owner         = $executor
                Host          = $hostName
                ExtendedInfo  = @{}
                CurrentStatus = $this.Status
                Comment       = $comment
                History       = @()
            }
        }

        # 2. ログエントリの作成
        $logEntry = [PSCustomObject]@{
            Timestamp    = $now
            Action       = $action
            Executor     = $executor
            Host         = $hostName
            Comment      = $comment
            ExtendedInfo = @{}
        }

        # 3. 状態の同期と履歴への追加
        $history = [System.Collections.ArrayList]::new($metadata.History)
        $history.Add($logEntry) | Out-Null
        $metadata.History = $history.ToArray()
        
        $metadata.CurrentStatus = $this.Status
        $metadata.Comment       = $comment

        # 4. 物理ファイルへの保存
        $metadata | ConvertTo-Json -Depth 32 | Out-File $metaPath -Encoding UTF8
    }
}

class UnitFolderOrchestrator {
    [StatusConfig]$Config
    [UnitFolderStructure]$Structure
    [string]$NamingTemplate
    [regex]$NamingRegex

    UnitFolderOrchestrator([hashtable]$configData, [hashtable]$structureData, [string]$template) {
        $this.Config    = [StatusConfig]::new($configData)
        $this.Structure = [UnitFolderStructure]::new($structureData)
        
        $this.NamingTemplate = $template
        $this.NamingRegex = New-TemplateRegex -Template $template
    }

    # BatchManager の提供（型情報を隠蔽しつつ機能を提供）
    [Object] GetBatchManager() {
        return [BatchIntegrationManager]::new($this.Config, $this.Structure)
    }

    [UnitFolderOperator] NewUnitFolder([hashtable]$attributes) {
        if (-not $attributes.ContainsKey("Timestamp")) { $attributes["Timestamp"] = (Get-Date -Format "yyyyMMdd-HHmmss") }
        if (-not $attributes.ContainsKey("UnitID")) { $attributes["UnitID"] = [System.Guid]::NewGuid().ToString().Substring(0,8) }
        
        $folderName = Format-TemplateString -Template $this.NamingTemplate -Values $attributes

        $workDir = $this.Config.Work
        if (-not (Test-Path $workDir)) { New-Item -ItemType Directory -Path $workDir -Force | Out-Null }
        
        $unitPath = Join-Path $workDir $folderName
        if (-not (Test-Path $unitPath)) { New-Item -ItemType Directory -Path $unitPath -Force | Out-Null }
        
        $info = [PSCustomObject]$attributes
        $operator = [UnitFolderOperator]::new($unitPath, $this.Config, $this.Structure, $info)
        
        $operator.AddLog("Create", "Initial Creation", [System.Environment]::UserName)
        
        return $operator
    }

    [UnitFolderOperator] GetUnitFolder([string]$path) {
        $folderName = [System.IO.Path]::GetFileName($path)
        $info = $this.ParseFolderName($folderName)
        return [UnitFolderOperator]::new($path, $this.Config, $this.Structure, $info)
    }

    [PSCustomObject[]] GetUnitInfoList([string]$status) {
        $dir = $this.Config.$status
        if (-not (Test-Path $dir)) { return @() }
        
        $results = [System.Collections.Generic.List[PSCustomObject]]::new()
        Get-ChildItem $dir -Directory | ForEach-Object {
            $info = $this.ParseFolderName($_.Name)
            $info | Add-Member -MemberType NoteProperty -Name "_Path" -Value $_.FullName
            $info | Add-Member -MemberType NoteProperty -Name "_FolderName" -Value $_.Name
            $results.Add($info)
        }
        return $results.ToArray()
    }

    [PSCustomObject] ParseFolderName([string]$folderName) {
        $result = ConvertFrom-TemplateString -Regex $this.NamingRegex -Text $folderName
        return [PSCustomObject]$result
    }
}

function New-UnitFolderOrchestrator {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)][hashtable]$Config,
        [Parameter(Mandatory=$true)][hashtable]$Structure,
        [Parameter(Mandatory=$true)][string]$NamingTemplate
    )
    return [UnitFolderOrchestrator]::new($Config, $Structure, $NamingTemplate)
}
