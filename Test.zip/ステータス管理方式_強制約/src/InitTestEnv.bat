@echo off
setlocal
set BASEDIR=%~dp0
set TESTENV=%BASEDIR%TestEnv

echo Initializing Test Environment at %TESTENV%...

if exist "%TESTENV%" (
    echo Cleaning existing Test Environment...
    rmdir /s /q "%TESTENV%"
)

echo Creating directories...
mkdir "%TESTENV%"
mkdir "%TESTENV%\01_Work"
mkdir "%TESTENV%\11_Pending"
mkdir "%TESTENV%\12_Returned"
mkdir "%TESTENV%\21_Approved"
mkdir "%TESTENV%\22_BatchQueue"
mkdir "%TESTENV%\23_Processing"
mkdir "%TESTENV%\31_Completed"
mkdir "%TESTENV%\32_BatchResult"
mkdir "%TESTENV%\33_Archive"

echo Initialization complete.
pause
endlocal
