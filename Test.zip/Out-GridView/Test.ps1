﻿# 必要なアセンブリとモジュールを読み込み
Add-Type -AssemblyName System.Windows.Forms
Import-Module -Name ".\WPFUI.psm1" -Force

# --- メインとなるWindowsフォームを作成 ---
$Form = New-Object System.Windows.Forms.Form
$Form.Text = "リファクタリングされた実装"
$Form.StartPosition = "CenterScreen"
$Form.Size = [System.Drawing.Size]::new(450, 200)

# Label, Buttonの作成
$Label = New-Object System.Windows.Forms.Label; $Label.Text = "下のボタンを押すと、定義済みの関数を使って安全にOut-GridViewが起動します。"; $Label.Dock = "Top"; $Label.AutoSize = $true; $Label.Padding = [System.Windows.Forms.Padding]::new(10)
$Button = New-Object System.Windows.Forms.Button; $Button.Text = "関数経由でGridViewを表示"; $Button.Dock = "Bottom"; $Button.Height = 50

# --- 表示したいデータ ---
$data = @(
    [PSCustomObject]@{ "社員番号" = "001"; "氏名" = "山田 太郎"; "部署" = "営業部" }
    [PSCustomObject]@{ "社員番号" = "002"; "氏名" = "佐藤 花子"; "部署" = "開発部" }
    [PSCustomObject]@{ "社員番号" = "003"; "氏名" = "鈴木 一郎"; "部署" = "人事部" }
    [PSCustomObject]@{ "社員番号" = "004"; "氏名" = "田中 美咲"; "部署" = "開発部" }
)

# --- ボタンがクリックされたときの処理 ---
$Button.add_Click({
    # モジュールからインポートした関数を呼び出す
    Start-GridView -InputObject $data -Title "社員一覧" -Wait
})


$Form.Controls.AddRange(@($Label, $Button))
$Form.ShowDialog()
