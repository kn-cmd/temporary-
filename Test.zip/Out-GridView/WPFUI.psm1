﻿<#
.SYNOPSIS
    独立した新規プロセスで Out-GridView を実行し、オブジェクトを表示します。
.DESCRIPTION
    UIのレイアウト崩れやフリーズを避けるため、Start-Processを使用してOut-GridViewを別プロセスで起動します。
    オブジェクトの受け渡しにはCLIXMLと一時ファイルを使用し、子プロセスの終了時に一時ファイルをクリーンアップします。
#>
function Start-GridView {
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)][object[]]$InputObject,
        [Parameter(Mandatory = $false)][string]$Title = "データ表示"
    )
    # CLIXML形式でオブジェクトを一時ファイルにエクスポート
    $tempFile = [System.IO.Path]::GetTempFileName()
    $InputObject | Export-Clixml -Path $tempFile
    # 子プロセスで実行するコマンドを定義
    $command = "
        try {
            Import-Clixml -Path '$tempFile' | Out-GridView -Title '$Title' -Wait
        }
        finally {
            Remove-Item -Path '$tempFile' -Force -ErrorAction SilentlyContinue
        }
    "
    # 別プロセスとしてPowerShellを起動
    $encodedCommand = [System.Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($command))
    Start-Process powershell.exe -ArgumentList "-NoProfile -EncodedCommand $encodedCommand" -WindowStyle Hidden
}

Export-ModuleMember -Function Start-GridViewProcess
