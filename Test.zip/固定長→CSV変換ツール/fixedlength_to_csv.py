"""
SJIS固定長ファイルをバイト数指定で分割し、CSV形式に変換するツールです。
入力ファイルがShift-JIS (CP932) であることを前提とし、出力も同形式を維持します。

【引数の構成】
■ 必須引数:
  input           入力ファイルパス (Shift-JIS固定長)
  output          出力ファイルパス (CSV形式)
  -l, --lengths   各項目のバイト長を順に指定 (例: -l 10 20 30)

■ 任意引数:
  -s, --sep_len   レコード間の改行等のバイト数 (CRLF=2, LF=1, なし=0 / デフォルト: 0)
  -d, --delimiter 出力の区切り文字 (デフォルト: , )

【特徴】
・デコード処理を行わないバイナリ処理のため、極めて高速に動作します。
・ジェネレータによる逐次処理により、巨大なファイルでもメモリを消費しません。

【制約】
・各項目の前後の「半角スペース (0x20)」を削除します。全角スペースは削除できません。
・データ内に区切り文字が含まれる場合でも、エスケープ処理は行いません。

実行例:
python script.py input.dat output.csv -l 10 20 30 -s 2
"""

import argparse
import sys
from pathlib import Path

def read_fixed_records_binary(path, field_lengths, sep_len):
    """固定長ファイルを1レコードずつバイト列のリストとして返すジェネレータ"""
    record_size = sum(field_lengths) + sep_len
    
    with path.open('rb') as f:
        while True:
            chunk = f.read(record_size)
            # 定義されたレコード長に満たない（終端等）場合は終了
            if not chunk or len(chunk) < sum(field_lengths):
                break
            
            row = []
            pos = 0
            for length in field_lengths:
                # バイト列のまま抽出し、半角スペース(0x20)をトリミング
                field = chunk[pos : pos + length].strip(b' ')
                row.append(field)
                pos += length
            yield row

def main(input_path, output_path, field_lengths, sep_len, delimiter):
    """バイナリモードで読み書きを行い、区切り文字を付与して出力する"""
    records = read_fixed_records_binary(input_path, field_lengths, sep_len)
    
    delim_b = delimiter.encode('ascii')
    newline_b = b'\n'

    with output_path.open('wb') as f_out:
        for row in records:
            # フィールドを結合して1行として書き出し
            line = delim_b.join(row) + newline_b
            f_out.write(line)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # 引数定義
    parser.add_argument('input')
    parser.add_argument('output')
    parser.add_argument('-l', '--lengths', type=int, nargs='+', required=True)
    parser.add_argument('-s', '--sep_len', type=int, default=0)
    parser.add_argument('-d', '--delimiter', default=',')
    
    args = parser.parse_args()

    input_p = Path(args.input)
    output_p = Path(args.output)

    if not input_p.exists():
        sys.exit(1)

    main(
        input_p, 
        output_p, 
        args.lengths, 
        args.sep_len, 
        args.delimiter
    )
    