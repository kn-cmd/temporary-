﻿# MessageBox用のWindows.Formsアセンブリをロード
Add-Type -AssemblyName System.Windows.Forms

# クリップボードのデータを取得
$Path = [string](Get-Clipboard)
$Path = $Path -replace "[\x00-\x1F]", ""
$Path = $Path.Trim().Trim('"', "'")

# パス判定
if ([string]::IsNullOrWhiteSpace($Path)) {
    [System.Windows.Forms.MessageBox]::Show("パスが指定されませんでした。")
    return
}
if (-not (Test-Path $Path)) {
    [System.Windows.Forms.MessageBox]::Show("存在しないパスが指定されました。： $Path")
    return
}

# エクスプローラー起動パラメータ設定
if (Test-Path -Path $Path -PathType Leaf) {
    # ファイルの場合、ファイルを選択した状態で開く
    $ArgumentList = "/select,`"$Path`""
} else {
    # フォルダの場合、フォルダを直接開く
    $ArgumentList = "`"$Path`""
}

# エクスプローラーで開く
Start-Process -FilePath explorer.exe -ArgumentList $ArgumentList
