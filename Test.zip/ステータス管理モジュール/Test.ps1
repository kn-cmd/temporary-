﻿# モジュールの読み込み
Import-Module "$PSScriptRoot\StatusManager.psm1" -Force

# 管理オブジェクトの取得
$Status = Get-StatusManager


# 管理オブジェクトからデータ取得
$current = $Status.Operation.Inputting
Write-Host "現在の状態: "  $current.Code  $current.DisplayName
# 出力結果 -> 現在の状態: [OP-0010] 入力中


# 外部要因で決まる現在の状態コード
$targetCode = "OP-0020" # 確認中

# 判定ロジックの実行
if ($Status.Actions.Submit.IsAllowed($targetCode)) {
    Write-Host "申請可能です"
} else {
    Write-Host "申請できません"
}
