"""
固定長ファイルのレコードサイズを変更するツールです。
各レコードの末尾を増やす（スペース埋め）、または減らす（切り捨て）することで
指定された出力レコード長に変更します。

【引数の構成】
■ 必須引数:
  input           入力ファイルパス
  output          出力ファイルパス
  --li            入力レコード長 (バイト数)
  --lo            出力レコード長 (バイト数)

■ 任意引数:
  -i, --incomplete_ending 不完全な終端の扱い (ignore, error, fill / デフォルト: error)

実行例:
python resize_fixedlength.py input.dat output.dat --li 100 --lo 120 -i error
"""

import argparse
import sys
from pathlib import Path

def resize_records_binary(path, li, lo, incomplete_ending):
    """入力レコード長 li を 出力レコード長 lo に変換して返すジェネレータ"""
    with path.open('rb') as f:
        while True:
            chunk = f.read(li)
            if not chunk:
                break
            
            # 定義されたレコード長に満たない場合の処理
            if len(chunk) < li:
                if incomplete_ending == 'error':
                    raise ValueError(f"不完全なレコードがファイル末尾に検出されました (長さ: {len(chunk)}, 期待値: {li})")
                elif incomplete_ending == 'ignore':
                    break
                elif incomplete_ending == 'fill':
                    # 不足分はそのままに、出力サイズ lo に合わせて調整を行う（下の処理へ進む）
                    pass
                else:
                    raise ValueError(f"incomplete_ending に不正な値が指定されました: {incomplete_ending}")

            # 出力サイズに合わせて調整
            # 1. lo > len(chunk) の場合、半角スペース(0x20)でパディング
            # 2. lo < len(chunk) の場合、末尾を切り捨て
            yield chunk.ljust(lo, b' ')[:lo]

def main(input_path, output_path, li, lo, incomplete_ending):
    """バイナリモードで読み書きを行い、レコードサイズを変更して出力する"""
    records = resize_records_binary(input_path, li, lo, incomplete_ending)

    with output_path.open('wb') as f_out:
        for rec in records:
            f_out.write(rec)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="固定長ファイルのレコードサイズを変更します。")
    # 引数定義
    parser.add_argument('input', help="入力ファイルパス")
    parser.add_argument('output', help="出力ファイルパス")
    parser.add_argument('--li', type=int, required=True, help="入力レコード長 (バイト数)")
    parser.add_argument('--lo', type=int, required=True, help="出力レコード長 (バイト数)")
    parser.add_argument('-i', '--incomplete_ending', choices=['ignore', 'error', 'fill'], default='error',
                        help="不完全な終端の扱い (ignore, error, fill / デフォルト: error)")
    
    args = parser.parse_args()

    input_p = Path(args.input)
    output_p = Path(args.output)

    if not input_p.exists():
        print(f"Error: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    try:
        main(
            input_p, 
            output_p, 
            args.li, 
            args.lo, 
            args.incomplete_ending
        )
        print(f"Successfully resized: {args.input} ({args.li} bytes) -> {args.output} ({args.lo} bytes)")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
