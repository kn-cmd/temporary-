# Java + PostgreSQL 開発環境構築ガイド (Dev Containers編)

この資料では、Docker を活用してローカル環境を汚さずに Java 開発環境を構築し、将来的に Spring Boot へスムーズに移行できる構成を目指します。

---

## 1. 目的と概要
*   **目的**: Java から PostgreSQL への接続を確認できる最小限の環境を構築する。
*   **技術構成**:
    *   **エディタ**: VS Code (Dev Containers 拡張)
    *   **実行環境**: Docker コンテナ (Java 17 or 21)
    *   **データベース**: PostgreSQL 15
    *   **ビルドツール**: Maven (将来の Spring 導入を容易にするため)
    *   **設定管理**: `.env` による環境変数管理

---

## 2. 事前準備
PCに以下がインストールされていることを確認してください。
1.  **Docker Desktop** (または Rancher Desktop 等)
2.  **Visual Studio Code**
3.  **VS Code 拡張機能**: `Dev Containers` (Microsoft製)

---

## 3. プロジェクトのディレクトリ構造
最初にローカルの任意の場所にフォルダを作成します。

```text
my-java-project/
├── .devcontainer/
│   ├── .env                 # 接続情報（Git管理外）
│   ├── .env.example         # .envのテンプレート（Git管理対象）
│   ├── devcontainer.json    # コンテナの設定
│   └── docker-compose.yml   # 複数コンテナ(Java, DB)の定義
├── .gitignore               # Git管理対象外の定義
├── pom.xml                  # Mavenの設定（ライブラリ管理）
└── src/
    └── main/
        └── java/
            └── com/example/App.java  # 実行コード
```

---

## 4. 設定ファイルの作成

### ① `.env` ファイル
機密情報と接続先を一箇所にまとめます。

```env
# Database Settings
DB_NAME=mydb
DB_USER=devuser
DB_PASSWORD=devpass
DB_PORT=5432

# Javaからの接続用 (サービス名の "db" で指定)
DB_URL=jdbc:postgresql://db:5432/mydb
```

### ② `.devcontainer/docker-compose.yml`
pgweb を含めた 3 つのサービスを定義します。

```yaml
services:
  app:
    image: mcr.microsoft.com/devcontainers/java:1-21-bullseye
    env_file: .env
    volumes:
      - ..:/workspaces/app:cached
    # コンテナを起動し続けるための設定
    command: sleep infinity


  db:
    image: postgres:15
    restart: always
    env_file: .env
    environment:
      POSTGRES_DB: ${DB_NAME}
      POSTGRES_USER: ${DB_USER}
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    ports:
      - "5432:5432"

  pgweb:
    image: sosedoff/pgweb
    restart: always
    ports:
      - "8081:8081"
    environment:
      # 起動時に自動でDBに接続する設定
      - DATABASE_URL=postgres://${DB_USER}:${DB_PASSWORD}@db:5432/${DB_NAME}?sslmode=disable
    depends_on:
      - db
```

### ③ `.devcontainer/devcontainer.json`
VS Code の拡張機能を自動セットアップし、Maven を確実にインストールします。

```json
{
  "name": "Java Postgres pgweb Env",
  "dockerComposeFile": "docker-compose.yml",
  "service": "app",
  "workspaceFolder": "/workspaces/app",
  "features": {
    "ghcr.io/devcontainers/features/java:1": {
      "version": "21",
      "installMaven": "true"
    }
  },
  "customizations": {
    "vscode": {
      "extensions": [
        "vscjava.vscode-java-pack" // Java開発必須パック
      ]
    }
  },
  "remoteUser": "vscode"
}
```

### ④ `pom.xml`
将来 Spring Boot を入れる場所を確保しつつ、まずは JDBC ドライバのみ定義します。

```xml
<project xmlns="http://maven.apache.org/POM/4.0.0"
         xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>

    <groupId>com.example</groupId>
    <artifactId>my-app</artifactId>
    <version>1.0-SNAPSHOT</version>

    <properties>
        <maven.compiler.source>21</maven.compiler.source>
        <maven.compiler.target>21</maven.compiler.target>
        <project.build.sourceEncoding>UTF-8</project.build.sourceEncoding>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.postgresql</groupId>
            <artifactId>postgresql</artifactId>
            <version>42.6.0</version>
        </dependency>
    </dependencies>
</project>

### ⑤ `.gitignore` ファイル
ビルド生成物や環境変数ファイルを Git 管理から除外します。

```gitignore
# --- Java / Maven ---
target/
*.class
*.jar
*.war
*.ear

# --- Environment ---
# .devcontainer/.env
```
```

---

## 5. 起動と動作確認

### 手順
1.  VS Code でプロジェクトフォルダを開きます。
2.  左下の緑色のアイコンから **「Reopen in Container」** をクリックします。
3.  ビルド完了後、ブラウザで `http://localhost:8081` を開きます。
    *   **pgweb が開き、すでに DB に接続されている状態**になっているはずです。

### Java からの接続テスト
`src/main/java/com/example/App.java` を作成して実行します。

```java
package com.example;
import java.sql.*;

public class App {
    public static void main(String[] args) {
        String url = System.getenv("DB_URL");
        String user = System.getenv("DB_USER");
        String pass = System.getenv("DB_PASSWORD");

        try (Connection conn = DriverManager.getConnection(url, user, pass)) {
            System.out.println("成功: pgweb でデータを確認してみましょう！");
            // ここでテーブル作成やデータ挿入のコードを書く
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
```

### 実行コマンド
**※必ず VS Code 内のターミナル（左下に「Dev Container: ...」と表示されている状態）で実行してください。**
VS Code のターミナル（`Ctrl + @`）を開き、以下のコマンドでプログラムを実行します。


```bash
# プロジェクトのコンパイル
mvn compile

# メインクラスの実行
mvn exec:java -Dexec.mainClass="com.example.App"

# メインクラスの実行（quiet モード）
mvn -q exec:java -Dexec.mainClass="com.example.App"
```

プログラムの出力だけを表示するには `-q` オプションを付けます。
`-q` は quiet モードの意味で、Maven 自体の `[INFO]` ログを非表示にします。

---

## 6. この環境のメリット

1.  **pgweb がとにかく速い**: 
    ブラウザを開いた瞬間にテーブル一覧が見えます。ログイン作業すら不要です。
2.  **Spring Boot への移行が 10 秒で終わる**: 
    準備ができたら `pom.xml` に Spring Boot の依存関係をコピペするだけです。
3.  **環境のポータビリティ**: 
    `.env.example` をコピーして `.env` を作れば、他の人の PC でも全く同じ（pgweb の接続設定まで含めて）環境が再現されます。

## 7. 将来の拡張（Spring Batch 導入時）
Spring Batch を導入すると、多くのメタデータテーブルが作成されます。その際も **pgweb の検索機能（Query）** を使えば、ジョブの成功・失敗を SQL ですぐに確認できるため、非常に相性が良い構成です。
