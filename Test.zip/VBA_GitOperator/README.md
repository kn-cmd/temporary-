# GitOperator VBA クラスモジュール

`GitOperator` は、Microsoft Excel VBA から Git コマンドラインツールを操作するためのラッパークラスモジュールです。これにより、VBAプロジェクト内でGitリポジトリのクローン、更新、コミット、プッシュといった操作を自動化できます。

## 目次

1.  [特徴](#1-特徴)
2.  [前提条件](#2-前提条件)
3.  [インストール](#3-インストール)
4.  [使用方法](#4-使用方法)
    *   [GitOperator クラスの設定](#gitoperator-クラスの設定)
    *   [主なメソッド](#主なメソッド)
    *   [エラーハンドリング](#エラーハンドリング)
    *   [セキュリティ (Personal Access Token)](#セキュリティ-personal-access-token)
5.  [クラスメンバ (プロパティ/メソッド)](#5-クラスメンバ-プロパティメソッド)
6.  [注意点](#6-注意点)
7.  [ライセンス](#7-ライセンス)

## 1. 特徴

*   **Gitコマンドの抽象化**: VBAから直接 `git` コマンドを実行するための簡潔なインターフェースを提供します。
*   **一時ディレクトリ管理**: リポジトリのクローン時に一時ディレクトリを自動で作成し、クラス終了時に安全に削除します。
*   **堅牢なエラーハンドリング**: Gitコマンドの標準出力、標準エラー、終了コードを捕捉し、VBAのエラー機構 (`Err.Raise`) を通じて詳細なエラー情報を提供します。
*   **タイムアウト設定**: 各Gitコマンドの実行タイムアウトをミリ秒単位で設定可能です。
*   **柔軟な認証**: Personal Access Token (PAT) を使用したHTTPS認証をサポートし、PATが提供されない場合はGitの資格情報マネージャーなどを利用できます。
*   **高いメンテナンス性**: 明示的な `Me.` の使用と抽象的なコメントにより、コードの可読性と保守性を高めています。

## 2. 前提条件

*   **Microsoft Excel**: VBAコードを実行可能な環境。
*   **Git コマンドラインツール**: `GitOperator` を使用するPCにGitがインストールされており、`git.exe` へのパスが正しく設定されていること。
*   **GitLab リポジトリ**: 操作対象のGitLab Enterprise Edition (EE) リポジトリへのアクセス権限。
*   **Personal Access Token (PAT) (推奨)**: リポジトリへの書き込み操作 (Commit, Push) が必要な場合、適切なスコープ (`write_repository` など) を持つPATが必要です。

## 3. インストール

1.  **VBAエディタを開く**: Excelブックを開き、`Alt + F11` を押してVBAエディタを起動します。
2.  **クラスモジュールのインポート**:
    *   `VBAProject` ツリーから任意のプロジェクト（例: `ThisWorkbook`）を選択します。
    *   「ファイル」→「ファイルのインポート」を選択し、`GitOperator.cls` ファイル（このクラスモジュールのコードを `.cls` 拡張子で保存したもの）をインポートします。
    *   または、「挿入」→「クラスモジュール」で新しいクラスモジュールを作成し、名前を `GitOperator` に変更後、提供されたコードをコピー＆ペーストします。
3.  **標準モジュールの作成**:
    *   「挿入」→「標準モジュール」で新しい標準モジュールを作成します。
    *   提供された使用例コード（`TestGitOperationsWithClassLatest` サブプロシージャなど）をコピー＆ペーストします。
4.  **Gitのインストール**: まだPCにGitがインストールされていない場合は、[Git公式ウェブサイト](https://git-scm.com/downloads) からダウンロードしてインストールしてください。

## 4. 使用方法

### GitOperator クラスの設定

標準モジュールや他のプロシージャから `GitOperator` クラスをインスタンス化し、必要なプロパティを設定します。

```vba
Dim gitOp As GitOperator
Set gitOp = New GitOperator

' Git実行ファイルのパスを設定 (例: C:\Program Files\Git\bin\git.exe)
gitOp.GitPath = "C:\Program Files\Git\bin\git.exe"

' GitLabリポジトリのURLを設定
gitOp.GitLabRepoUrl = "https://gitlab.com/your_group/your_repo.git"

' Personal Access Token (PAT) を設定 (セキュリティのため、外部ファイル等から読み込むことを推奨)
' gitOp.GitLabPat = GetPatFromExternalSource() ' 外部から読み込む例
gitOp.GitLabPat = "your_personal_access_token"

' コマンドのタイムアウトを設定 (ミリ秒単位、デフォルトは300000ms = 5分)
' gitOp.CommandTimeoutMs = 600000 ' 10分に設定する場合
```

### 主なメソッド

| メソッド名          | 説明                                                                                                 |
| :------------------ | :--------------------------------------------------------------------------------------------------- |
| `Clone(branch)`     | リモートリポジトリをローカルの一時ディレクトリにクローンします。                                   |
| `Pull(branch)`      | ローカルリポジトリをリモートの最新の状態にプルします。                                             |
| `Add(filePath)`     | 指定されたファイル（またはすべての変更）をステージングエリアに追加します。                         |
| `Commit(message)`   | ステージングされた変更をコミットします。                                                           |
| `Push(branch)`      | コミットされた変更をリモートリポジトリにプッシュします。                                           |
| `LocalRepoPath`     | クローンされたローカルリポジトリのパスを取得します。                                               |
| `LastStandardOutput`| 最後に実行されたGitコマンドの標準出力を取得します。                                                |
| `LastStandardError` | 最後に実行されたGitコマンドの標準エラー出力を取得します。                                          |
| `LastExitCode`      | 最後に実行されたGitコマンドの終了コードを取得します。                                                |

### エラーハンドリング

すべてのパブリックメソッドは、Gitコマンドの実行に失敗した場合にVBAのエラー (`Err.Raise`) を発生させます。呼び出し元のコードでは `On Error GoTo` を使用してエラーを捕捉し、`Err.Description` に含まれる詳細な情報（Gitの標準エラー出力など）を利用して適切な処理を行うことができます。

```vba
On Error GoTo ErrorHandler

' Git操作コード

CleanUp:
    Set gitOp = Nothing ' クラスインスタンスを解放し、一時ディレクトリを自動削除
    Exit Call

ErrorHandler:
    MsgBox "エラーが発生しました: " & Err.Description & vbCrLf & _
           "終了コード: " & gitOp.LastExitCode, vbCritical
    Resume CleanUp
```

### セキュリティ (Personal Access Token)

`GitOperator` は `GitLabPat` プロパティを通じてPATを直接受け取ることができますが、**PATをVBAコードにハードコードすることはセキュリティ上の大きなリスクです**。以下のいずれかの方法でPATを安全に管理することを強く推奨します。

*   **Git Credential Manager for Windows の利用**: 最も安全な方法です。Gitクライアント側に設定することで、VBAコードがPATを直接扱う必要がなくなります。
*   **外部設定ファイル**: PATを暗号化された外部ファイル（例: `config.ini`、`settings.json`）に保存し、VBAで読み込みます。ファイルへのアクセス権限を適切に設定してください。
*   **環境変数**: PATをPCの環境変数に設定し、VBAの `Environ("YOUR_PAT_ENV_VAR")` で読み込みます。

## 5. クラスメンバ (プロパティ/メソッド)

### プロパティ

*   `GitPath As String`: Git実行ファイルのフルパス。
*   `GitLabRepoUrl As String`: 操作対象のGitLabリポジトリのHTTPS URL。
*   `GitLabPat As String`: GitLab Personal Access Token (オプション)。
*   `LocalRepoPath As String` (Read-only): クローンされたローカルリポジトリの一時パス。
*   `CommandTimeoutMs As Long`: Gitコマンド実行のタイムアウト時間（ミリ秒）。デフォルトは300000ms (5分)。
*   `LastStandardOutput As String` (Read-only): 最後に実行されたGitコマンドの標準出力。
*   `LastStandardError As String` (Read-only): 最後に実行されたGitコマンドの標準エラー出力。
*   `LastExitCode As Long` (Read-only): 最後に実行されたGitコマンドの終了コード。

### メソッド

*   `Clone(Optional ByVal branch As String = "main") As Boolean`: リポジトリをクローン。成功した場合 `True`。
*   `Pull(Optional ByVal branch As String = "main") As Boolean`: リポジトリをプル。成功した場合 `True`。
*   `Add(Optional ByVal filePath As String = ".") As Boolean`: ファイルをステージング。成功した場合 `True`。
*   `Commit(ByVal message As String) As Boolean`: 変更をコミット。成功した場合 `True`。
*   `Push(Optional ByVal branch As String = "main") As Boolean`: 変更をプッシュ。成功した場合 `True`。

## 6. 注意点

この `GitOperator` クラスはVBAからGitコマンドラインツールをラップして動作します。以下の点にご注意ください。

*   **Gitのインストール必須**: 本モジュールは `git.exe` を直接呼び出すため、実行環境にGitがインストールされており、`GitPath` プロパティに正しいパスが設定されている必要があります。
*   **`WScript.Shell.Exec` の依存**: コマンドの実行には `WScript.Shell` オブジェクトの `Exec` メソッドを使用しています。この機能がブロックされている環境では動作しません。
*   **一時ディレクトリの利用**: リポジトリのクローンは一時ディレクトリ (`%TEMP%` 以下) に行われます。十分なディスクスペースがあることを確認してください。また、クラスインスタンスの解放 (`Set gitOp = Nothing`) が適切に行われない場合、一時ディレクトリが残り続ける可能性があります。
*   **競合解決の制限**: Gitの `pull` や `push` 実行時にリモートリポジトリとの競合 (コンフリクト) が発生した場合、本モジュールは自動的な解決機能を提供しません。エラーが返され、手動での解決が必要となります。
*   **標準エラー出力**: Gitコマンドによっては、エラーではない警告メッセージが標準エラーに出力されることがあります。`RunGitCommand` 内では `lastStdErr` が空白でない場合に `Debug.Print` で出力しますが、これは必ずしも致命的なエラーを示すものではありません。各パブリックメソッドは主に `LastExitCode` が `0` でない場合にエラーを `Err.Raise` します。

## 7. ライセンス

このモジュールは自由に利用、変更、配布いただけます。
