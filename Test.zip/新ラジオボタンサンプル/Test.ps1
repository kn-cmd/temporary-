﻿# ====================================================================
# 1. モジュールのインポートと外部スクリプトの読み込み
# ====================================================================
# モジュールをインポート
Import-Module (Join-Path $PSScriptRoot "ui.psm1") -Force
. (Join-Path $PSScriptRoot "EventHandlers.ps1")

# .NETアセンブリのロード
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# ====================================================================
# 2. 定数・設定値の定義
# ====================================================================
$APP_TITLE = "URL選択ツール"
$URL_MAP = @{
    'Google' = 'https://www.google.com'
    'Yahoo' = 'https://www.yahoo.co.jp'
    'Bing' = 'https://www.bing.com'
}

# ====================================================================
# 3. GUIの構築と表示
# ====================================================================

function Show-RefactoredForm {

    # UIコントロールの生成
    
    # ラジオボタンリストの生成
    $radioButtons = $URL_MAP.Keys | ForEach-Object {
        New-UiRadioButton -Text $_
    }
    # 最初のラジオボタンを選択状態にする
    if ($radioButtons.Count -gt 0) {
        $radioButtons[0].Checked = $true
    }

    # フォームの生成
    $form = New-UiForm -Title $APP_TITLE -AutoSize
    $form.Tag = [RadioButtonEventHandlers]::new($URL_MAP)
    $form.Tag.Form = $form
    $form.Tag.RadioButtons = $radioButtons

    # レイアウトの構築
    $mainPanel = New-UiFlowLayoutPanel -AutoSize -Controls {
        
        # ラジオボタンを配置するパネル     
        New-UiGroupBox -Text "選択してください" -AutoSize -Controls {
            # ラジオボタン
            $groupBoxLayout = New-UiFlowLayoutPanel -AutoSize -Controls {$radioButtons}
            $groupBoxLayout.Dock = [System.Windows.Forms.DockStyle]::Fill
            $groupBoxLayout
        }

        # 垂直方向のスペーサー
        New-UiSpacer

        # ボタンを配置するパネル
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            # 実行ボタン
            $executeButton = New-UiButton -Text "実行"
            $executeButton.Add_Click({ $this.FindForm().Tag.OnExecuteClick() })
            $executeButton
            
            # 水平方向のスペーサー
            New-UiSpacer -Width 5

            # 閉じるボタン
            $closeButton = New-UiButton -Text "閉じる"
            $closeButton.Add_Click({ $this.FindForm().Tag.OnCloseClick() })
            $closeButton
        }
    }

    # フォームにメインパネルを追加して表示
    $form.Controls.Add($mainPanel)
    $form.ShowDialog() | Out-Null
}

# ====================================================================
# 4. スクリプト実行
# ====================================================================
Show-RefactoredForm
