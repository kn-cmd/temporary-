﻿# ====================================================================
# イベントハンドラクラス
# ====================================================================

class RadioButtonEventHandlers {
    # --- UIコントロール ---
    [System.Windows.Forms.Form] $Form
    [System.Windows.Forms.RadioButton[]] $RadioButtons

    # --- データ ---
    [hashtable] $UrlMap

    # --- コンストラクタ ---
    RadioButtonEventHandlers([hashtable]$urlMap) {
        $this.UrlMap = $urlMap
    }

    # --- イベントハンドラメソッド ---

    # 実行ボタン押下処理
    OnExecuteClick() {
        $selectedButton = $this.RadioButtons | Where-Object { $_.Checked }
        
        if ($selectedButton) {
            $key = $selectedButton.Text
            $url = $this.UrlMap[$key]
            
            try {
                # Internet Explorer (IE) を使用してURLを開く
                Start-Process iexplore.exe -ArgumentList $url -ErrorAction Stop
            }
            catch {
                # IEが利用不可の場合は既定のブラウザで開く
                [System.Windows.Forms.MessageBox]::Show("IE起動に失敗。既定のブラウザで開きます。", "エラー", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning)
                Start-Process $url
            }
        }
    }

    # 閉じるボタン押下処理
    OnCloseClick() {
        $this.Form.Close()
    }
}
