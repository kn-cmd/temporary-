﻿# DLLファイルのパスを指定
# この例では MyJsonProcessor.dll が TestProcessor.ps1 と同じディレクトリにあると仮定しています。
$dllPath = Join-Path (Split-Path $MyInvocation.MyCommand.Definition) "MyJsonProcessor.dll"

# DLLをPowerShellのセッションにロード
try {
    Add-Type -LiteralPath $dllPath
    Write-Host "DLL '$dllPath' が正常にロードされました。"
}
catch {
    Write-Error "DLLのロード中にエラーが発生しました: $($_.Exception.Message)"
    exit 1
}

# MyProcessor.JsonGenerator クラスのインスタンスを作成
$jsonGenerator = New-Object MyProcessor.JsonGenerator

# DLLのメソッドに渡す入力文字列
$inputString = "PowerShellから渡されたデータです！"

# DLLのメソッドを呼び出し、JSON文字列を受け取る
try {
    $jsonResult = $jsonGenerator.GetProcessedJson($inputString)
    Write-Host "`n--- DLLからの生のJSON出力 ---"
    Write-Host $jsonResult
}
catch {
    Write-Error "DLLメソッドの呼び出し中にエラーが発生しました: $($_.Exception.Message)"
    exit 1
}

# 受け取ったJSON文字列をPowerShellオブジェクトに変換
try {
    $jsonObject = $jsonResult | ConvertFrom-Json
    Write-Host "`n--- PowerShellオブジェクトに変換後 ---"
    $jsonObject | Format-List # オブジェクトを見やすく表示
}
catch {
    Write-Error "JSONの解析中にエラーが発生しました。生のJSON: $jsonResult"
    Write-Error "エラーメッセージ: $($_.Exception.Message)"
    exit 1
}

# 変換されたオブジェクトのプロパティにアクセスする例
Write-Host "`n--- プロパティへのアクセス ---"
Write-Host "入力された値: $($jsonObject.Input)"
Write-Host "実行日時: $($jsonObject.ExecutionDateTime)"
Write-Host "ステータス: $($jsonObject.Status)"

Write-Host "`n処理が完了しました。"