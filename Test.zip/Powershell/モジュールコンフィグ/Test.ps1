﻿# モジュールのインポート（同じディレクトリにある前提）
Import-Module ".\MyModule.psm1" -Force

Write-Host "--- 1. 初期設定の確認 ---" -ForegroundColor Cyan
Get-MyModuleConfig | Out-String | Write-Host

Write-Host "--- 2. Key/Value による個別更新 (RetryCount -> 10) ---" -ForegroundColor Cyan
Set-MyModuleConfig -Key "RetryCount" -Value 10
Get-MyModuleConfig | Out-String | Write-Host

Write-Host "--- 3. Property による一括更新 (ApiKey と Endpoint) ---" -ForegroundColor Cyan
$newSettings = @{
    ApiKey   = "SECRET_TOKEN_999"
    Endpoint = "https://production.api.com"
}
Set-MyModuleConfig -Property $newSettings
Get-MyModuleConfig | Out-String | Write-Host

Write-Host "--- 4. 存在しないキーの指定（警告が出る） ---" -ForegroundColor Cyan
Set-MyModuleConfig -Key "UnknownKey" -Value "IgnoreMe"

Write-Host "`n--- 5. 重複指定によるエラーチェック ---" -ForegroundColor Cyan
try {
    Set-MyModuleConfig -Key "RetryCount" -Value 5 -Property @{ RetryCount = 1 }
} catch {
    Write-Host "期待通りのエラーが発生しました: $_" -ForegroundColor Yellow
}

Write-Host "`n--- 最終的な設定内容 ---" -ForegroundColor Cyan
Get-MyModuleConfig | Out-String | Write-Host
