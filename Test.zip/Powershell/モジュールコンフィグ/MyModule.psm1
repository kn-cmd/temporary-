﻿# --- モジュール内部変数（スクリプトスコープ） ---
$script:MyModuleConfig = @{
    ApiKey     = "Default_Key_123"
    RetryCount = 3
    Endpoint   = "https://api.example.com"
}

# --- 公開関数: 設定の取得 ---
function Get-MyModuleConfig {
    <#
    .SYNOPSIS
        モジュールの現在の設定を返します。
    #>
    # 外部から直接書き換えられないよう、クローン（複製）を返すのが安全です
    return $script:MyModuleConfig.Clone()
}

# --- 公開関数: 設定の更新 ---
function Set-MyModuleConfig {
    <#
    .SYNOPSIS
        モジュールの設定を更新します。
    .PARAMETER Key
        更新したい設定の名前を指定します。
    .PARAMETER Value
        更新したい設定の値を指定します。
    .PARAMETER Property
        複数の設定をハッシュテーブル形式でまとめて指定します。
    #>
    param(
        [string]$Key,
        [object]$Value,
        [hashtable]$Property = @{}
    )

    # 1. 重複チェック
    if ($Key -and $Property.ContainsKey($Key)) {
        throw "エラー: キー '$Key' が -Key と -Property の両方で指定されています。重複は許可されません。"
    }

    # 2. Key/Value 指定がある場合は Property に統合
    # $PSBoundParameters を使うことで、引数が明示的に渡されたか判定
    if ($PSBoundParameters.ContainsKey('Key')) {
        $Property[$Key] = $Value
    }

    # 3. 反復処理で設定を更新
    foreach ($name in $Property.Keys) {
        if ($script:MyModuleConfig.ContainsKey($name)) {
            $script:MyModuleConfig[$name] = $Property[$name]
            Write-Verbose "設定 '$name' を更新しました。"
        } else {
            Write-Warning "設定項目 '$name' は存在しないため無視されました。"
        }
    }
}

# 関数のエクスポート
Export-ModuleMember -Function Get-MyModuleConfig, Set-MyModuleConfig
