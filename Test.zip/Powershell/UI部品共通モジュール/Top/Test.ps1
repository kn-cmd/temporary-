﻿# ====================================================================
# モジュールのインポート
# ====================================================================
Import-Module (Join-Path $PSScriptRoot "..\ui.psm1") -Force


# ====================================================================
# 定数設定
# ====================================================================
# ウィンドウタイトル
$FORM_TITLE = "テスト画面"

# ラベル文字フォント
$LARGE_FONT = [System.Drawing.Font]::new("Yu Gothic UI", 16, [System.Drawing.FontStyle]::Bold)

# 閉じるボタンスペーサーの幅
$SPACER_WIDTH_FOR_RIGHT_ALIGN = 280


# ====================================================================
# GUIの構築と表示
# ====================================================================
function Show-TestForm {
    # フォームの生成
    $form = New-UiForm -Title $FORM_TITLE -AutoSize

    # レイアウトの構築
    $mainPanel = New-UiFlowLayoutPanel -AutoSize -Controls {
        
        # 1. ラベル (大きく設定)
        New-UiLabel -Text "ラベル1" -AutoSize -Font $LARGE_FONT

        # 2. ボタン ボタン ボタン
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            New-UiButton -Text "ボタン1-1"
            New-UiButton -Text "ボタン1-2"
            New-UiButton -Text "ボタン1-3"
        }

        # 3. ラベル (大きく設定)
        New-UiLabel -Text "ラベル2" -AutoSize -Font $LARGE_FONT

        # 4. ボタン
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            New-UiButton -Text "ボタン2-1"
        }

        # 5. ラベル (大きく設定)
        New-UiLabel -Text "ラベル3" -AutoSize -Font $LARGE_FONT

        # 6. ボタン ボタン
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            New-UiButton -Text "ボタン3-1"
            New-UiButton -Text "ボタン3-2"
        }

        # 7. 閉じるボタン
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            # スペーサーを入れてボタンを右に押し出す
            New-UiSpacer -Width $SPACER_WIDTH_FOR_RIGHT_ALIGN
            
            $closeButton = New-UiButton -Text "閉じる"
            $closeButton.Add_Click({ $this.FindForm().Close() })
            $closeButton
        }
    }

    # フォームにメインパネルを追加
    $form.Controls.Add($mainPanel)
    

    # 表示
    $form.ShowDialog() | Out-Null
}

# ====================================================================
# スクリプト実行
# ====================================================================
Show-TestForm
