﻿Add-Type -AssemblyName System.Windows.Forms

$form = New-Object Windows.Forms.Form
$form.Size = New-Object Drawing.Size(300, 200)
$form.Text = "空白許可カレンダー"

$dtp = New-Object Windows.Forms.DateTimePicker
$dtp.Location = New-Object Drawing.Point(50, 50)
$dtp.Size = New-Object Drawing.Size(150, 25)

# --- 空白をシミュレートするための設定 ---

# 1. 書式をカスタムに設定し、スペース1個をセット（これで空白に見える）
$dtp.Format = [Windows.Forms.DateTimePickerFormat]::Custom
$dtp.CustomFormat = " " 

# 2. カレンダーで日付が選ばれた時の処理
$dtp.Add_ValueChanged({
    # 日付が選択されたら、書式を通常の日付形式に戻す
    $dtp.CustomFormat = "yyyy/MM/dd"
})

# 3. キー入力の処理（Deleteキーで空白に戻す）
$dtp.Add_KeyDown({
    param($sender, $e)
    if ($e.KeyCode -eq "Delete" -or $e.KeyCode -eq "Back") {
        # 空白（スペース）をセットして空白に見せる
        $dtp.CustomFormat = " "
    }
})

$form.Controls.Add($dtp)

# 確定ボタン（値が空かどうか判定する例）
$btn = New-Object Windows.Forms.Button
$btn.Text = "値を確認"
$btn.Location = New-Object Drawing.Point(50, 100)
$btn.Add_Click({
    if ($dtp.CustomFormat -eq " ") {
        [Windows.Forms.MessageBox]::Show("現在は空白(Null)です")
    } else {
        [Windows.Forms.MessageBox]::Show("選択された日付: " + $dtp.Value.ToString("yyyy/MM/dd"))
    }
})
$form.Controls.Add($btn)

$form.ShowDialog()