﻿# ====================================================================
# モジュールのインポート
# ====================================================================
Import-Module (Join-Path $PSScriptRoot "..\ui.psm1") -Force


# ====================================================================
# 定数設定
# ====================================================================
# ウィンドウタイトル
$FORM_TITLE = "入力画面"

# ラベル文字フォント
$LARGE_FONT = [System.Drawing.Font]::new("Yu Gothic UI", 16, [System.Drawing.FontStyle]::Bold)

# レイアウト用定数（Paddingの上下を0にして間隔を詰める）
$ROW_PADDING = [System.Windows.Forms.Padding]::new(10, 0, 10, 0)
$ZERO_PADDING =  @{
        Margin = [System.Windows.Forms.Padding]::Empty
        Padding = [System.Windows.Forms.Padding]::Empty
}

# 閉じるボタンスペーサーの幅
$SPACER_WIDTH_FOR_RIGHT_ALIGN = 350


# ====================================================================
# GUIの構築と表示
# ====================================================================
function Show-EntryForm {
    # フォームの生成
    $form = New-UiForm -Title $FORM_TITLE -AutoSize

    # レイアウトの構築
    $mainPanel = New-UiFlowLayoutPanel -AutoSize -Controls {
        
        # 「基本設定」ラベル
        New-UiLabel -Text "基本設定" -AutoSize -Font $LARGE_FONT

        # 「基本設定」レイアウト
        New-UiFlowLayoutPanel @ZERO_PADDING -AutoSize -Controls {
            # ラベル： テキストボックス
            New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Padding $ROW_PADDING -Controls {
                New-UiLabel -Text "ラベル１：" -AutoSize
                New-UiTextBox
            } -ControlsAnchor "Left"

            # ラベル： 日付入力
            New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Padding $ROW_PADDING -Controls {
                New-UiLabel -Text "ラベル２：" -AutoSize
                New-UiDateTimePicker
            } -ControlsAnchor "Left"

            # ラベル： 〇 ラジオボタン１　〇 ラジオボタン２
            New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Padding $ROW_PADDING -Controls {
                New-UiLabel -Text "ラベル３：" -AutoSize
                New-UiRadioButton -Text "ラジオボタン１"
                New-UiRadioButton -Text "ラジオボタン２"
            } -ControlsAnchor "Left"

            # ラベル： テキストボックス
            New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Padding $ROW_PADDING -Controls {
                New-UiLabel -Text "ラベル４：" -AutoSize
                New-UiTextBox
            } -ControlsAnchor "Left"
        }

        New-UiSpacer -Height 10

        # 「入力形式」ラベル
        New-UiLabel -Text "入力形式" -AutoSize -Font $LARGE_FONT

        # 「入力形式」レイアウト
        New-UiFlowLayoutPanel -AutoSize -Controls {
            # 「ダウンロード」ボタン
            New-UiButton -Text "ダウンロード"
        }

        New-UiSpacer -Height 10

        # 「入力」ラベル
        New-UiLabel -Text "入力" -AutoSize -Font $LARGE_FONT

        # 「入力」レイアウト
        New-UiFlowLayoutPanel -AutoSize -Controls {
            # テキストボックス 　　「ファイル選択」ボタン
            New-UiFlowLayoutPanel @ZERO_PADDING -FlowDirection LeftToRight -AutoSize -Controls {
                New-UiTextBox -Width 300
                
                New-UiButton -Text "ファイル選択"
            }

            # 「アップロード」ボタン
            New-UiButton -Text "アップロード"
        }

        New-UiSpacer -Height 20

        # 「閉じる」ボタン
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            # スペーサーを入れてボタンを右に押し出す
            New-UiSpacer -Width $SPACER_WIDTH_FOR_RIGHT_ALIGN
            
            $closeButton = New-UiButton -Text "閉じる"
            $closeButton.Add_Click({ $this.FindForm().Close() })
            $closeButton
        }
    }

    # フォームにメインパネルを追加
    $form.Controls.Add($mainPanel)
    
    # 表示
    $form.ShowDialog() | Out-Null
}

# ====================================================================
# スクリプト実行
# ====================================================================
Show-EntryForm
