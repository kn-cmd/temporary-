﻿Import-Module ".\ui.psm1" -Force

# --- 1. コントロールの作成 ---
$inputWidth = 300

# メインタイトル
$titleFont = [System.Drawing.Font]::new("Yu Gothic UI", 24, [System.Drawing.FontStyle]::Bold)
$lblTitle = New-UiLabel -Text "【デモ用】起動設定画面" -Font $titleFont -AutoSize

# ID・氏名
$lblID = New-UiLabel -Text "ID" -AutoSize
$txtID = New-UiTextBox -Text "USER001"
$txtID.Width = $inputWidth

$lblName = New-UiLabel -Text "氏名" -AutoSize
$txtName = New-UiTextBox -Text "山田 太郎"
$txtName.Width = $inputWidth

# 部署コード (4択ラジオボタン)
$rbDept1 = New-UiRadioButton -Text "D001"
$rbDept2 = New-UiRadioButton -Text "D002"
$rbDept3 = New-UiRadioButton -Text "D003"
$rbDept4 = New-UiRadioButton -Text "D004"
$rbDept1.Checked = $true
$deptButtons = @($rbDept1, $rbDept2, $rbDept3, $rbDept4)

# 権限
$rbAdmin = New-UiRadioButton -Text "管理者"
$rbGeneral = New-UiRadioButton -Text "一般"
$rbGeneral.Checked = $true

# ボタン
$btnMain1 = New-UiButton -Text "Main_1 起動"
$btnMain2 = New-UiButton -Text "Main_2 起動"

# --- 2. UI の組み立て ---
$form = New-UiForm -Title "起動設定画面" -AutoSize
$padding20 = [System.Windows.Forms.Padding]::new(20)

$mainPanel = New-UiFlowLayoutPanel -AutoSize -Padding $padding20 -Controls {
    
    # タイトル
    $lblTitle
    # New-UiSpacer -Height 20
    
    # ID セクション
    $lblID; $txtID
    New-UiSpacer -Height 10
    
    # 氏名 セクション
    $lblName; $txtName
    New-UiSpacer -Height 10
    
    # 横並びセクション (部署コード & 権限設定)
    New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Margin ([System.Windows.Forms.Padding]::new(0)) -Controls {
        
        # 部署コード選択
        $gbDept = New-UiGroupBox -Text "部署コード" -AutoSize -Controls {
            $pnlDept = New-UiFlowLayoutPanel -FlowDirection TopDown -AutoSize -Controls {
                $rbDept1; $rbDept2; $rbDept3; $rbDept4
            }
            $pnlDept.Dock = [System.Windows.Forms.DockStyle]::Fill
            $pnlDept
        }
        $gbDept.Margin = [System.Windows.Forms.Padding]::new(0, 0, 30, 0) # 右に余白
        $gbDept
        
        # 権限設定
        $gbPriv = New-UiGroupBox -Text "権限設定" -AutoSize -Controls {
            $pnlPriv = New-UiFlowLayoutPanel -FlowDirection TopDown -AutoSize -Controls {
                $rbAdmin; $rbGeneral
            }
            $pnlPriv.Dock = [System.Windows.Forms.DockStyle]::Fill
            $pnlPriv
        }
        $gbPriv.Margin = [System.Windows.Forms.Padding]::new(0)
        $gbPriv
    }
    
    New-UiSpacer -Height 10
    
    # ボタン配置
    New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Margin ([System.Windows.Forms.Padding]::new(0)) -Controls {
        $btnMain1
        $btnMain2
    }
}

$form.Controls.Add($mainPanel)

# --- 3. 補助関数・イベントハンドラ ---

# 選択されている部署コードを取得する関数
function Get-SelectedDept {
    foreach ($rb in $deptButtons) {
        if ($rb.Checked) { return $rb.Text }
    }
    return ""
}

# Main_1 起動
$btnMain1.Add_Click({
    $isPrivileged = $rbAdmin.Checked
    $dept = Get-SelectedDept
    Write-Host "`n[Test.ps1] Main_1.ps1 を呼び出します..." -ForegroundColor Cyan
    & ".\Main_1.ps1" -Name $txtName.Text -DeptCode $dept -IsPrivileged $isPrivileged
})

# Main_2 起動
$btnMain2.Add_Click({
    $isPrivileged = $rbAdmin.Checked
    $dept = Get-SelectedDept
    Write-Host "`n[Test.ps1] Main_2.ps1 を呼び出します..." -ForegroundColor Cyan
    & ".\Main_2.ps1" -ID $txtID.Text -DeptCode $dept -IsPrivileged $isPrivileged
})

$form.ShowDialog() | Out-Null
$form.Dispose()
