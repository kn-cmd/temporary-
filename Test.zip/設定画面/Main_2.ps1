﻿Param (
    [string]$ID,
    # [string]$Name,
    [string]$DeptCode,
    [bool]$IsPrivileged
)

Write-Host "--- Main_2 起動 ---"
Write-Host "ID: $ID"
# Write-Host "氏名: $Name"
Write-Host "部署コード: $DeptCode"
Write-Host "権限 (特権): $IsPrivileged"
