Option Explicit

' ==============================================================================
' 設定定数 (環境に合わせて書き換えてください)
' ==============================================================================
Private Const GITLAB_BASE_URL As String = "https://gitlab.example.com"
Private Const GITLAB_PRIVATE_TOKEN As String = "YOUR_PERSONAL_ACCESS_TOKEN"
Private Const GITLAB_PROJECT_ID As String = "your-group/your-project"

' ==============================================================================
' GitLabSimpleCommit クラス用 動作テストプログラム
' ==============================================================================

Public Sub Main()
    ' クラスのインスタンス化
    Dim gitlab As GitLabSimpleCommit
    Set gitlab = initGitlab()
    
    ' エラーハンドリングの開始
    On Error GoTo ErrorHandler
    
    ' コミット内容の準備
    Dim content As String
    content = "Upsert test content." & vbCrLf & _
              "This will be created if missing, or updated if exists." & vbCrLf & _
              "Last updated: " & Now
               
    ' Upsertプロシージャの呼び出し
    UpsertFile gitlab, "vba_test/upsert_test.txt", content
    
    MsgBox "コミットに成功しました！", vbInformation
    Exit Sub

ErrorHandler:
    MsgBox "エラーが発生しました。" & vbCrLf & vbCrLf & _
           "エラー番号: " & Err.Number & vbCrLf & _
           "内容: " & Err.Description, vbCritical
End Sub

' 1ファイル専用の Upsert 関数（まず update を試み、ファイルが存在しないエラーの場合は create で再試行します。）
Private Sub UpsertFile(gitlab As GitLabSimpleCommit, filePath As String, content As String, Optional ByVal branch As String = "main", Optional ByVal message As String = "update")
    ' update を試みる
    gitlab.clear
    gitlab.addCommit filePath, content, "update"
    If gitlab.commit(branch, message) Then Exit Sub ' 成功

    ' ファイルが存在しないエラー ("doesn't exist") の場合は create で再試行
    If InStr(LCase(gitlab.LastError), "doesn't exist") > 0 Then
        gitlab.clear
        gitlab.addCommit filePath, content, "create"
        If gitlab.commit(branch, message) Then Exit Sub ' 再試行成功
    End If
    
    ' ここまで到達した場合はエラーを通知
    Err.Raise vbObjectError + 513, "UpsertFile", _
              "GitLabへのコミットに失敗しました。" & vbCrLf & "詳細: " & gitlab.LastError
End Sub


' GitLabSimpleCommit クラスを初期化
Private Function initGitlab() As GitLabSimpleCommit
    Dim gitlab As GitLabSimpleCommit
    Set gitlab = New GitLabSimpleCommit
    
    gitlab.BaseUrl = GITLAB_BASE_URL
    gitlab.PrivateToken = GITLAB_PRIVATE_TOKEN
    gitlab.ProjectId = GITLAB_PROJECT_ID
    
    Set initGitlab = gitlab
End Function
