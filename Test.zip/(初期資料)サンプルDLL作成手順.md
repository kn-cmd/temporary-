はい、`csc.exe` を使用してフレームワーク依存展開 (Framework-dependent deployment) のDLLを作成し、それをPowerShellから呼び出す手順を以下に示します。このDLLは、引数で指定された入力値と、実行された現在の日付時刻をJSON形式の文字列として返します。

この手順では、広く利用可能な **.NET Framework 4.x** の環境を想定し、JSONシリアライズに **`System.Web.Script.Serialization.JavaScriptSerializer`** を使用します。これは、`csc.exe` で追加のNuGetパッケージなしに簡単に参照できるため、一般的なWindows環境での互換性が高いです。

---

### **手順1: C#ソースコードの作成**

`MyJsonProcessor.cs`という名前で以下の内容のファイルを作成します。

```csharp
using System;
using System.Web.Script.Serialization; // この名前空間は System.Web.Extensions.dll に含まれます。

namespace MyProcessor
{
    public class JsonGenerator
    {
        /// <summary>
        /// 指定された入力値と現在の実行日時を含むJSON文字列を返します。
        /// </summary>
        /// <param name="input">処理する入力文字列。</param>
        /// <returns>入力値と実行日時を含むJSON文字列。</returns>
        public string GetProcessedJson(string input)
        {
            // 結果を格納する匿名オブジェクトを作成
            var resultObject = new
            {
                Input = input,
                ExecutionDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), // 日付時刻を文字列としてフォーマット
                Status = "Success"
            };

            // JavaScriptSerializer を使用してオブジェクトをJSON文字列にシリアライズ
            // JavaScriptSerializer は .NET Framework 3.5 以降で利用可能です。
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(resultObject);
        }
    }
}
```

### **手順2: DLLのコンパイル (csc.exe を使用)**

1.  **`csc.exe` と `System.Web.Extensions.dll` の場所を見つける:**
    これらは通常、`.NET Framework` のインストールディレクトリ内にあります。一般的なパスは以下の通りです（バージョンやOSのビット数によって異なります）。

    *   64ビットOSの場合: `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\`
    *   32ビットOSの場合: `C:\Windows\Microsoft.NET\Framework\v4.0.30319\`
    （`v4.0.30319` は .NET Framework 4.x を指します。より新しいバージョンの`csc.exe`や.NET Frameworkディレクトリが存在する場合、それを使用することもできます。）

    `System.Web.Extensions.dll` も通常、同じディレクトリまたはGAC内に存在します。

2.  **コマンドプロンプトまたはPowerShellを開く:**
    `MyJsonProcessor.cs` ファイルを保存したディレクトリに移動し、そこでコマンドプロンプトまたはPowerShellを開きます。

3.  **DLLをコンパイルするコマンドを実行:**
    以下のコマンドを実行してDLLをコンパイルします。**`csc.exe` のパス** と **`System.Web.Extensions.dll` のパス** は、あなたの環境に合わせて正確に調整してください。

    ```powershell
    # 例: .NET Framework 4.x の csc.exe を使用する場合
    $cscPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
    $webExtensionsDllPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll" # csc.exeと同じディレクトリにあることが多い

    # DLLをコンパイルするコマンド
    & $cscPath /target:library /reference:$webExtensionsDllPath MyJsonProcessor.cs
    ```
    *   `/target:library` (または `/t:library`): 実行可能ファイルではなく、クラスライブラリ (DLL) を作成することを指定します。
    *   `/reference:パス`: DLLが依存する他のアセンブリ（ここでは`System.Web.Extensions.dll`）を参照することを指定します。

    コンパイルが成功すると、`MyJsonProcessor.dll` というファイルが現在のディレクトリに生成されます。

### **手順3: PowerShellスクリプトの作成と実行**

以下の内容のPowerShellスクリプト（例: `TestProcessor.ps1`）を作成します。このスクリプトは、作成したDLLをロードし、メソッドを呼び出してJSON文字列を取得、そしてPowerShellオブジェクトに変換して表示します。

```powershell
# DLLファイルのパスを指定
# この例では MyJsonProcessor.dll が TestProcessor.ps1 と同じディレクトリにあると仮定しています。
$dllPath = Join-Path (Split-Path $MyInvocation.MyCommand.Definition) "MyJsonProcessor.dll"

# DLLをPowerShellのセッションにロード
try {
    Add-Type -LiteralPath $dllPath
    Write-Host "DLL '$dllPath' が正常にロードされました。"
}
catch {
    Write-Error "DLLのロード中にエラーが発生しました: $($_.Exception.Message)"
    exit 1
}

# MyProcessor.JsonGenerator クラスのインスタンスを作成
$jsonGenerator = New-Object MyProcessor.JsonGenerator

# DLLのメソッドに渡す入力文字列
$inputString = "PowerShellから渡されたデータです！"

# DLLのメソッドを呼び出し、JSON文字列を受け取る
try {
    $jsonResult = $jsonGenerator.GetProcessedJson($inputString)
    Write-Host "`n--- DLLからの生のJSON出力 ---"
    Write-Host $jsonResult
}
catch {
    Write-Error "DLLメソッドの呼び出し中にエラーが発生しました: $($_.Exception.Message)"
    exit 1
}

# 受け取ったJSON文字列をPowerShellオブジェクトに変換
try {
    $jsonObject = $jsonResult | ConvertFrom-Json
    Write-Host "`n--- PowerShellオブジェクトに変換後 ---"
    $jsonObject | Format-List # オブジェクトを見やすく表示
}
catch {
    Write-Error "JSONの解析中にエラーが発生しました。生のJSON: $jsonResult"
    Write-Error "エラーメッセージ: $($_.Exception.Message)"
    exit 1
}

# 変換されたオブジェクトのプロパティにアクセスする例
Write-Host "`n--- プロパティへのアクセス ---"
Write-Host "入力された値: $($jsonObject.Input)"
Write-Host "実行日時: $($jsonObject.ExecutionDateTime)"
Write-Host "ステータス: $($jsonObject.Status)"

Write-Host "`n処理が完了しました。"
```

### **手順4: PowerShellスクリプトの実行**

`TestProcessor.ps1` を保存したディレクトリでPowerShellを開き、以下のコマンドを実行します。

```powershell
.\TestProcessor.ps1
```

### **期待される出力例:**

（日付と時刻は実行時に応じて変化します）

```
DLL 'C:\Path\To\Your\DLL\MyJsonProcessor.dll' が正常にロードされました。

--- DLLからの生のJSON出力 ---
{"Input":"PowerShellから渡されたデータです！","ExecutionDateTime":"2025-09-26 13:45:30","Status":"Success"}

--- PowerShellオブジェクトに変換後 ---

Input           : PowerShellから渡されたデータです！
ExecutionDateTime : 2025-09-26 13:45:30
Status          : Success

--- プロパティへのアクセス ---
入力された値: PowerShellから渡されたデータです！
実行日時: 2025-09-26 13:45:30
ステータス: Success

処理が完了しました。
```

---

### **補足と注意点:**

*   **.NET Frameworkのバージョン:** この手順は、PowerShellが実行されるWindows環境に**`.NET Framework 4.x`**（またはそれ以降の互換性のあるバージョン）がインストールされていることを前提としています。`JavaScriptSerializer`は、このフレームワークバージョンで利用可能です。
*   **パスの調整:** `csc.exe` や `System.Web.Extensions.dll` の正確なパスは、あなたのシステム環境やインストールされている.NET Frameworkのバージョンによって異なります。適切なパスを調べて指定してください。
*   **よりモダンな.NET (.NET 5以降) の場合:**
    もし、より新しい.NET (.NET 5, 6, 7, 8など) をターゲットにしたい場合は、`csc.exe` を直接使用するよりも、`dotnet CLI` (`dotnet new classlib`でプロジェクト作成後、`dotnet build`) を使用してDLLをコンパイルする方が一般的かつ推奨されます。その場合、JSONシリアライズには `System.Text.Json` が標準で利用でき、追加の参照は不要です。DLLを実行する環境には、ターゲットとなる.NETランタイムがインストールされている必要があります。
*   **エラーハンドリング:** 実運用では、DLLのロード失敗、メソッドの実行失敗、JSON解析失敗などのエラー処理をより堅牢に行う必要があります。