﻿
# =============================================================================
# MainForm Module
# =============================================================================

# 外部モジュールとクラス定義をインポート
Import-Module ".\ui.psm1" -Force
. "$PSScriptRoot\EventHandlers.ps1"

#region 定数 (モジュールスコープ)
$MAIN_FORM_TITLE = "社員を選択"
#endregion

#region 公開関数
function New-MainForm {
<#
.SYNOPSIS
    メインフォームを生成し、設定済みのフォームオブジェクトを返します。
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory=$true)]
        [PSCustomObject[]]$Data,
        [Parameter(Mandatory=$true)]
        [string[]]$Columns
    )

    # メインフォームの作成
    $form = New-UiForm -Title $MAIN_FORM_TITLE -AutoSize
    $form.Tag = [EventHandlers]::new()

    # UIレイアウト
    $rootPanel = New-UiFlowLayoutPanel -AutoSize -Padding 0 -Controls {
        # DataGridView 用パネル
        New-UiFlowLayoutPanel -AutoSize -Controls {
            # DataGridView
            $tableSize = [System.Drawing.Size]::new(600, 300)
            $form.Tag.DataGridView = New-UiDataGridView -FromData $Data -Columns $Columns -Size $tableSize
            $form.Tag.DataGridView
        }

        # ボタン用パネル (削除/ダウンロード)
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            # 削除ボタン
            $deleteButton = New-UiButton -Text "削除"
            $deleteButton.Add_Click({ $this.FindForm().Tag.OnDeleteButtonClick() })
            $deleteButton

            # ダウンロードボタン
            $downloadButton = New-UiButton -Text "ダウンロード"
            $downloadButton.Add_Click({ $this.FindForm().Tag.OnDownloadButtonClick() })
            $downloadButton

        }
    
        # 行間
        New-UiSpacer

        # 入力行パネル
        New-UiFlowLayoutPanel -AutoSize -FlowDirection TopDown -Controls {
            # ファイル選択ラベル
            New-UiLabel -Text "ファイル選択" -AutoSize
            # ファイルパス入力欄
            $form.Tag.TextBox = New-UiTextBox -ReadOnly -TabStop $false
            $form.Tag.TextBox.Width =  $form.Tag.DataGridView.Size.Width
            $form.Tag.TextBox
        }
    
        # ボタン行パネル (ファイル選択/アップロード)
        New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
            # ファイル選択ボタン
            $selectFileButton = New-UiButton -Text "ファイル選択"
            $selectFileButton.Add_Click({ $this.FindForm().Tag.OnSelectFileButtonClick() })
            $selectFileButton

            # アップロードボタン
            $uploadButton = New-UiButton -Text "アップロード"
            $uploadButton.Add_Click({ $this.FindForm().Tag.OnUploadButtonClick() })
            $uploadButton
        }
    }

    # フォームにルートパネルを追加
    $form.Controls.Add($rootPanel)
    return $form
}
#endregion

# 公開する関数をエクスポート
Export-ModuleMember -Function New-MainForm

