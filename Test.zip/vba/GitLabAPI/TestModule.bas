Option Explicit

' ==============================================================================
' 設定定数 (環境に合わせて書き換えてください)
' ==============================================================================
Private Const GITLAB_BASE_URL As String = "https://gitlab.example.com"
Private Const GITLAB_PRIVATE_TOKEN As String = "YOUR_PERSONAL_ACCESS_TOKEN"
Private Const GITLAB_PROJECT_ID As String = "your-group/your-project"

' ==============================================================================
' GitLabSimpleCommit クラス用 動作テストプログラム
' ==============================================================================

Public Sub Main()
    ' クラスのインスタンス化
    Dim gitlab As GitLabSimpleCommit
    Set gitlab = initGitlab()
    
    ' コミット内容の蓄積1
    Dim content1 As String
    content1 = "Hello GitLab!" & vbCrLf & _
               "This file was created from Excel VBA." & vbCrLf & _
               "Generated at: " & Now
               
    gitlab.addCommit "vba_test/hello.txt", content1, "create"
    

    ' コミット内容の蓄積2
    Dim content2 As String
    content2 = "Update log:" & vbCrLf & _
               "- Action: Automated commit" & vbCrLf & _
               "- Status: Success"
               
    gitlab.addCommit "vba_test/log.md", content2, "update"
    
    ' 一括コミットの実行
    Dim success As Boolean
    success = gitlab.commit("main", "VBAからのテストコミット")
    
    ' 結果の確認
    If success Then
        MsgBox "コミットに成功しました！" & vbCrLf & "GitLabのリポジトリを確認してください。", vbInformation
    Else
        Debug.Print "エラー詳細: " & gitlab.LastError
        MsgBox "コミットに失敗しました。" & vbCrLf & vbCrLf & _
               "エラー内容:" & vbCrLf & gitlab.LastError, vbCritical
    End If
    
End Sub


' GitLabSimpleCommit クラスを初期化
Private Function initGitlab() As GitLabSimpleCommit
    Dim gitlab As GitLabSimpleCommit
    Set gitlab = New GitLabSimpleCommit
    
    gitlab.BaseUrl = GITLAB_BASE_URL
    gitlab.PrivateToken = GITLAB_PRIVATE_TOKEN
    gitlab.ProjectId = GITLAB_PROJECT_ID
    
    Set initGitlab = gitlab
End Function
