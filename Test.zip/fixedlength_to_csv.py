"""
SJIS固定長ファイルをバイト数指定で分割し、CSV形式に変換するツールです。
入力ファイルがShift-JIS (CP932) であることを前提とし、出力も同形式を維持します。

【引数の構成】
■ 必須引数:
  input           入力ファイルパス (Shift-JIS固定長)
  -l, --lengths   各項目のバイト長を順に指定 (例: -l 10 20 30)

■ 任意引数:
  output          出力ファイルパス (省略時は入力パス末尾に .csv を付加)
  -s, --sep_len   入力レコード間の改行等のバイト数 (CRLF=2, LF=1, なし=0 / デフォルト: 0)
  -d, --delimiter 出力の区切り文字 (デフォルト: , )
  -n, --newline   出力の改行コード (CRLF または LF / デフォルト: CRLF)
  -i, --incomplete_ending 不完全な終端の扱い (ignore, error, fill / デフォルト: error)
  --trim          指定された場合、各項目の前後の半角スペースを削除する

【特徴】
・デコード処理を行わないバイナリ処理のため、極めて高速に動作します。
・ジェネレータによる逐次処理により、巨大なファイルでもメモリを消費しません。

【制約】
・データ内に区切り文字が含まれる場合でも、エスケープ処理は行いません。
・trim オプション指定時は各項目の前後の「半角スペース (0x20)」を削除します。全角スペースや"0" などは削除できません。

実行例:
python fixedlength_to_csv.py input.dat -l 10 20 30 -n LF --trim
"""

import argparse
import sys
from pathlib import Path

def read_fixed_records_binary(path, field_lengths, sep_len, incomplete_ending, trim):
    """固定長ファイルを1レコードずつバイト列のリストとして返すジェネレータ"""
    data_len = sum(field_lengths)
    record_size = data_len + sep_len
    
    with path.open('rb') as f:
        while True:
            chunk = f.read(record_size)
            if not chunk:
                break
            
            # 定義されたデータ長に満たない場合の処理
            if len(chunk) < data_len:
                if incomplete_ending == 'error':
                    raise ValueError(f"不完全なレコードがファイル末尾に検出されました (長さ: {len(chunk)}, 期待値: {data_len}以上)")
                elif incomplete_ending == 'fill':
                    # 不足分を半角スペースで埋める
                    chunk = chunk.ljust(data_len, b' ')
                elif incomplete_ending == 'ignore':
                    break
                else:
                    raise ValueError(f"incomplete_ending に不正な値が指定されました: {incomplete_ending}")
            
            row = []
            pos = 0
            for length in field_lengths:
                # 指定範囲を抽出
                field = chunk[pos : pos + length]
                if trim:
                    field = field.strip(b' ')
                row.append(field)
                pos += length
            yield row

def main(input_path, output_path, field_lengths, sep_len, delimiter, newline_b, incomplete_ending, trim):
    """バイナリモードで読み書きを行い、区切り文字を付与して出力する"""
    records = read_fixed_records_binary(
        input_path, 
        field_lengths, 
        sep_len, 
        incomplete_ending, 
        trim
    )
    
    delim_b = delimiter.encode('ascii')

    with output_path.open('wb') as f_out:
        for row in records:
            # フィールドを結合して1行として書き出し
            line = delim_b.join(row) + newline_b
            f_out.write(line)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    # 引数定義
    parser.add_argument('input')
    parser.add_argument('output', nargs='?')
    parser.add_argument('-l', '--lengths', type=int, nargs='+', required=True)
    parser.add_argument('-s', '--sep_len', type=int, default=0)
    parser.add_argument('-d', '--delimiter', default=',')
    parser.add_argument('-n', '--newline', choices=['CRLF', 'LF'], default='CRLF')
    parser.add_argument('-i', '--incomplete_ending', choices=['ignore', 'error', 'fill'], default='error')
    parser.add_argument('--trim', action='store_true')
    
    args = parser.parse_args()

    input_p = Path(args.input)
    if not input_p.exists():
        print(f"Error: File not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    # 出力パスの決定（省略時は末尾に .csv を付加）
    if args.output:
        output_p = Path(args.output)
    else:
        output_p = input_p.with_name(input_p.name + ".csv")

    # 改行コードのバイナリ変換
    newline_map = {'CRLF': b'\r\n', 'LF': b'\n'}
    newline_b = newline_map[args.newline]

    try:
        main(
            input_p, 
            output_p, 
            args.lengths, 
            args.sep_len, 
            args.delimiter,
            newline_b,
            args.incomplete_ending,
            args.trim
        )
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)
