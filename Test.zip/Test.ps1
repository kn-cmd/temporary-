﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

# --- 設定値の集中管理 (定数) ---

# アプリケーション全般
$APP_TITLE = "ID検索ツール"

# フォームサイズ (最小サイズとして使用)
$FORM_WIDTH = 450
$FORM_HEIGHT = 350
$FORM_PADDING = [System.Windows.Forms.Padding]::new(10, 10, 10, 10) # フォームのパディング

# ボタン設定
$BUTTON_OK_TEXT = "OK"
$BUTTON_CANCEL_TEXT = "キャンセル"
$BUTTON_WIDTH = 75
$BUTTON_HEIGHT = 23

# DataGridView設定
$COL_ID_HEADER = "ID"
$COL_VALUE_HEADER = "値"
$COL_ID_FILLWEIGHT = 70
$COL_VALUE_FILLWEIGHT = 100
$READONLY_BACKCOLOR = [System.Drawing.Color]::LightGray
$INITIAL_ROWS = 5

# データファイルパス
$CSV_FILE_PATH = Join-Path $PSScriptRoot "id_data.csv" # CSVファイルのパス

# --- ID-値の辞書 (ハッシュテーブル) ---
$data = @{
    "ID001" = "Apple"
    "ID002" = "Banana"
    "ID003" = "Cherry"
    "ID004" = "Date"
}

# --- GUI要素作成関数 ---
function New-DataGridView {
<#
.SYNOPSIS
DataGridViewコントロールを作成し、列を定義します。
#>
    param(
        [Parameter(Mandatory=$true)]
        [System.Windows.Forms.Form]$Form
    )

    $dataGridView = New-Object System.Windows.Forms.DataGridView
    $dataGridView.Dock = [System.Windows.Forms.DockStyle]::Fill
    $dataGridView.AllowUserToAddRows = $true
    $dataGridView.AllowUserToDeleteRows = $true
    $dataGridView.ColumnHeadersVisible = $true
    $dataGridView.RowHeadersVisible = $false # 行ヘッダーを非表示にする
    $dataGridView.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::CellSelect
    $dataGridView.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
    $Form.Controls.Add($dataGridView) | Out-Null

    # ID列
    $colId = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colId.Name = "ID"
    $colId.HeaderText = $COL_ID_HEADER
    $colId.FillWeight = $COL_ID_FILLWEIGHT
    $dataGridView.Columns.Add($colId) | Out-Null

    # 値列
    $colValue = New-Object System.Windows.Forms.DataGridViewTextBoxColumn
    $colValue.Name = "Value"
    $colValue.HeaderText = $COL_VALUE_HEADER
    $colValue.ReadOnly = $true
    $colValue.DefaultCellStyle.BackColor = $READONLY_BACKCOLOR
    $colValue.FillWeight = $COL_VALUE_FILLWEIGHT
    $dataGridView.Columns.Add($colValue) | Out-Null

    # 初期行の追加
    for ($i = 0; $i -lt $INITIAL_ROWS; $i++) {
        $dataGridView.Rows.Add() | Out-Null
    }

    return $dataGridView
}

function New-MainForm {
<#
.SYNOPSIS
メインとなるWindowsフォームを作成し、コントロールを配置します。
#>
    $form = New-Object System.Windows.Forms.Form
    $form.Text = $APP_TITLE
    $form.StartPosition = "CenterScreen"
    $form.FormBorderStyle = "FixedSingle"
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.AutoSize = $true
    $form.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $form.Padding = $FORM_PADDING
    $form.MinimumSize = [System.Drawing.Size]::new($FORM_WIDTH, $FORM_HEIGHT)

    # ボタンパネルの作成 (FlowLayoutPanelを使用)
    $buttonPanel = New-Object System.Windows.Forms.FlowLayoutPanel
    $buttonPanel.FlowDirection = [System.Windows.Forms.FlowDirection]::RightToLeft # 右から左へ配置
    $buttonPanel.AutoSize = $true
    $buttonPanel.AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowAndShrink
    $buttonPanel.Dock = [System.Windows.Forms.DockStyle]::Bottom # フォームの下部にドック
    $buttonPanel.Padding = [System.Windows.Forms.Padding]::new(0, 5, 10, 5) # 上下左右の余白
    $form.Controls.Add($buttonPanel) | Out-Null

    # DataGridViewの作成と追加
    $script:dataGridView = New-DataGridView -Form $form

    # CSVからデータを読み込み、DataGridViewを補完
    Load-CsvToDataGridView -DataGridView $script:dataGridView | Out-Null

    # OKボタン
    $buttonOk = New-Object System.Windows.Forms.Button
    $buttonOk.Text = $BUTTON_OK_TEXT
    $buttonOk.Size = [System.Drawing.Size]::new($BUTTON_WIDTH, $BUTTON_HEIGHT)
    $buttonOk.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $buttonOk.Add_Click({ Save-DataGridViewToCsv -DataGridView $script:dataGridView })
    $buttonPanel.Controls.Add($buttonOk) | Out-Null

    # キャンセルボタン
    $buttonCancel = New-Object System.Windows.Forms.Button
    $buttonCancel.Text = $BUTTON_CANCEL_TEXT
    $buttonCancel.Size = [System.Drawing.Size]::new($BUTTON_WIDTH, $BUTTON_HEIGHT)
    $buttonCancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $buttonPanel.Controls.Add($buttonCancel) | Out-Null

    # --- DataGridViewのCellValueChangedイベントハンドラ ---
    $script:dataGridView.Add_CellValueChanged({
        param($sender, $e)

        # ID列の変更のみを処理
        if ($e.ColumnIndex -eq $script:dataGridView.Columns["ID"].Index -and $e.RowIndex -ge 0) {
            $currentRow = $script:dataGridView.Rows[$e.RowIndex]
            $id = $currentRow.Cells["ID"].Value

            if ($id -ne $null -and $id.ToString().Trim() -ne "") {
                $trimmedId = $id.ToString().Trim()
                if ($data.ContainsKey($trimmedId)) {
                    $currentRow.Cells["Value"].Value = $data[$trimmedId]
                } else {
                    $currentRow.Cells["Value"].Value = ""
                }
            }
            else {
                $currentRow.Cells["Value"].Value = ""
            }
        }
    })

    return $form
}

# --- データ保存関数 ---
function Save-DataGridViewToCsv {
<#
.SYNOPSIS
DataGridViewの内容をCSVファイルに保存します。
#>
    param(
        [Parameter(Mandatory=$true)]
        [System.Windows.Forms.DataGridView]$DataGridView
    )

    $csvContent = @()
    # ヘッダー行を追加
    $csvContent += "`"ID`",`"Value`""

    foreach ($row in $DataGridView.Rows) {
        # 新規行で、ID列が空の場合はスキップ
        if ($row.IsNewRow -or [string]::IsNullOrEmpty($row.Cells["ID"].Value)) {
            continue
        }

        $id = ($row.Cells["ID"].Value | Out-String).Trim()
        $value = ($row.Cells["Value"].Value | Out-String).Trim()

        # CSV形式で追加
        $csvContent += "`"$id`",`"$value`""
    }

    try {
        $csvContent | Set-Content -Path $CSV_FILE_PATH -Encoding UTF8
        Write-Host "Data saved to $CSV_FILE_PATH"
    } catch {
        Write-Error "Failed to save data to CSV: $($_.Exception.Message)"
    }
}

# --- データ読み込み関数 ---
function Load-CsvToDataGridView {
<#
.SYNOPSIS
CSVファイルからデータを読み込み、DataGridViewを補完します。
#>
    param(
        [Parameter(Mandatory=$true)]
        [System.Windows.Forms.DataGridView]$DataGridView
    )

    if (Test-Path $CSV_FILE_PATH) {
        try {
            $csvData = Import-Csv -Path $CSV_FILE_PATH -Encoding UTF8

            # DataGridViewをクリア
            $DataGridView.Rows.Clear()

            foreach ($row in $csvData) {
                $DataGridView.Rows.Add($row.ID, $row.Value)
            }
            # 少なくともINITIAL_ROWSの行を確保
            while ($DataGridView.Rows.Count -lt $INITIAL_ROWS) {
                $DataGridView.Rows.Add() | Out-Null
            }

            Write-Host "Data loaded from $CSV_FILE_PATH"
        } catch {
            Write-Error "Failed to load data from CSV: $($_.Exception.Message)"
        }
    } else {
        Write-Host "CSV file not found: $CSV_FILE_PATH. Starting with empty DataGridView."
    }
}

# --- メインロジック ---
$mainForm = New-MainForm
$mainForm.ShowDialog() | Out-Null