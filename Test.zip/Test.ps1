﻿
    try {
        $session = New-CsvManagerSession -FilePath $testCsvPath -Columns $testColumns -Encoding $defaultEncoding -MaxRetries $defaultMaxRetries -RetryIntervalMs $defaultRetryIntervalMs
        if ($session.FilePath -eq $testCsvPath) {
            Write-Host "  [SUCCESS] Session initialized with matching header without error."
        } else {
            throw "Session properties are wrong. Session Path: $($session.FilePath)"
        }
    } catch {
        Write-Host "  [FAILURE] An unexpected error occurred during session initialization: $_"
        return
    }

    # Test 3: Existing file with mismatched header
    Write-Host "Test 3: Existing file with mismatched header..."
    try {
        $mismatchedColumns = @("ID", "Name", "DifferentValue")
        $session = New-CsvManagerSession -FilePath $testCsvPath -Columns $mismatchedColumns -Encoding $defaultEncoding -MaxRetries $defaultMaxRetries -RetryIntervalMs $defaultRetryIntervalMs
        # If this line is reached, the test failed
        Write-Host "  [FAILURE] SchemaValidationException was not thrown."
        return
    } catch [SchemaValidationException] {
        Write-Host "  [SUCCESS] Correctly caught SchemaValidationException."
    } catch {
        Write-Host "  [FAILURE] An unexpected exception was thrown: $_"
        return
    }

    Write-Host "--- Session Creation Tests Passed ---"

    #region CRUD Tests
    Write-Host "--- Running CRUD Tests ---"
    $crudTestCsvPath = ".\crud_test.csv"
    $crudTestColumns = @("ID", "Name", "Status", "Version")
    
    # Cleanup previous test files if they exist and re-create session with new file
    if (Test-Path $crudTestCsvPath) {
        Remove-Item $crudTestCsvPath
    }
    $crudSession = New-CsvManagerSession -FilePath $crudTestCsvPath -Columns $crudTestColumns -Encoding $defaultEncoding -MaxRetries $defaultMaxRetries -RetryIntervalMs $defaultRetryIntervalMs # Re-create fresh session after cleanup


    # Test: Upsert (Insert)
    Write-Host "Test: Upsert (Insert) - Adding new records..."
    try {
        $data = @{ID="1"; Name="Alice"; Status="Active"; Version="1"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols
        $data = @{ID="2"; Name="Bob"; Status="Inactive"; Version="1"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols
        $data = @{ID="3"; Name="Charlie"; Status="Pending"; Version="1"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols

        Write-Host "  DEBUG: Content of $crudTestCsvPath after inserts:"
        Get-Content -Path $crudTestCsvPath | ForEach-Object { Write-Host "    $_" }

        $records = Get-CsvData -SessionObject $crudSession -Filter @{}
        Write-Host "  DEBUG: Test runner sees $($records.Count) records."
        if ($records.Count -eq 3 -and $records[0].Name -eq "Alice" -and $records[1].Name -eq "Bob") {
            Write-Host "  [SUCCESS] Records inserted correctly."
        } else {
            throw "Failed to insert records. Count: $($records.Count)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Insert) failed: $_"
        return
    }

    # Test: Read (Filter)
    Write-Host "Test: Read (Filter) - Filtering records..."
    try {
        $filter = @{Status="Active"}
        $filtered = Get-CsvData -SessionObject $crudSession -Filter $filter
        if ($filtered.Count -eq 1 -and $filtered[0].ID -eq "1") {
            Write-Host "  [SUCCESS] Records filtered correctly."
        } else {
            throw "Failed to filter records. Count: $($filtered.Count)"
        }
    } catch {
        Write-Host "  [FAILURE] Read (Filter) failed: $_"
        return
    }

    # Test: Upsert (Update)
    Write-Host "Test: Upsert (Update) - Updating existing record..."
    try {
        $data = @{ID="1"; Status="Inactive"; Version="2"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols # Alice's status to Inactive, Version to 2
        $filter = @{ID="1"}
        $updatedAlice = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($updatedAlice.Status -eq "Inactive" -and $updatedAlice.Version -eq "2") {
            Write-Host "  [SUCCESS] Record updated correctly."
        } else {
            throw "Failed to update record. Status: $($updatedAlice.Status), Version: $($updatedAlice.Version)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Update) failed: $_"
        return
    }

    # Test: Upsert (Partial Update)
    Write-Host "Test: Upsert (Partial Update) - Updating only one field..."
    try {
        $data = @{ID="2"; Name="Bobby"; Version="2"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols # Bob's name to Bobby, Version to 2
        $filter = @{ID="2"}
        $updatedBob = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($updatedBob.Name -eq "Bobby" -and $updatedBob.Status -eq "Inactive" -and $updatedBob.Version -eq "2") {
            Write-Host "  [SUCCESS] Partial update successful."
        } else {
            throw "Failed to partial update record. Name: $($updatedBob.Name), Status: $($updatedBob.Status), Version: $($updatedBob.Version)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Partial Update) failed: $_"
        return
    }

    # Test: Upsert (-Unique) - DuplicateKeyException for update
    Write-Host "Test: Upsert (-Unique) - Expecting DuplicateKeyException for update..."
    try {
        $data = @{ID="1"; Name="AliceX"; Status="Active"; Version="3"}
        $keyCols = @("Status")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Unique # Unique=$true
        Write-Host "  [FAILURE] DuplicateKeyException was not thrown for unique update."
        return
    } catch [DuplicateKeyException] {
        Write-Host "  [SUCCESS] Correctly caught DuplicateKeyException for unique update."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for unique update: $_"
        return
    }
    
    # Test: Upsert (-Unique) - DuplicateKeyException for insert
    Write-Host "Test: Upsert (-Unique) - Expecting DuplicateKeyException for insert..."
    try {
        $data = @{ID="4"; Name="Diana"; Status="Active"; Version="1"}
        $keyCols = @("Status")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Unique # Unique=$true
        Write-Host "  [FAILURE] DuplicateKeyException was not thrown for unique insert."
        return
    } catch [DuplicateKeyException] {
        Write-Host "  [SUCCESS] Correctly caught DuplicateKeyException for unique insert."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for unique insert: $_"
        return
    }

    # Test: Read (-Unique) - Single record found
    Write-Host "Test: Read (-Unique) - Single record found..."
    try {
        $filter = @{ID="2"}
        $record = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($null -ne $record -and $record.Name -eq "Bobby") {
            Write-Host "  [SUCCESS] Read -Unique returned single record."
        } else {
            throw "Read -Unique failed. Record: $($record | ConvertTo-Json -Compress)"
        }
    } catch {
        Write-Host "  [FAILURE] Read (-Unique) failed: $_"
        return
    }

    # Test: Read (-Unique) - No record found
    Write-Host "Test: Read (-Unique) - No record found..."
    try {
        $filter = @{ID="99"}
        $record = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($null -eq $record) {
            Write-Host "  [SUCCESS] Read -Unique returned null for no record."
        } else {
            throw "Read -Unique failed. Record: $($record | ConvertTo-Json -Compress)"
        }
    } catch {
        Write-Host "  [FAILURE] Read (-Unique) failed: $_"
        return
    }

    # Test: Read (-Unique) - DuplicateKeyException for multiple records
    Write-Host "Test: Read (-Unique) - Expecting DuplicateKeyException for multiple records..."
    try {
        # Status="Inactive" のレコードはAliceとBobbyの2つ
        $filter = @{Status="Inactive"}
        $records = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        Write-Host "  [FAILURE] DuplicateKeyException was not thrown for multiple records with -Unique."
        return
    } catch [DuplicateKeyException] {
        Write-Host "  [SUCCESS] Correctly caught DuplicateKeyException for multiple records with -Unique."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for Read (-Unique) multiple: $_"
        return
    }

    # Test: Upsert (Optimistic Locking) - Successful update
    Write-Host "Test: Upsert (Optimistic Locking) - Successful update..."
    try {
        # AliceのStatusは"Inactive", Versionは"2"のはず
        $data = @{ID="1"; Status="Active"; Version="3"}
        $keyCols = @("ID")
        $assumeData = @{Status="Inactive"; Version="2"}
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Assume $assumeData # Unique=$false, Assume=$assumeData
        $filter = @{ID="1"}
        $updatedAlice = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($updatedAlice.Status -eq "Active" -and $updatedAlice.Version -eq "3") {
            Write-Host "  [SUCCESS] Optimistic locking update successful."
        } else {
            throw "Failed optimistic locking update. Status: $($updatedAlice.Status), Version: $($updatedAlice.Version)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Optimistic Locking) failed: $_"
        return
    }

    # Test: Upsert (Optimistic Locking) - Expecting OptimisticLockingException
    Write-Host "Test: Upsert (Optimistic Locking) - Expecting OptimisticLockingException..."
    try {
        # AliceのStatusは"Active", Versionは"3"になっているはずだが、"Inactive", "2"を想定
        $data = @{ID="1"; Status="Archived"; Version="4"}
        $keyCols = @("ID")
        $assumeData = @{Status="Inactive"; Version="2"}
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Assume $assumeData # Unique=$false, Assume=$assumeData
        Write-Host "  [FAILURE] OptimisticLockingException was not thrown."
        return
    } catch [OptimisticLockingException] {
        Write-Host "  [SUCCESS] Correctly caught OptimisticLockingException."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for optimistic locking: $_"
        return
    }

    Write-Host "--- CRUD Tests Passed ---"
    #endregion

    #region Lock Timeout Test
    Write-Host "--- Running Lock Timeout Test ---"
    $lockTestCsvPath = ".\lock_timeout_test.csv"
    $lockTestColumns = @("Key", "Data")
    
    # Clean up previous test files if they exist
    if ($null -ne $lockTestCsvPath -and (Test-Path $lockTestCsvPath)) {
        Remove-Item $lockTestCsvPath
    }

    $lockSession = New-CsvManagerSession -FilePath $lockTestCsvPath -Columns $lockTestColumns -Encoding $defaultEncoding -MaxRetries 2 -RetryIntervalMs 200 # MaxRetriesを2、RetryIntervalMsを200msに設定

    $lockScriptBlock = {param($filePath, $encoding, $maxRetries, $retryIntervalMs)
        # ロックを長時間保持する
        $fs = $null
        try {
            $fs = _Acquire-CsvFileLock -FilePath $filePath -MaxRetries 1 -RetryIntervalMs 100 # acquire with minimal retries
            # 実際には何も書き込まず、ロックだけを保持
            Start-Sleep -Seconds 3 # 3秒間ロックを保持
        } catch {
            Write-Error "Child process failed to acquire lock: $_"
        } finally {
            if ($fs) {
                $fs.Dispose()
            }
        }
    }

    $job = Start-Job -ScriptBlock $lockScriptBlock -ArgumentList $lockTestCsvPath, $defaultEncoding, $lockSession.MaxRetries, $lockSession.RetryIntervalMs
    
    # 子プロセスがロックを取得するまで少し待つ
    Start-Sleep -Milliseconds 500

    try {
        Write-Host "Test: Lock Timeout - Attempting Upsert while file is locked..."
        $crudData = @{Key="A"; Data="Value"}
        $keyCols = @("Key")
        Invoke-CsvUpsert -SessionObject $lockSession -Data $crudData -KeyColumns $keyCols
        Write-Host "  [FAILURE] LockTimeoutException was not thrown."
        return
    } catch [LockTimeoutException] {
        Write-Host "  [SUCCESS] Correctly caught LockTimeoutException."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for lock timeout test: $_"
        return
    } finally {
        # ジョブが完了するのを待ってからクリーンアップ
        Wait-Job $job | Out-Null
        Receive-Job $job | Out-Host # ジョブの出力を表示
        Remove-Job $job

        if ($null -ne $lockTestCsvPath -and (Test-Path $lockTestCsvPath)) {
            Remove-Item $lockTestCsvPath
        }
    }
    Write-Host "--- Lock Timeout Test Passed ---"
    #endregion

} finally {
    #region Cleanup
    if (Test-Path $testCsvPath) {
        Remove-Item $testCsvPath
    }
    if (Test-Path $crudTestCsvPath) {
        Remove-Item $crudTestCsvPath
    }
    if ($null -ne $lockTestCsvPath ) {
        if (Test-Path $lockTestCsvPath) {Remove-Item $lockTestCsvPath}
    }
    #endregion
}

    # Test 2: Existing file with matching header
    Write-Host "Test 2: Existing file with matching header..."
    try {
        $session = New-CsvManagerSession -FilePath $testCsvPath -Columns $testColumns -Encoding $defaultEncoding -MaxRetries $defaultMaxRetries -RetryIntervalMs $defaultRetryIntervalMs
        if ($session.FilePath -eq $testCsvPath) {
            Write-Host "  [SUCCESS] Session initialized with matching header without error."
        } else {
            throw "Session properties are wrong. Session Path: $($session.FilePath)"
        }
    } catch {
        Write-Host "  [FAILURE] An unexpected error occurred during session initialization: $_"
        return
    }

    # Test 3: Existing file with mismatched header
    Write-Host "Test 3: Existing file with mismatched header..."
    try {
        $mismatchedColumns = @("ID", "Name", "DifferentValue")
        $session = New-CsvManagerSession -FilePath $testCsvPath -Columns $mismatchedColumns -Encoding $defaultEncoding -MaxRetries $defaultMaxRetries -RetryIntervalMs $defaultRetryIntervalMs
        # If this line is reached, the test failed
        Write-Host "  [FAILURE] SchemaValidationException was not thrown."
        return
    } catch [SchemaValidationException] {
        Write-Host "  [SUCCESS] Correctly caught SchemaValidationException."
    } catch {
        Write-Host "  [FAILURE] An unexpected exception was thrown: $_"
        return
    }

    Write-Host "--- Session Creation Tests Passed ---"

    #region CRUD Tests
    Write-Host "--- Running CRUD Tests ---"
    $crudTestCsvPath = ".\crud_test.csv"
    $crudTestColumns = @("ID", "Name", "Status", "Version")
    
    # Cleanup previous test files if they exist and re-create session with new file
    if (Test-Path $crudTestCsvPath) {
        Remove-Item $crudTestCsvPath
    }
    $crudSession = New-CsvManagerSession -FilePath $crudTestCsvPath -Columns $crudTestColumns -Encoding $defaultEncoding -MaxRetries $defaultMaxRetries -RetryIntervalMs $defaultRetryIntervalMs # Re-create fresh session after cleanup


    # Test: Upsert (Insert)
    Write-Host "Test: Upsert (Insert) - Adding new records..."
    try {
        $data = @{ID="1"; Name="Alice"; Status="Active"; Version="1"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols
        $data = @{ID="2"; Name="Bob"; Status="Inactive"; Version="1"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols
        $data = @{ID="3"; Name="Charlie"; Status="Pending"; Version="1"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols

        Write-Host "  DEBUG: Content of $crudTestCsvPath after inserts:"
        Get-Content -Path $crudTestCsvPath | ForEach-Object { Write-Host "    $_" }

        $records = Get-CsvData -SessionObject $crudSession -Filter @{}
        Write-Host "  DEBUG: Test runner sees $($records.Count) records."
        if ($records.Count -eq 3 -and $records[0].Name -eq "Alice" -and $records[1].Name -eq "Bob") {
            Write-Host "  [SUCCESS] Records inserted correctly."
        } else {
            throw "Failed to insert records. Count: $($records.Count)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Insert) failed: $_"
        return
    }

    # Test: Read (Filter)
    Write-Host "Test: Read (Filter) - Filtering records..."
    try {
        $filter = @{Status="Active"}
        $filtered = Get-CsvData -SessionObject $crudSession -Filter $filter
        if ($filtered.Count -eq 1 -and $filtered[0].ID -eq "1") {
            Write-Host "  [SUCCESS] Records filtered correctly."
        } else {
            throw "Failed to filter records. Count: $($filtered.Count)"
        }
    } catch {
        Write-Host "  [FAILURE] Read (Filter) failed: $_"
        return
    }

    # Test: Upsert (Update)
    Write-Host "Test: Upsert (Update) - Updating existing record..."
    try {
        $data = @{ID="1"; Status="Inactive"; Version="2"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols # Alice's status to Inactive, Version to 2
        $filter = @{ID="1"}
        $updatedAlice = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($updatedAlice.Status -eq "Inactive" -and $updatedAlice.Version -eq "2") {
            Write-Host "  [SUCCESS] Record updated correctly."
        } else {
            throw "Failed to update record. Status: $($updatedAlice.Status), Version: $($updatedAlice.Version)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Update) failed: $_"
        return
    }

    # Test: Upsert (Partial Update)
    Write-Host "Test: Upsert (Partial Update) - Updating only one field..."
    try {
        $data = @{ID="2"; Name="Bobby"; Version="2"}
        $keyCols = @("ID")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols # Bob's name to Bobby, Version to 2
        $filter = @{ID="2"}
        $updatedBob = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($updatedBob.Name -eq "Bobby" -and $updatedBob.Status -eq "Inactive" -and $updatedBob.Version -eq "2") {
            Write-Host "  [SUCCESS] Partial update successful."
        } else {
            throw "Failed to partial update record. Name: $($updatedBob.Name), Status: $($updatedBob.Status), Version: $($updatedBob.Version)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Partial Update) failed: $_"
        return
    }

    # Test: Upsert (-Unique) - DuplicateKeyException for update
    Write-Host "Test: Upsert (-Unique) - Expecting DuplicateKeyException for update..."
    try {
        $data = @{ID="1"; Name="AliceX"; Status="Active"; Version="3"}
        $keyCols = @("Status")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Unique # Unique=$true
        Write-Host "  [FAILURE] DuplicateKeyException was not thrown for unique update."
        return
    } catch [DuplicateKeyException] {
        Write-Host "  [SUCCESS] Correctly caught DuplicateKeyException for unique update."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for unique update: $_"
        return
    }
    
    # Test: Upsert (-Unique) - DuplicateKeyException for insert
    Write-Host "Test: Upsert (-Unique) - Expecting DuplicateKeyException for insert..."
    try {
        $data = @{ID="4"; Name="Diana"; Status="Active"; Version="1"}
        $keyCols = @("Status")
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Unique # Unique=$true
        Write-Host "  [FAILURE] DuplicateKeyException was not thrown for unique insert."
        return
    } catch [DuplicateKeyException] {
        Write-Host "  [SUCCESS] Correctly caught DuplicateKeyException for unique insert."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for unique insert: $_"
        return
    }

    # Test: Read (-Unique) - Single record found
    Write-Host "Test: Read (-Unique) - Single record found..."
    try {
        $filter = @{ID="2"}
        $record = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($null -ne $record -and $record.Name -eq "Bobby") {
            Write-Host "  [SUCCESS] Read -Unique returned single record."
        } else {
            throw "Read -Unique failed. Record: $($record | ConvertTo-Json -Compress)"
        }
    } catch {
        Write-Host "  [FAILURE] Read (-Unique) failed: $_"
        return
    }

    # Test: Read (-Unique) - No record found
    Write-Host "Test: Read (-Unique) - No record found..."
    try {
        $filter = @{ID="99"}
        $record = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($null -eq $record) {
            Write-Host "  [SUCCESS] Read -Unique returned null for no record."
        } else {
            throw "Read -Unique failed. Record: $($record | ConvertTo-Json -Compress)"
        }
    } catch {
        Write-Host "  [FAILURE] Read (-Unique) failed: $_"
        return
    }

    # Test: Read (-Unique) - DuplicateKeyException for multiple records
    Write-Host "Test: Read (-Unique) - Expecting DuplicateKeyException for multiple records..."
    try {
        # Status="Inactive" のレコードはAliceとBobbyの2つ
        $filter = @{Status="Inactive"}
        $records = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        Write-Host "  [FAILURE] DuplicateKeyException was not thrown for multiple records with -Unique."
        return
    } catch [DuplicateKeyException] {
        Write-Host "  [SUCCESS] Correctly caught DuplicateKeyException for multiple records with -Unique."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for Read (-Unique) multiple: $_"
        return
    }

    # Test: Upsert (Optimistic Locking) - Successful update
    Write-Host "Test: Upsert (Optimistic Locking) - Successful update..."
    try {
        # AliceのStatusは"Inactive", Versionは"2"のはず
        $data = @{ID="1"; Status="Active"; Version="3"}
        $keyCols = @("ID")
        $assumeData = @{Status="Inactive"; Version="2"}
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Assume $assumeData # Unique=$false, Assume=$assumeData
        $filter = @{ID="1"}
        $updatedAlice = Get-CsvData -SessionObject $crudSession -Filter $filter -Unique # Unique=$true
        if ($updatedAlice.Status -eq "Active" -and $updatedAlice.Version -eq "3") {
            Write-Host "  [SUCCESS] Optimistic locking update successful."
        } else {
            throw "Failed optimistic locking update. Status: $($updatedAlice.Status), Version: $($updatedAlice.Version)"
        }
    } catch {
        Write-Host "  [FAILURE] Upsert (Optimistic Locking) failed: $_"
        return
    }

    # Test: Upsert (Optimistic Locking) - Expecting OptimisticLockingException
    Write-Host "Test: Upsert (Optimistic Locking) - Expecting OptimisticLockingException..."
    try {
        # AliceのStatusは"Active", Versionは"3"になっているはずだが、"Inactive", "2"を想定
        $data = @{ID="1"; Status="Archived"; Version="4"}
        $keyCols = @("ID")
        $assumeData = @{Status="Inactive"; Version="2"}
        Invoke-CsvUpsert -SessionObject $crudSession -Data $data -KeyColumns $keyCols -Assume $assumeData # Unique=$false, Assume=$assumeData
        Write-Host "  [FAILURE] OptimisticLockingException was not thrown."
        return
    } catch [OptimisticLockingException] {
        Write-Host "  [SUCCESS] Correctly caught OptimisticLockingException."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for optimistic locking: $_"
        return
    }

    Write-Host "--- CRUD Tests Passed ---"
    #endregion

    #region Lock Timeout Test
    Write-Host "--- Running Lock Timeout Test ---"
    $lockTestCsvPath = ".\lock_timeout_test.csv"
    $lockTestColumns = @("Key", "Data")
    
    # Clean up previous test files if they exist
    if ($null -ne $lockTestCsvPath -and (Test-Path $lockTestCsvPath)) {
        Remove-Item $lockTestCsvPath
    }

    $lockSession = New-CsvManagerSession -FilePath $lockTestCsvPath -Columns $lockTestColumns -Encoding $defaultEncoding -MaxRetries 2 -RetryIntervalMs 200 # MaxRetriesを2、RetryIntervalMsを200msに設定

    $lockScriptBlock = {param($filePath, $encoding, $maxRetries, $retryIntervalMs)
        # ロックを長時間保持する
        $fs = $null
        try {
            $fs = _Acquire-CsvFileLock -FilePath $filePath -MaxRetries 1 -RetryIntervalMs 100 # acquire with minimal retries
            # 実際には何も書き込まず、ロックだけを保持
            Start-Sleep -Seconds 3 # 3秒間ロックを保持
        } catch {
            Write-Error "Child process failed to acquire lock: $_"
        } finally {
            if ($fs) {
                $fs.Dispose()
            }
        }
    }

    $job = Start-Job -ScriptBlock $lockScriptBlock -ArgumentList $lockTestCsvPath, $defaultEncoding, $lockSession.MaxRetries, $lockSession.RetryIntervalMs
    
    # 子プロセスがロックを取得するまで少し待つ
    Start-Sleep -Milliseconds 500

    try {
        Write-Host "Test: Lock Timeout - Attempting Upsert while file is locked..."
        $crudData = @{Key="A"; Data="Value"}
        $keyCols = @("Key")
        Invoke-CsvUpsert -SessionObject $lockSession -Data $crudData -KeyColumns $keyCols
        Write-Host "  [FAILURE] LockTimeoutException was not thrown."
        return
    } catch [LockTimeoutException] {
        Write-Host "  [SUCCESS] Correctly caught LockTimeoutException."
    } catch {
        Write-Host "  [FAILURE] Unexpected exception for lock timeout test: $_"
        return
    } finally {
        # ジョブが完了するのを待ってからクリーンアップ
        Wait-Job $job | Out-Null
        Receive-Job $job | Out-Host # ジョブの出力を表示
        Remove-Job $job

        if ($null -ne $lockTestCsvPath -and (Test-Path $lockTestCsvPath)) {
            Remove-Item $lockTestCsvPath
        }
    }
    Write-Host "--- Lock Timeout Test Passed ---"
    #endregion

} finally {
    #region Cleanup
    if (Test-Path $testCsvPath) {
        Remove-Item $testCsvPath
    }
    if (Test-Path $crudTestCsvPath) {
        Remove-Item $crudTestCsvPath
    }
    if ($null -ne $lockTestCsvPath ) {
        if (Test-Path $lockTestCsvPath) {Remove-Item $lockTestCsvPath}
    }
    #endregion
}