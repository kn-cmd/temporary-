﻿function New-BrokenForm {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object System.Windows.Forms.Form
    
    # (1) 関数内で変数を定義する
    $message = "こんにちは、世界！"

    $button = New-Object System.Windows.Forms.Button
    $button.Text = "メッセージ表示"
    $button.Add_Click({
        # (3) ボタンがクリックされた時、この処理が実行されるが...
        [System.Windows.Forms.MessageBox]::Show($message) # $message は $null になっている！
    })
    
    $form.Controls.Add($button)
    return $form
}

# (2) 関数を呼び出し、フォームを表示する
$myForm = New-BrokenForm
$myForm.ShowDialog()