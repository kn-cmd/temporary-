﻿# GUI.ps1

Add-Type -AssemblyName System.Windows.Forms

# 依存するクラス定義を読み込む
. (Join-Path -Path $PSScriptRoot -ChildPath "EventHandlers.ps1")

function New-AppForm {
    param(
        [hashtable]$AppSettings # 外部から設定を受け取る
    )
    
    # 1. アプリの「頭脳」をインスタンス化
    $appLogic = [AppLogic]::new()
    $appLogic.Settings = $AppSettings

    # 2. UI部品を生成
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "クラスベース設計"
    $form.ClientSize = [System.Drawing.Size]::new(280, 250)
    $form.StartPosition = "CenterScreen"

    $textBox = New-Object System.Windows.Forms.TextBox
    $textBox.Location = [System.Drawing.Point]::new(10, 10)
    $textBox.Size = [System.Drawing.Size]::new(180, 20)

    $addButton = New-Object System.Windows.Forms.Button
    $addButton.Text = "追加"
    $addButton.Location = [System.Drawing.Point]::new(200, 8)
    $addButton.Size = [System.Drawing.Size]::new(70, 23)

    $listBox = New-Object System.Windows.Forms.ListBox
    $listBox.Location = [System.Drawing.Point]::new(10, 40)
    $listBox.Size = [System.Drawing.Size]::new(260, 160)
    $listBox.Anchor = "Top, Bottom, Left, Right"

    $clearButton = New-Object System.Windows.Forms.Button
    $clearButton.Text = "クリア"
    $clearButton.Location = [System.Drawing.Point]::new(200, 210)
    $clearButton.Size = [System.Drawing.Size]::new(70, 23)
    $clearButton.Anchor = "Bottom, Right"
    
    # 3. 「頭脳」にUI部品を登録して組み立てる
    $appLogic.UserNameTextBox = $textBox
    $appLogic.LogListBox      = $listBox

    # 4. 完成した「頭脳」をフォームのTagに格納
    $form.Tag = $appLogic
    
    # 5. イベントを「頭脳」のメソッドに接続
    $addButton.Add_Click({ 
        param($sender, $e)
        $sender.FindForm().Tag.HandleAddButtonClick()
    })
    $clearButton.Add_Click({ 
        param($sender, $e)
        $sender.FindForm().Tag.HandleClearButtonClick()
    })

    $form.Controls.AddRange(@($textBox, $listBox, $addButton, $clearButton))
    return $form
}

