﻿# EventHandlers.ps1

class AppLogic {
    # --- 状態 (State) ---
    # このアプリが必要とするUI部品や設定値をプロパティとして定義
    [System.Windows.Forms.TextBox] $UserNameTextBox
    [System.Windows.Forms.ListBox]   $LogListBox
    [hashtable] $Settings

    # --- 振る舞い (Logic) ---
    # 各ボタンが実行する処理をメソッドとして定義
    HandleAddButtonClick() {
        # メソッド内では、自分自身のプロパティ($this)に安全にアクセスできる
        $userName = $this.UserNameTextBox.Text
        if ([string]::IsNullOrWhiteSpace($userName)) { return }

        $logFilePath = $this.Settings.LogFilePath
        $logEntry = "[{0}] USER ADDED: {1}" -f (Get-Date -Format "HH:mm:ss"), $userName
        
        Add-Content -Path $logFilePath -Value $logEntry
        $this.LogListBox.Items.Add($logEntry)
        $this.UserNameTextBox.Clear()
        $this.UserNameTextBox.Focus()
    }

    HandleClearButtonClick() {
        $this.LogListBox.Items.Clear()
    }
}