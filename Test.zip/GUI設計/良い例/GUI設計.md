## PowerShell GUI講座：クラス設計で「変数が消える問題」を完全克服する

### はじめに

PowerShellでGUIアプリを作り始めると、多くの人が「**ボタンを押すと変数の中身が消える**」という謎の現象に遭遇します。これは、GUIプログラミングにおける最初の、そして最大の壁と言えるかもしれません。

この資料では、この問題の根本原因から、最終的な解決策である**プロフェッショナルなクラスベース設計**までを、順を追って丁寧に解説します。この設計をマスターすれば、複雑なアプリでも破綻しない、安定したGUI開発が可能になります。

---

### 第1章：問題の核心 - なぜ変数は消えるのか？

すべての問題は、PowerShellの「**スコープ（変数の寿命）**」と「**イベント（ユーザー操作）**」の仕組みから生じます。

#### 失敗例：動かないコード

まずは、典型的な失敗例を見てみましょう。ボタンを押してもメッセージは表示されません。

```powershell
function New-BrokenForm {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object System.Windows.Forms.Form
    
    # (1) 関数の中で変数を定義
    $message = "こんにちは、世界！"

    $button = New-Object System.Windows.Forms.Button
    $button.Text = "メッセージ表示"
    $button.Add_Click({
        # (3) ボタンがクリックされた時、この処理が実行されるが...
        [System.Windows.Forms.MessageBox]::Show($message) # $message は $null になっている！
    })
    
    $form.Controls.Add($button)
    return $form
}

# (2) 関数を呼び出し、フォームを表示
$myForm = New-BrokenForm
$myForm.ShowDialog()
```

#### 原因：関数の「スコープ」という作業部屋

なぜ`$message`変数は消えてしまうのでしょうか。それは、コードが実行される時間差にあります。

1.  **フォーム生成時 (`New-BrokenForm` 実行中)**
    *   PowerShellは、関数を実行するために一時的な**「作業部屋（スコープ）」**を用意します。
    *   変数 `$message` は、この「作業部屋」の中に作られます。
    *   この時点では `$message` は存在しており、`Add_Click` の `{}` にもその情報が渡されます。

2.  **関数の終了**
    *   関数がフォームオブジェクト (`$form`) を返し終わると、その役目は完了です。
    *   **【最重要】** この時、一時的に作られた「作業部屋」は**跡形もなく解体されます。**
    *   当然、中にあった `$message` 変数も一緒に消滅します。

3.  **ボタンクリック時 (未来)**
    *   ユーザーがボタンを押すと、登録されていた処理が実行されます。
    *   しかし、`$message` があったはずの「作業部屋」はもう存在しません。
    *   結果、変数は見つからず `$null` (空) として扱われてしまいます。

> **教訓：** 関数のローカル変数は、関数が終われば消える運命にあります。

---

### 第2章：解決への道筋 - 消えない入れ物を見つける

変数が消えるなら、**関数が終わっても消えない場所**に保管すれば解決します。そのための最も安全な場所が、ウィンドウが閉じるまでメモリに残り続ける**フォームオブジェクト自身**です。

#### アイデア：フォームの`Tag`プロパティという「名札」を使う

全てのUI部品は `Tag` という汎用のプロパティを持っています。ここには何でも好きなデータを格納できます。この `Tag` を、アプリの情報を詰め込む「**データ保管庫**」として利用します。

```
┌──────────────────┐
│ Formオブジェクト │
├──────────────────┤
│ Text: "アプリ名" │
│ Size: {300, 300} │
│ ...              │
│                  │
│ Tag: [保管庫]    │ ← ここに必要な情報をすべて格納する！
└──────────────────┘
```

しかし、複数の変数やロジックをバラバラに`Tag`へ詰め込むと、すぐに管理が難しくなります。そこで、もっとスマートな方法が必要になります。

#### 発展：状態と振る舞いを「カプセル化」する

ここで登場するのが**クラス**です。クラスとは、関連する**データ（状態）**と**処理（振る舞い）**を、一つの「カプセル」にまとめるための設計図です。

この「カプセル」を丸ごと`Tag`プロパティに格納すれば、データも処理も一元管理でき、コードが非常にクリーンになります。これがクラスベース設計の核心です。

---

### 第3章：最終解決策 - 役割分担によるクラスベース設計

この設計では、アプリケーションを3つの専門家チームに分け、それぞれの役割に専念させます。

1.  **`EventHandlers.ps1` (頭脳チーム):** アプリのロジックとデータをカプセル化した `AppLogic` クラスを定義します。
2.  **`GUI.ps1` (建築チーム):** UIの「見た目」を構築し、イベントを「頭脳」に接続します。
3.  **`Test.ps1` (監督チーム):** 全体を統括し、アプリケーションを起動します。

#### 1. `EventHandlers.ps1` - アプリケーションの「頭脳」

アプリケーションの心臓部です。必要なデータ（プロパティ）と、それらを操作する処理（メソッド）を `AppLogic` クラスとして定義します。

```powershell
# EventHandlers.ps1

class AppLogic {
    # --- 状態 (State) ---
    [System.Windows.Forms.TextBox] $UserNameTextBox
    [System.Windows.Forms.ListBox]   $LogListBox
    [hashtable] $Settings

    # --- 振る舞い (Logic) ---
    HandleAddButtonClick() {
        $userName = $this.UserNameTextBox.Text
        if ([string]::IsNullOrWhiteSpace($userName)) { return }

        $logFilePath = $this.Settings.LogFilePath
        $logEntry = "[{0}] USER ADDED: {1}" -f (Get-Date -Format "HH:mm:ss"), $userName
        
        Add-Content -Path $logFilePath -Value $logEntry
        $this.LogListBox.Items.Add($logEntry)
        $this.UserNameTextBox.Clear()
        $this.UserNameTextBox.Focus()
    }

    HandleClearButtonClick() {
        $this.LogListBox.Items.Clear()
    }
}
```

#### 2. `GUI.ps1` - GUIを組み立てる「建築家」

UI部品を生成して**レイアウト（サイズと位置）を定義**し、各コントロールのイベントを「頭脳」である`AppLogic`のメソッドに接続します。

```powershell
# GUI.ps1

Add-Type -AssemblyName System.Windows.Forms
. (Join-Path -Path $PSScriptRoot -ChildPath "EventHandlers.ps1")

function New-AppForm {
    param([hashtable]$AppSettings)
    
    # 1. 「頭脳」をインスタンス化
    $appLogic = [AppLogic]::new()
    $appLogic.Settings = $AppSettings

    # 2. UI部品を生成し、レイアウトを定義
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "クラスベース設計"
    $form.ClientSize = [System.Drawing.Size]::new(280, 250)
    # ... (各コントロールの Location, Size 設定)
    $textBox = New-Object System.Windows.Forms.TextBox; $textBox.Location = [System.Drawing.Point]::new(10, 10); $textBox.Size = [System.Drawing.Size]::new(180, 20)
    $addButton = New-Object System.Windows.Forms.Button; $addButton.Text = "追加"; $addButton.Location = [System.Drawing.Point]::new(200, 8); $addButton.Size = [System.Drawing.Size]::new(70, 23)
    $listBox = New-Object System.Windows.Forms.ListBox; $listBox.Location = [System.Drawing.Point]::new(10, 40); $listBox.Size = [System.Drawing.Size]::new(260, 160); $listBox.Anchor = "Top, Bottom, Left, Right"
    $clearButton = New-Object System.Windows.Forms.Button; $clearButton.Text = "クリア"; $clearButton.Location = [System.Drawing.Point]::new(200, 210); $clearButton.Size = [System.Drawing.Size]::new(70, 23); $clearButton.Anchor = "Bottom, Right"

    # 3. 「頭脳」にUI部品を登録
    $appLogic.UserNameTextBox = $textBox
    $appLogic.LogListBox      = $listBox

    # 4. 完成した「頭脳」をフォームのTagに格納！
    $form.Tag = $appLogic
    
    # 5. イベントを「頭脳」のメソッドに接続
    $addButton.Add_Click({ 
        param($sender, $e)
        # $senderからフォームを探し、Tag経由で頭脳のメソッドを呼ぶ
        $sender.FindForm().Tag.HandleAddButtonClick()
    })
    $clearButton.Add_Click({ 
        param($sender, $e)
        $sender.FindForm().Tag.HandleClearButtonClick()
    })

    $form.Controls.AddRange(@($textBox, $listBox, $addButton, $clearButton))
    return $form
}
```

**ポイント:**
*   **レイアウト指定の重要性:** UI部品は `.Location` (位置) と `.Size` (大きさ) を指定しないと表示されません。
*   **正しいイベント処理:** `Add_Click` の `{}` 内では `param($sender, $e)` でクリックされたオブジェクト自身 (`$sender`) を受け取って処理するのが定石です。

#### 3. `Test.ps1` - すべてを起動する「監督」

アプリケーションの設定を行い、`GUI.ps1` の関数を呼び出してフォームを表示する、シンプルな起動スクリプトです。

```powershell
# Test.ps1

Import-Module (Join-Path -Path $PSScriptRoot -ChildPath "GUI.ps1") -Force

# アプリケーションの構成を定義
$appSettings = @{ LogFilePath = ".\App.log" }

# 「建築家」に依頼してフォームを生成
$mainForm = New-AppForm -AppSettings $appSettings

# 完成品を表示
$mainForm.ShowDialog()

Write-Host "アプリケーションが終了しました。"
```

---

### まとめ：クラスベース設計の利点

*   **変数が消えない:** 状態とロジックがクラスに保護され、フォームが閉じるまで安全に保持されます。
*   **関心事の分離:** 「ロジック」「見た目」「起動」がファイル単位で明確に分離され、コードの見通しが劇的に良くなります。
*   **高い保守性:** 機能追加や修正の際に、変更すべき箇所が明確になります。例えば、ボタンの処理を変えたいなら`EventHandlers.ps1`を、見た目を変えたいなら`GUI.ps1`を編集すればOKです。

この設計パターンは、PowerShellで本格的かつ安定したGUIアプリケーションを構築するための、強力な武器となります。