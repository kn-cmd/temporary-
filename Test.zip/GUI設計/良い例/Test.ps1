﻿# Main.ps1

# GUI工場をインポート
Import-Module (Join-Path -Path $PSScriptRoot -ChildPath "GUI.ps1") -Force

# アプリケーションの構成を定義
$LogFilePath = ".\App.log"

$appSettings = @{
    LogFilePath = $LogFilePath
}

# 工場に「この設定でアプリを作ってください」とお願いするだけ
$mainForm = New-AppForm -AppSettings $appSettings

# 完成品を表示
$mainForm.ShowDialog()

Write-Host "アプリケーションが終了しました。"