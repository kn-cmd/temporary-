## PowerShell GUI講座："変数が消える問題"をクラス設計で完全克服する

### はじめに

PowerShellでGUIアプリを作り始めると、誰もが一度は経験する謎の現象があります。それは「**ボタンを押しても、さっきまであったはずの変数の中身が空っぽになっている**」という問題です。

この資料では、この問題がなぜ起きるのか、その根本原因を突き止め、よくある間違った解決策を乗り越え、最終的に**複雑なアプリケーションでも破綻しない、プロフェッショナルなクラスベースの設計**にたどり着くまでの道のりを解説します。

---

### 第1章：悪夢のはじまり - なぜ変数は消えるのか？

すべての問題は、PowerShellの「**関数のスコープ（寿命）**」と「**イベント処理のタイミング**」の組み合わせによって引き起こされます。

#### 1-1. `Add_Click`で変数が消える典型的な失敗例

まずは、誰もが最初に書いてしまうであろう、しかし**動かない**コードを見てみましょう。

```powershell
function New-BrokenForm {
    Add-Type -AssemblyName System.Windows.Forms
    $form = New-Object System.Windows.Forms.Form
    
    # (1) 関数内で変数を定義する
    $message = "こんにちは、世界！"

    $button = New-Object System.Windows.Forms.Button
    $button.Text = "メッセージ表示"
    $button.Add_Click({
        # (3) ボタンがクリックされた時、この処理が実行されるが...
        [System.Windows.Forms.MessageBox]::Show($message) # $message は $null になっている！
    })
    
    $form.Controls.Add($button)
    return $form
}

# (2) 関数を呼び出し、フォームを表示する
$myForm = New-BrokenForm
$myForm.ShowDialog()
```

このコードを実行しボタンを押すと、メッセージボックスは**空白**になります。

#### 1-2. 真犯人：関数の「スコープ（作業部屋）」の解体

なぜ`$message`は消えてしまったのでしょうか？その理由は、コードが実行される時間差にあります。

1.  **フォーム生成時 (`New-BrokenForm`実行中):**
    *   PowerShellは`New-BrokenForm`関数のために、一時的な**「作業部屋（スコープ）」**を作ります。
    *   変数`$message`は、この「作業部屋」の中に置かれます。
    *   `Add_Click`に処理を登録します。この時点では、`$message`は確かに存在します。
    *   関数は`$form`オブジェクトを返して**処理を終了します。**

2.  **関数終了と同時に...**
    *   **ここが最重要ポイントです。** 関数が終了すると、そのために用意された「作業部屋」は**容赦なく解体されます。**
    *   その結果、部屋の中にあった**`$message`変数も跡形もなく消え去ってしまいます。**

3.  **ボタンクリック時 (ユーザー操作):**
    *   しばらくしてユーザーがボタンをクリックします。
    *   登録されていた処理が実行され、`$message`変数を探します。
    *   しかし、変数が置かれていた「作業部屋」は既に取り壊されて存在しません。
    *   結果、変数は見つからず`$null`として扱われ、空白のメッセージボックスが表示されるのです。

> **教訓：** 関数のローカル変数は、関数が終了すれば消える運命にある。これは、変数が単純な文字列でも、ハッシュテーブルのような「参照型」でも同じです。

---

### 第2章：解決への探求 - 正しい状態管理とは？

変数が消えるなら、**関数が終了しても消えない場所にデータを保管**すれば解決します。そのための最も安全で公式な場所が、画面が閉じるまでメモリに残り続ける**フォームオブジェクト自身**です。

#### 解決方針：フォームの`Tag`プロパティを「司令塔」にする

全てのUI部品は`Tag`という名前の「データポケット」を持っています。ここに、後で使いたい情報をすべて格納しておくのが定石です。

しかし、ただ`Tag`を使うだけでは、コードが複雑になると可読性が低下します。そこで、最終的なベストプラクティスとして「**クラスベース設計**」を導入します。

---

### 第3章：最終解決策 - クラスベース設計による完全なカプセル化

この設計では、アプリケーションを3つの専門家チームに分け、それぞれの役割に専念させます。

1.  **`EventHandlers.ps1` (頭脳チーム):** アプリケーションの「状態」と「振る舞い」を定義する`AppLogic`クラスを作成します。
2.  **`GUI.ps1` (建築チーム):** UIの「見た目」を構築し、イベントを「頭脳」に接続します。
3.  **`Test.ps1` (監督チーム):** 全体を統括し、アプリケーションを起動します。

#### 1. `EventHandlers.ps1` - アプリケーションの「頭脳」をクラスで定義する

アプリケーションのロジックと、管理すべき状態（データ）をすべて`AppLogic`という一つのクラスに集約します。

```powershell
# EventHandlers.ps1

class AppLogic {
    # --- 状態 (State) ---
    # このアプリが必要とするUI部品や設定値をプロパティとして定義
    [System.Windows.Forms.TextBox] $UserNameTextBox
    [System.Windows.Forms.ListBox]   $LogListBox
    [hashtable] $Settings

    # --- 振る舞い (Logic) ---
    # 各ボタンが実行する処理をメソッドとして定義
    HandleAddButtonClick() {
        # メソッド内では、自分自身のプロパティ($this)に安全にアクセスできる
        $userName = $this.UserNameTextBox.Text
        if ([string]::IsNullOrWhiteSpace($userName)) { return }

        $logFilePath = $this.Settings.LogFilePath
        $logEntry = "[{0}] USER ADDED: {1}" -f (Get-Date -Format "HH:mm:ss"), $userName
        
        Add-Content -Path $logFilePath -Value $logEntry
        $this.LogListBox.Items.Add($logEntry)
        $this.UserNameTextBox.Clear()
        $this.UserNameTextBox.Focus()
    }

    HandleClearButtonClick() {
        $this.LogListBox.Items.Clear()
    }
}
```
**メリット:**
*   **状態とロジックの集約:** アプリの全状態と全ロジックが1つのクラスにまとまっているため、全体像を把握しやすいです。
*   **タイプミスの防止:** `.`を打つとプロパティ名が補完され、存在しないプロパティにアクセスしようとするとエラーになります。

#### 2. `GUI.ps1` - 「頭脳」を組み込むインテリジェントな建築役

ここでは、UI部品を生成して**レイアウト（サイズと位置）を定義**し、**正しい方法でイベントを接続**する、建築の役割を担います。

```powershell
# GUI.ps1

Add-Type -AssemblyName System.Windows.Forms

# 依存するクラス定義を読み込む
. (Join-Path -Path $PSScriptRoot -ChildPath "EventHandlers.ps1")

function New-AppForm {
    param(
        [hashtable]$AppSettings # 外部から設定を受け取る
    )
    
    # 1. アプリの「頭脳」をインスタンス化
    $appLogic = [AppLogic]::new()
    $appLogic.Settings = $AppSettings

    # 2. UI部品を生成し、レイアウトを定義
    $form = New-Object System.Windows.Forms.Form
    $form.Text = "クラスベース設計"
    $form.ClientSize = [System.Drawing.Size]::new(280, 250)
    $form.StartPosition = "CenterScreen"

    $textBox = New-Object System.Windows.Forms.TextBox
    $textBox.Location = [System.Drawing.Point]::new(10, 10)
    $textBox.Size = [System.Drawing.Size]::new(180, 20)

    $addButton = New-Object System.Windows.Forms.Button
    $addButton.Text = "追加"
    $addButton.Location = [System.Drawing.Point]::new(200, 8)
    $addButton.Size = [System.Drawing.Size]::new(70, 23)

    $listBox = New-Object System.Windows.Forms.ListBox
    $listBox.Location = [System.Drawing.Point]::new(10, 40)
    $listBox.Size = [System.Drawing.Size]::new(260, 160)
    $listBox.Anchor = "Top, Bottom, Left, Right"

    $clearButton = New-Object System.Windows.Forms.Button
    $clearButton.Text = "クリア"
    $clearButton.Location = [System.Drawing.Point]::new(200, 210)
    $clearButton.Size = [System.Drawing.Size]::new(70, 23)
    $clearButton.Anchor = "Bottom, Right"
    
    # 3. 「頭脳」にUI部品を登録して組み立てる
    $appLogic.UserNameTextBox = $textBox
    $appLogic.LogListBox      = $listBox

    # 4. 完成した「頭脳」をフォームのTagに格納
    $form.Tag = $appLogic
    
    # 5. イベントを「頭脳」のメソッドに接続
    $addButton.Add_Click({ 
        param($sender, $e)
        $sender.FindForm().Tag.HandleAddButtonClick()
    })
    $clearButton.Add_Click({ 
        param($sender, $e)
        $sender.FindForm().Tag.HandleClearButtonClick()
    })

    $form.Controls.AddRange(@($textBox, $listBox, $addButton, $clearButton))
    return $form
}
```

**ポイント:**
*   **レイアウトの指定:** UI部品は、生成するだけでなく `.Location` (位置) と `.Size` (大きさ) を指定しないと画面に表示されません。きちんとレイアウトを定義することが重要です。
*   **正しいイベント処理:** `Add_Click` の `{}` 内では、自動変数 `$_` はイベント引数を指してしまいます。`param($sender, $e)` のように引数を明示的に定義し、クリックされたオブジェクト自身を指す `$sender` を使って処理を続けます。
*   このスクリプトは、必要な部品をすべて内部で調達・組み立て、完成品のフォームを返す「全自動工場」の役割を果たします。

#### 3. `Test.ps1` - アプリケーションを起動するシンプルな監督役

このスクリプトは、アプリケーションの構成（設定）を行い、`GUI.ps1` で定義された関数を呼び出して、最終的なフォームを表示する役割だけを担います。

```powershell
# Test.ps1

# GUI工場をインポート
Import-Module (Join-Path -Path $PSScriptRoot -ChildPath "GUI.ps1") -Force

# アプリケーションの構成を定義
$LogFilePath = ".\App.log"

$appSettings = @{
    LogFilePath = $LogFilePath
}

# 工場に「この設定でアプリを作ってください」とお願いするだけ
$mainForm = New-AppForm -AppSettings $appSettings

# 完成品を表示
$mainForm.ShowDialog()

Write-Host "アプリケーションが終了しました。"
```
**ポイント:**
*   `Test.ps1`は、アプリの内部構造を知る必要がありません。ただ、必要な設定を渡して起動するだけの、非常にシンプルな役割に徹します。
*   `GUI.ps1`を `-Force` 付きで `Import-Module` することで、開発中に `GUI.ps1` を変更しても、常に最新の関数定義を読み込むことができます。

---

### まとめ

*   **問題:** 関数のローカル変数は関数終了時に消滅するため、`Add_Click`イベントからアクセスできない。
*   **解決方針:** 関数終了後も存在する**フォームオブジェクト**に、必要な状態をすべて保持させる。
*   **ベストプラクティス:**
    1.  アプリケーションの**状態（プロパティ）**と**ロジック（メソッド）**を一つの**クラス (`AppLogic`)**にカプセル化する。
    2.  GUI構築スクリプト内で、この`AppLogic`クラスのインスタンスを生成し、UIコントロールを登録する。**このとき、コントロールのサイズと位置を必ず指定する。**
    3.  完成した`AppLogic`インスタンスをフォームの**`Tag`プロパティ**に格納する。
    4.  各クリックイベントは、`param($sender, $e)`でクリックされたオブジェクトを正しく取得し、`$sender`経由で`Tag`から`AppLogic`インスタンスを取り出し、その**メソッドを呼び出す**だけ。

このクラスベースの設計パターンをマスターすれば、「変数が消える」という初歩的な問題から解放されるだけでなく、複雑な要求にも耐えうる、保守性と拡張性に優れたプロフェッショナルなGUIアプリケーションを構築できるようになります。