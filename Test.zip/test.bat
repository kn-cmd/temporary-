set SCRIPT=test_tool.py
set PWD=%~dp0

podman run --rm -v "%PWD%:/src" -w /src python:3-slim python %SCRIPT%


pause