﻿# ==========================================================
# 1. 基底クラス定義
# ==========================================================
class DataClassBase {
    # コンストラクタ: ハッシュテーブルをプロパティへ動的にマッピング
    DataClassBase([hashtable]$data) {
        $properties = $this.psobject.Properties | Where-Object { $_.MemberType -eq 'Property' }
        foreach ($prop in $properties) {
            $name = $prop.Name
            try {
                $this.$name = $data[$name]
            }
            catch {
                throw "Property validation error [$name]: $($_.Exception.Message)"
            }
        }
    }

    DataClassBase() {}
}

# ==========================================================
# 2. サブクラス定義
# ==========================================================
class UserInfo : DataClassBase {
    [ValidateNotNullOrEmpty()][string]$Id
    [ValidateNotNullOrEmpty()][string]$Name
    [string]$Email

    UserInfo([hashtable]$data) : base($data) {}
}

class ProductInfo : DataClassBase {
    [ValidateNotNullOrEmpty()][string]$Sku
    [ValidateRange(0, 1000)][int]$Price

    ProductInfo([hashtable]$data) : base($data) {}
}

# ==========================================================
# 3. 動作確認用テストユーティリティ
# ==========================================================
function Run-Test {
    param (
        [string]$TestName,
        [scriptblock]$TestBlock
    )
    Write-Host "--------------------------------------------------" -ForegroundColor Cyan
    Write-Host "Test: $TestName" -ForegroundColor Cyan
    try {
        &$TestBlock
        Write-Host "Result: SUCCESS" -ForegroundColor Green
    }
    catch {
        Write-Host "Result: FAILED (Expected if testing invalid data)" -ForegroundColor Yellow
        Write-Host "Error : $($_.Exception.Message)" -ForegroundColor Gray
    }
}

# ==========================================================
# 4. 実行テストケース
# ==========================================================

# --- 正常系 ---
Run-Test "UserInfo - 正常なデータ" {
    $data = @{ Id = "U001"; Name = "田中 太郎"; Email = "tanaka@example.com" }
    $user = [UserInfo]::new($data)
    Write-Host "User Created: $($user.Id) - $($user.Name)"
}

Run-Test "ProductInfo - 正常なデータ" {
    $data = @{ Sku = "PROD-100"; Price = 500 }
    $product = [ProductInfo]::new($data)
    Write-Host "Product Created: $($product.Sku) ($($product.Price) yen)"
}

# --- 異常系（バリデーション失敗） ---
Run-Test "UserInfo - 必須キー(Name)の欠損" {
    $data = @{ Id = "U002" } # Name が入っていない
    $user = [UserInfo]::new($data)
}

Run-Test "UserInfo - 値が空文字" {
    $data = @{ Id = "U003"; Name = "" } # Name が空文字
    $user = [UserInfo]::new($data)
}

Run-Test "ProductInfo - 数値の範囲外" {
    $data = @{ Sku = "PROD-200"; Price = 5000 } # Price上限(1000)を超過
    $product = [ProductInfo]::new($data)
}

Run-Test "UserInfo - 型の不一致（自動変換不能な場合）" {
    # 文字列プロパティに配列を渡すなど
    $data = @{ Id = @(1, 2, 3); Name = "InvalidIdType" } 
    $user = [UserInfo]::new($data)
}

Write-Host "--------------------------------------------------" -ForegroundColor Cyan
Write-Host "Test Completed."
