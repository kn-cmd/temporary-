﻿# モジュールのインポート
Import-Module .\ConcurrentCsvManager.psm1 -Force

$testFilePath = Join-Path $PSScriptRoot "test_data.csv"
$columns = "Id", "Name", "Status", "Version"

Write-Host "--- テスト開始 ---"

#region Test: New-CsvManagerSession - 初期化とヘッダー検証

Write-Host "`n=== New-CsvManagerSession テスト ==="

# 既存ファイルがあれば削除
if (Test-Path $testFilePath) {
    Remove-Item $testFilePath -Force
    Write-Host "既存ファイル $testFilePath を削除しました。"
}

# 新規セッションの作成 (ファイルが存在しない場合)
try {
    Write-Host "新規ファイルでセッションを作成します..."
    $session = New-CsvManagerSession -FilePath $testFilePath -Columns $columns
    Write-Host "セッション作成成功。ファイル: $($session.FilePath)"
    if (Test-Path $testFilePath) {
        Write-Host "ファイル $testFilePath が作成されました。"
    } else {
        Write-Host "エラー: ファイル $testFilePath が作成されていません。" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "エラー: 新規セッション作成中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 既存ファイルでセッションを作成 (ヘッダー検証)
try {
    Write-Host "既存ファイルでセッションを作成します (ヘッダー検証)..."
    $session2 = New-CsvManagerSession -FilePath $testFilePath -Columns $columns
    Write-Host "既存ファイルでのセッション作成成功。"
} catch {
    Write-Host "エラー: 既存ファイルでセッション作成中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# ヘッダー不一致テスト
try {
    Write-Host "ヘッダー不一致テスト (意図的に失敗させます)..."
    New-CsvManagerSession -FilePath $testFilePath -Columns "Id", "Name", "InvalidColumn" -ErrorAction Stop | Out-Null
    Write-Host "エラー: ヘッダー不一致が検出されませんでした。" -ForegroundColor Red
    exit 1
} catch {
    if ($_.Exception.GetType().Name -eq "SchemaValidationException") { # 型名を文字列でチェック
        Write-Host "成功: 期待通りSchemaValidationExceptionがスローされました: $($_.Exception.Message)" -ForegroundColor Green
    } else {
        Write-Host "エラー: 予期せぬ例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

#endregion

#region Test: Invoke-CsvUpsert - データ操作テスト

Write-Host "`n=== Invoke-CsvUpsert テスト ==="

# データを挿入
try {
    Write-Host "レコード1を挿入します..."
    Invoke-CsvUpsert -SessionObject $session -Data @{Id="1"; Name="Test1"; Status="Active"; Version="1"} -KeyColumns "Id"
    Write-Host "レコード1挿入成功。"
} catch {
    Write-Host "エラー: レコード1挿入中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# データを挿入
try {
    Write-Host "レコード2を挿入します..."
    Invoke-CsvUpsert -SessionObject $session -Data @{Id="2"; Name="Test2"; Status="Pending"; Version="1"} -KeyColumns "Id"
    Write-Host "レコード2挿入成功。"
} catch {
    Write-Host "エラー: レコード2挿入中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 既存データを更新
try {
    Write-Host "レコード1を更新します (Status: Active -> Completed)..."
    Invoke-CsvUpsert -SessionObject $session -Data @{Id="1"; Status="Completed"; Version="2"} -KeyColumns "Id"
    Write-Host "レコード1更新成功。"
} catch {
    Write-Host "エラー: レコード1更新中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 部分更新 (Nameは維持されるはず)
try {
    Write-Host "レコード2を部分更新します (Status: Pending -> Active)..."
    Invoke-CsvUpsert -SessionObject $session -Data @{Id="2"; Status="Active"} -KeyColumns "Id"
    Write-Host "レコード2部分更新成功。"
} catch {
    Write-Host "エラー: レコード2部分更新中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

#endregion

#region Test: Get-CsvData - データ読み込みテスト

Write-Host "`n=== Get-CsvData テスト ==="

# 全件読み込み
try {
    Write-Host "全レコードを読み込みます..."
    $allRecords = @(Get-CsvData -SessionObject $session)
    if ($allRecords.Count -eq 2) {
        Write-Host "成功: 全2レコードを読み込みました。" -ForegroundColor Green
        $allRecords | Format-Table -AutoSize
    } else {
        Write-Host "エラー: 予期せぬレコード数: $($allRecords.Count)" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "エラー: 全件読み込み中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# フィルタ条件での読み込み
try {
    Write-Host "Statusが'Completed'のレコードを読み込みます..."
    $completedRecords = @(Get-CsvData -SessionObject $session -Filter @{Status="Completed"})
    if ($completedRecords.Count -eq 1 -and $completedRecords[0].Id -eq "1") {
        Write-Host "成功: Status='Completed'のレコードを1件読み込みました。" -ForegroundColor Green
        $completedRecords | Format-Table -AutoSize
    } else {
        Write-Host "エラー: フィルタ結果が期待と異なります。" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "エラー: フィルタ読み込み中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# -Unique スイッチでの単一レコード読み込み
try {
    Write-Host "-Unique スイッチでレコード Id='2' を読み込みます..."
    $uniqueRecord = Get-CsvData -SessionObject $session -Filter @{Id="2"} -Unique
    if ($uniqueRecord -and $uniqueRecord.Name -eq "Test2") {
        Write-Host "成功: -Unique でレコード Id='2' を読み込みました。" -ForegroundColor Green
        $uniqueRecord | Format-List
    } else {
        Write-Host "エラー: -Unique 読み込み結果が期待と異なります。" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "エラー: -Unique 読み込み中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# -Unique スイッチでレコードが見つからない場合 ($nullを返す)
try {
    Write-Host "-Unique スイッチで存在しないレコードを読み込みます..."
    $notFoundRecord = Get-CsvData -SessionObject $session -Filter @{Id="999"} -Unique
    if (-not $notFoundRecord) {
        Write-Host "成功: -Unique でレコードが見つからず、`$null`が返されました。" -ForegroundColor Green
    } else {
        Write-Host "エラー: -Unique 読み込み結果が期待と異なります ($notFoundRecord が返されました)。" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "エラー: -Unique 読み込み中に例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# -Unique スイッチと重複レコードでのエラーテスト (意図的に失敗させます)
# 一時的に重複レコードを作成
Invoke-CsvUpsert -SessionObject $session -Data @{Id="3"; Name="Test3"; Status="Active"; Version="1"} -KeyColumns "Id" -ErrorAction Stop | Out-Null # StatusがActiveのレコードが複数になるように挿入
Invoke-CsvUpsert -SessionObject $session -Data @{Id="4"; Name="Test4"; Status="Active"; Version="1"} -KeyColumns "Id" -ErrorAction Stop | Out-Null # StatusがActiveのレコードが複数になるように挿入

try {
    Write-Host "-Unique スイッチで重複するレコードを読み込みます (意図的に失敗させます)..."
    $temp = Get-CsvData -SessionObject $session -Filter @{Status="Active"} -Unique -ErrorAction Stop
    Write-Host $temp
    Write-Host "エラー: DuplicateKeyExceptionが検出されませんでした。" -ForegroundColor Red
    exit 1
} catch {
    if ($_.Exception.GetType().Name -eq "DuplicateKeyException") { # 型名を文字列でチェック
        Write-Host "成功: 期待通りDuplicateKeyExceptionがスローされました: $($_.Exception.Message)" -ForegroundColor Green
    } else {
        Write-Host "エラー: 予期せぬ例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

#endregion

#region Test: Invoke-CsvUpsert - 楽観的ロックテスト

Write-Host "`n=== Invoke-CsvUpsert 楽観的ロックテスト ==="

# レコードを再初期化 (既存のCSVファイルを削除し、再度New-CsvManagerSessionで作成)
if (Test-Path $testFilePath) { Remove-Item $testFilePath -Force }
$session = New-CsvManagerSession -FilePath $testFilePath -Columns $columns
Invoke-CsvUpsert -SessionObject $session -Data @{Id="1"; Name="OptTest1"; Status="Active"; Version="1"} -KeyColumns "Id" -ErrorAction Stop | Out-Null
Write-Host "楽観的ロックテスト用にレコードを初期化しました (Id=1, Name=OptTest1, Status=Active, Version=1)。"

# 楽観的ロック成功ケース
try {
    Write-Host "楽観的ロック成功ケース (Version=1 -> 2)..."
    Invoke-CsvUpsert -SessionObject $session -Data @{Id="1"; Status="Completed"; Version="2"} -KeyColumns "Id" -Assume @{Version="1"}
    Write-Host "成功: 楽観的ロックでレコードを更新しました。" -ForegroundColor Green
    $updatedRecord = Get-CsvData -SessionObject $session -Filter @{Id="1"} -Unique
    if ($updatedRecord.Status -eq "Completed" -and $updatedRecord.Version -eq "2") {
        Write-Host "更新内容も確認しました。" -ForegroundColor Green
    } else {
        Write-Host "エラー: 更新内容が期待と異なります。" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "エラー: 楽観的ロック成功ケースで予期せぬ例外: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

# 楽観的ロック失敗ケース (意図的に失敗させます)
try {
    Write-Host "楽観的ロック失敗ケース (前提Version=1だが実際は2)..."
    Invoke-CsvUpsert -SessionObject $session -Data @{Id="1"; Status="Failed"; Version="3"} -KeyColumns "Id" -Assume @{Version="1"} -ErrorAction Stop | Out-Null
    Write-Host "エラー: OptimisticLockingExceptionが検出されませんでした。" -ForegroundColor Red
    exit 1
} catch {
    if ($_.Exception.GetType().Name -eq "OptimisticLockingException") { # 型名を文字列でチェック
        Write-Host "成功: 期待通りOptimisticLockingExceptionがスローされました: $($_.Exception.Message)" -ForegroundColor Green
    } else {
        Write-Host "エラー: 予期せぬ例外が発生しました: $($_.Exception.Message)" -ForegroundColor Red
        exit 1
    }
}

#endregion

Write-Host "`n--- テスト終了 ---"

# テストファイルをクリーンアップ
# if (Test-Path $testFilePath) {
#    Remove-Item $testFilePath -Force
#    Write-Host "テストファイル $testFilePath をクリーンアップしました。"
# }