`ADODB.Stream` を使用する方法は、**Windows環境であれば最も一般的かつ「スマート」な実装方法**です。

手動計算（ビット演算）を自前で行う必要がなく、文字コードの変換（UTF-16 → UTF-8）をOS標準のライブラリに任せられるため、コードが短くなり、絵文字などの処理も確実です。

以下に、**32bit/64bit両対応・参照設定不要**な `ADODB.Stream` 版のコードを紹介します。

### ADODB.Stream を使用した URLエンコード

このコードは「レイトバインディング（実行時バインディング）」という手法を使っているため、ライブラリの設定作業なしで、そのままコピー＆ペーストで動作します。

```vba
Public Function UrlEncodeADO(ByVal strInput As String) As String
    If strInput = "" Then Exit Function

    Dim adodbStream As Object
    Dim bytes() As Byte
    Dim i As Long
    Dim b As Integer
    Dim result As String

    ' 1. ADODB.Streamオブジェクトを作成
    Set adodbStream = CreateObject("ADODB.Stream")
    
    ' 2. UTF-8で文字列をバイナリに変換
    adodbStream.Type = 2 ' adTypeText
    adodbStream.Charset = "UTF-8"
    adodbStream.Open
    adodbStream.WriteText strInput
    
    ' バイナリモードに切り替えて読み出し
    adodbStream.Position = 0
    adodbStream.Type = 1 ' adTypeBinary
    bytes = adodbStream.Read
    adodbStream.Close
    
    ' 3. バイト列を1つずつループしてパーセント符号化
    result = ""
    ' UTF-8のBOM（先頭3バイト: EF BB BF）を避けるため、LBound + 3 から開始
    ' ※ADODBはデフォルトでBOMを付与するため
    For i = LBound(bytes) + 3 To UBound(bytes)
        b = bytes(i)
        
        ' RFC3986 未予約文字の判定 (0-9, A-Z, a-z, "-", ".", "_", "~")
        Select Case b
            Case 48 To 57, 65 To 90, 97 To 122, 45, 46, 95, 126
                result = result & Chr(b)
            Case 32
                result = result & "%20" ' スペース
            Case Else
                ' 16進数に変換。1桁の場合は0を補完
                result = result & "%" & Right("0" & Hex(b), 2)
        End Select
    Next i

    UrlEncodeADO = result
    Set adodbStream = Nothing
End Function
```

---

### この方法のメリット・デメリット

#### メリット
1.  **確実な文字コード変換**: `ADODB.Stream` は Windows OS 標準の変換エンジンを使うため、複雑な漢字や最新の絵文字も正確に UTF-8 バイト列へ変換できます。
2.  **32bit / 64bit を問わない**: `CreateObject` で呼び出す COM オブジェクトは、Excel のビット数に合わせて OS が適切に処理するため、互換性の問題が起きません。
3.  **コードが読みやすい**: 自前でビット演算をする必要がないため、メンテナンス性が向上します。

#### デメリット・注意点
1.  **Windows 専用**: `ADODB.Stream` は Windows のコンポーネントであるため、**Mac 版 Excel では動作しません。**
2.  **BOM（バイト順マーク）の処理**: ADODB は UTF-8 で出力する際、先頭に 3 バイトの識別信号（BOM）を付与します。URL エンコードに BOM は不要なため、コード内で `+ 3` をして読み飛ばす処理が必要です。
3.  **速度**: 大量の文字列（数万行のセルなど）を一括で処理する場合、手動計算方式よりもオブジェクト生成のオーバーヘッド分、わずかに遅くなることがあります。

---

### 結局、どれを使うべきか？

今の状況に合わせて選んでください。

*   **「Windows 環境しか想定せず、楽に実装したい」**
    → **この `ADODB.Stream` 方式** がベストです。
*   **「Mac でも使う可能性がある、またはセキュリティが極めて厳しい環境である」**
    → 前回紹介した **「手動計算（Pure VBA）方式」** が最も安全です。
*   **「Excel 2013 以降しか使わないことが確定している」**
    → 組み込みの `WorksheetFunction.EncodeURL` が最速です。

`ADODB.Stream` を使った方法は Windows 上の VBA 開発では「定番中の定番」ですので、非常に信頼性の高い選択肢です。
