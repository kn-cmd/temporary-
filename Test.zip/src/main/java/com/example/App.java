package com.example;
import java.sql.*;

public class App {
    public static void main(String[] args) {
        String url = System.getenv("DB_URL");
        String user = System.getenv("DB_USER");
        String pass = System.getenv("DB_PASSWORD");

        try (Connection conn = DriverManager.getConnection(url, user, pass)) {
            System.out.println("成功: pgweb でデータを確認してみましょう！");
            // ここでテーブル作成やデータ挿入のコードを書く
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
