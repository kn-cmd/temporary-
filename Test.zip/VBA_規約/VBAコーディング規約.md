# VBA Coding Standards

本プロジェクトにおける VBA (Visual Basic for Applications) のコーディング規約です。
可読性、メンテナンス性、および現代的なプログラミングスタイルへの適応を重視します。

## 1. 変数・定数

### 1.1. 宣言の位置
*   **原則**: 変数は **利用する直前** に宣言します。プロシージャの先頭でまとめて宣言する古いスタイルは推奨しません。
*   **理由**: 変数のスコープ（有効範囲）と生存期間を視覚的に最小化し、コードの流れを追いやすくするため。

**Good:**
```vba
' 処理 A
Dim count As Long
count = GetCount()
For i = 1 To count
    ...
Next i

' 処理 B (ここでしか使わない変数はここで宣言)
Dim result As String
result = BuildResult()
```

**Bad:**
```vba
Dim count As Long
Dim result As String
Dim i As Long

' ... 長い処理 ...
count = GetCount()
```

### 1.2. 命名規則
*   **変数名**: キャメルケース (例: `taskName`, `startDate`)
*   **定数名**: アッパースネークケース (例: `STATUS_ACTIVE`, `MAX_RETRY`)
*   **プライベート変数**: `p` 接頭辞 + キャメルケース (例: `pProjects`, `pTasks`)

### 1.3. 文字列の扱い
*   **空文字の判定**: 原則として `""` (長さ0の文字列) を使用します。
    *   **理由**: `vbNullString` よりも直感的で可読性が高いため。
*   **例外**: 処理効率が極めて重要な場合（数万回以上のループ内や、大量の文字列操作を行う場合など）に限り、`vbNullString` の使用を許容・推奨します。
    *   `vbNullString` はメモリ割り当てを行わないヌルポインタであり、`""` よりもわずかに高速でメモリ効率が良いですが、通常のビジネスロジックでは無視できる程度の差です。

## 2. プロシージャ (Sub / Function)

### 2.1. 引数の渡し方 (`ByRef` / `ByVal`)
VBA のデフォルトは `ByRef` です。本プロジェクトでは以下のルールで明示/省略を使い分け、**意図（副作用の有無）を明確** にします。

*   **省略 (デフォルト)**:
    *   値を書き換えない引数（入力用引数）は、修飾子 (`ByVal` / `ByRef`) を **省略** します。
    *   これは **配列引数であっても同様** です。単に配列であるという理由だけで `ByRef` を記述することはありません。
*   **明示 (`ByRef` / `ByVal`)**:
    *   メソッド内部で **引数の値を書き換える場合のみ** 記述します。
    *   **`ByRef`**: 値を書き換え、その結果を呼び出し元に返す（出力パラメータ）場合。
    *   **`ByVal`**: 値を内部で書き換えるが、呼び出し元には影響を与えたくない（ローカルな変更）場合。

**Example:**
```vba
' inputArr は入力用（変更しない） -> 配列だが省略
' outResult は出力用（変更して返す） -> ByRef 明示
Sub ProcessData(inputArr() As String, ByRef outResult As Long)
    outResult = UBound(inputArr)
End Sub

' arr は内部でソート（変更）して返す -> ByRef 明示
Sub SortData(ByRef arr() As Object)
    ' ソート処理
End Sub
```

### 2.2. 戻り値
*   関数が複数の値を返す必要がある場合は、`Function` の戻り値として `Boolean` (成功/失敗) を返し、結果自体は `ByRef` 引数で返すパターンを検討します（Try-Parse パターン）。

## 3. データ構造

### 3.1. Dictionary
*   連想配列が必要な場合は `Scripting.Dictionary` を使用します。
*   汎用的な `Object` 型として宣言し、`CreateObject("Scripting.Dictionary")` で生成する（遅延バインディング）か、参照設定を行って `New Dictionary` するかはプロジェクトの設定に従いますが、コード上はどちらでも通るように配慮します。

### 3.2. Collection
*   単純なリスト構造には `Collection` を使用します。
*   ソートや複雑な操作が必要な場合は、一時的に配列へ変換して処理することを許容します。

### 3.3. ユーザー定義型 (Type) の制限
*   **原則**: クラスモジュール内では **`Type` (ユーザー定義型) を使用しません**。
*   **理由**: VBAの仕様上、クラスモジュールにおける `Type` には強い制約があるためです。
    *   `Public Type` は定義自体が禁止されており、コンパイルエラーとなります。
    *   `Private Type` は定義可能ですが、その型を **`Public` なプロシージャ（Sub/Function/Property）の引数や戻り値に使用することはできません**。
*   **結論**: クラス間で構造化されたデータをやり取りする本プロジェクトの設計において、クラス内 `Type` はインターフェースとして利用できないため、一貫して `Scripting.Dictionary` を使用します。

## 4. コメント・ドキュメンテーション

### 4.1. メソッドコメント
*   各 `Public` メソッドの直前に、XMLドキュメントコメント風の要約 (`''' <summary>`) を記述することを推奨します。

```vba
''' <summary>
''' プロジェクトごとのスケジュールを生成して返します。
''' </summary>
Public Function GetScheduleByProject() As String
```

### 4.2. インラインコメント
*   処理の「What（何をしているか）」ではなく「Why（なぜそうしているか）」を記述します。
*   自明なコード（例: `i = i + 1 ' カウントアップ`）にはコメントを付けません。

## 5. 制御構造

### 5.1. 条件分岐 (If文)
*   **原則**: `If ... Then ... Else ...` を1行で記述することは避け、複数行のブロック構文 (`If ... End If`) を使用します。
*   **理由**:
    *   デバッガでブレークポイントを設定しやすくするため（True/False どちらのルートを通ったか確認しやすい）。
    *   条件分岐の構造を視覚的に明確にし、可読性を向上させるため。

**Good:**
```vba
If IsDate(val) Then
    result = CDate(val)
Else
    result = LATE_DATE
End If
```

**Bad:**
```vba
If IsDate(val) Then result = CDate(val) Else result = LATE_DATE
```
