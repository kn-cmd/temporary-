﻿# =============================================================================
# PowerShell GUI - 社員選択デモ (リファクタリング版)
# =============================================================================

# -----------------------------------------------------------------------------
# スクリプト全体の実行設定
# -----------------------------------------------------------------------------
# .NETコンソール自体の出力エンコーディングをUTF-8に設定
[System.Console]::OutputEncoding = [System.Text.Encoding]::UTF8

# PowerShellの出力エンコーディングをUTF-8に設定
$OutputEncoding = [System.Text.Encoding]::UTF8

# Windows Forms アセンブリをロード
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Data


# =============================================================================
# メイン処理
# =============================================================================

# ui.psm1モジュールをインポート
Import-Module ".\ui.psm1" -Force

# 表示する列を定義
$displayColumns = "項目名", "状態", "入力者", "承認者"

# 表示するデータ (PSCustomObjectの配列) を作成
$employeeData = @(
    [PSCustomObject]@{ "項目名" = "経費申請-001"; "状態" = "承認済"; "入力者" = "山田 太郎"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "休暇申請-002"; "状態" = "申請中"; "入力者" = "鈴木 一郎"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "備品購入依頼-003"; "状態" = "差戻"; "入力者" = "田中 美咲"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "経費申請-004"; "状態" = "承認済"; "入力者" = "山田 太郎"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "出張申請-005"; "状態" = "申請中"; "入力者" = "加藤 健太"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "経費申請-006"; "状態" = "承認済"; "入力者" = "山田 太郎"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "物品破棄申請-007"; "状態" = "完了"; "入力者" = "伊藤 さやか"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "PC交換申請-008"; "状態" = "申請中"; "入力者" = "中村 俊介"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "交通費申請-009"; "状態" = "差戻"; "入力者" = "田中 美咲"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "書籍購入依頼-010"; "状態" = "承認済"; "入力者" = "渡辺 謙"; "承認者" = "佐藤 部長" },
    [PSCustomObject]@{ "項目名" = "会議室予約-011"; "状態" = "完了"; "入力者" = "鈴木 一郎"; "承認者" = "佐藤 部長" }
)

$mainForm = $null
try {
    # 1. GUIコントロールの作成 (ui.psm1 の関数を使用)
    
    # メインフォーム
    $mainForm = New-UiForm -Title "社員を選択" -AutoSize

    # DataGridView
    $dataGridView = New-UIDataGridView -FromData $employeeData -Columns $displayColumns -Size ([System.Drawing.Size]::new(600, 300)) -ReadOnly

    # ボタン (削除・ダウンロード)
    $deleteButton = New-UiButton -Text "削除"
    $downloadButton = New-UiButton -Text "ダウンロード"

    # ファイル選択UI
    $fileLabel = New-UiLabel -Text "ファイル選択" -AutoSize
    $textBox = New-UiTextBox -ReadOnly -TabStop:$false
    $selectFileButton = New-UiButton -Text "ファイル選択"
    $uploadButton = New-UiButton -Text "アップロード"

    # 2. イベントハンドラの設定
    $deleteButton.Add_Click({
        Write-Host "削除ボタンがクリックされました。"
    })

    $downloadButton.Add_Click({
        Write-Host "ダウンロードボタンがクリックされました。"
    })

    $selectFileButton.add_Click({
        $openFileDialog = [System.Windows.Forms.OpenFileDialog]::new()
        $openFileDialog.Title = "ファイルを選択してください"
        if ($openFileDialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $textBox.Text = $openFileDialog.FileName
        }
        $openFileDialog.Dispose()
    })

    $uploadButton.add_Click({
        $filePath = $textBox.Text
        if (-not [string]::IsNullOrEmpty($filePath)) {
            [System.Console]::WriteLine("'{0}' をアップロードします。" -f $filePath)
        } else {
            [System.Console]::WriteLine("ファイルが選択されていません。")
        }
    })

    # 3. レイアウトの構築
    
    # ボタンパネル (削除・ダウンロード)
    $buttonPanel = New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
        $deleteButton
        $downloadButton
    }

    # ファイル選択テキストボックスの幅を調整
    $textBox.Width = $dataGridView.Width - $textBox.Margin.Horizontal

    # 入力行パネル
    $inputRowPanel = New-UiFlowLayoutPanel -FlowDirection TopDown -AutoSize -Controls {
        (New-UiSpacer)
        $fileLabel
        $textBox
    }

    # ボタンパネル (ファイル選択・アップロード)
    $newButtonsPanel = New-UiFlowLayoutPanel -FlowDirection LeftToRight -AutoSize -Controls {
        $selectFileButton
        $uploadButton
    }

    # ルートパネル
    $rootPanel = New-UiFlowLayoutPanel -FlowDirection TopDown -AutoSize -Controls {
        $dataGridView
        $buttonPanel
        $inputRowPanel
        $newButtonsPanel
    }
    
    $mainForm.Controls.Add($rootPanel)

    # フォームを表示
    $mainForm.ShowDialog() | Out-Null
}
# catch {
#     Write-Error $_.Exception.Message
# }
finally {
    if ($mainForm) {
        # フォームを破棄
        $mainForm.Dispose()
    }
}
