# `New-UIDataGridView` 関数 設計資料

## 1. 背景と目的

プロジェクト内の複数のPowerShell GUIサンプルにおいて、`System.Windows.Forms.DataGridView` コントロールが異なる方法で作成・設定されている。これにより、コードの重複や一貫性の欠如が生じている。

本ドキュメントで定義する汎用関数 `New-UIDataGridView` は、`ui.psm1` モジュールに実装することを目的とする。この関数は、`DataGridView` の生成プロセスを標準化し、コードの再利用性を高め、将来のメンテナンスを容易にすることを目的とする。

## 2. 設計思想

本関数は、以下の設計思想に基づいて設計されている。

### a. YAGNI (You Ain't Gonna Need It) の原則
初期の多機能な提案から、本当に必要な機能に絞り込んだ。`Dock` や `Location` プロパティのような、呼び出し側で容易に設定できるパラメータは意図的に排除し、関数をシンプルに保つ。

### b. 分岐の単純化
`DataGridView` の主な用途が「表示専用」と「編集可能」の2つであるという分析に基づき、`-ReadOnly` スイッチを主要な分岐点として採用した。これにより、関数の利用者は一つのスイッチで、目的に応じた適切なデフォルト設定（選択モード、行の追加可否など）の恩恵を受けられる。

### c. 独立したユーザー操作オプション
グリッドの読み取り専用/編集可能状態とは独立して、リサイズやソートの可否を制御するオプション (`-Resizable`, `-Sortable`) を提供する。これにより、例えば「読み取り専用だがソートは可能」といった柔軟な設定が可能となる。

### d. 安定性と堅牢性、排他的なデータ指定
PowerShellの**パラメータセット**機能を利用し、データソースを指定する `-FromData` と、空の行数を指定する `-FromCount` を排他的に利用させる。これにより、利用者はどちらか一方を明確に選択する必要があり、誤ったパラメータの組み合わせによる混乱を防ぐ。

`-FromData` パラメータには型制約 `[System.Collections.IEnumerable]` を設け、コレクション以外のデータが渡された場合はPowerShellがエラーを発生させる。さらに、渡されたコレクションは内部で `System.ComponentModel.BindingList` に変換されるため、`PSCustomObject` の配列などを渡しても安定したデータバインディングが保証される。既に `BindingList` 型が渡された場合は、そのまま利用され、再変換は行われない。

## 3. 関数の仕様

### a. 構文

```powershell
function New-UIDataGridView {
    [CmdletBinding(DefaultParameterSetName = 'FromData')]
    param(
        # --- 動作モード ---
        [switch]$ReadOnly,

        # --- データと列の指定 (排他的) ---
        [Parameter(ParameterSetName = 'FromData')]
        [System.Collections.IEnumerable]$FromData,

        [Parameter(ParameterSetName = 'FromCount')]
        [int]$FromCount = 0,

        # --- データと列の定義 ---
        [string[]]$Columns,

        # --- 基本的なレイアウト ---
        [System.Drawing.Size]$Size,

        # --- ユーザー操作の制御 (独立したオプション) ---
        [switch]$Resizable,
        [switch]$Sortable
    )
}
```

### b. パラメータ詳細

| パラメータ | 型 | 説明 |
| :--- | :--- | :--- |
| `-ReadOnly` | `[switch]` | このスイッチを指定すると、グリッドが「表示専用モード」になる。指定しない場合は「編集可能モード」となる。 |
| `-FromData` | `[System.Collections.IEnumerable]` | **(FromData パラメータセット)** グリッドに表示する項目のコレクション (`PSCustomObject[]`など)。内部で `BindingList` に変換され、安定したデータバインディングを提供する。コレクション以外の型を渡すとエラーになる。`-FromCount` とは排他的。 |
| `-FromCount` | `[int]` | **(FromCount パラメータセット)** データソースがない場合に、初期状態で作成する空の行数を指定する。`-FromData` とは排他的。 |
| `-Columns` | `[string[]]` | 表示する列のヘッダー名を文字列配列で指定する。 |
| `-Size` | `[System.Drawing.Size]` | グリッドのサイズを指定する（任意）。指定しない場合、`DataGridView` のデフォルトサイズが使用される。 |
| `-Resizable` | `[switch]` | 指定すると、ユーザーによる行の高さと列の幅の変更が許可される。 |
| `-Sortable` | `[switch]` | 指定すると、ユーザーによる列のソートが許可される。 |

## 4. 動作モード

### a. 表示専用モード (`-ReadOnly` 指定時)

ユーザーによるデータ編集を意図しない表示専用のグリッドを作成する。リサイズやソートの可否は、このモードに影響されず、`-Resizable` / `-Sortable` スイッチによってのみ決定される。

- **プロパティ設定:**
  - `ReadOnly` = `$true`
  - `AllowUserToAddRows` = `$false`
  - `AllowUserToDeleteRows` = `$false`
  - `SelectionMode` = `FullRowSelect`

### b. 編集可能モード (デフォルト)

ユーザーによるデータ入力を意図する編集可能なグリッドを作成する。リサイズやソートの可否は、このモードに影響されず、`-Resizable` / `-Sortable` スイッチによってのみ決定される。

- **プロパティ設定:**
  - `ReadOnly` = `$false`
  - `AllowUserToAddRows` = `$true`
  - `AllowUserToDeleteRows` = `$true`
  - `SelectionMode` = `CellSelect`

## 5. 使用例

### 例1: データソースから表示する、表示専用だがリサイズとソートが可能なグリッド

```powershell
$param = @{
    FromData  = $myData
    Columns   = "ID", "名前"
    ReadOnly  = $true
    Resizable = $true
    Sortable  = $true
}
$dataGridView = New-UIDataGridView @param
```

### 例2: 10行の空の入力欄を持つ、編集可能だがリサイズとソートが不可能なグリッド

```powershell
$param = @{
    FromCount = 10
    Columns   = "ID", "値"
    Resizable = $false
    Sortable  = $false
}
$dataGridView = New-UIDataGridView @param
```

### 例3: データソースと空の行数を同時に指定しようとした場合 (エラーになる例)

```powershell
# このコマンドは、パラメータセットの競合によりエラーになります。
# New-UIDataGridView : Parameter set cannot be resolved using the specified named parameters.
$param = @{
    FromData  = $myData
    FromCount = 5
    Columns   = "ID", "名前"
}
$dataGridView = New-UIDataGridView @param
```