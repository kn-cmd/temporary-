﻿# =============================================================================
# UI Module (ui.psm1)
# 汎用的なWindows Forms UI要素を生成する関数群
# =============================================================================

# .NETアセンブリのロード
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

#region 定数 (モジュールスコープ)
# 共通デフォルト値
$DEFAULT_PADDING = [System.Windows.Forms.Padding]::new(10, 10, 10, 10)
$DEFAULT_MARGIN = [System.Windows.Forms.Padding]::new(3, 3, 3, 3)
$DEFAULT_FONT = [System.Drawing.Font]::new("Yu Gothic UI", 12)
$DATAGRIDVIEW_DEFAULT_SIZE = [System.Drawing.Size]::new(600, 300)
# コンポーネントデフォルト値
$BUTTON_MIN_SIZE = [System.Drawing.Size]::new(80, 25)
$TEXTBOX_DEFAULT_HEIGHT = 25
$SPACER_HEIGHT_SMALL = 3
$SPACER_WIDTH_SMALL = 3
$GROUPBOX_TITLE_PADDING = 20

#endregion

#region 汎用UI生成関数

function New-UiForm {
<#
.SYNOPSIS
    標準的なWindows Formsフォームを生成します。
#>
    [CmdletBinding()]
    param (
        [string]$Title = "PowerShell GUI Application",
        [switch]$AutoSize,
        [System.Windows.Forms.AutoSizeMode]$AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowOnly,
        [System.Windows.Forms.FormStartPosition]$StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
    )
    $properties = @{
        Text = $Title
        StartPosition = $StartPosition
    }
    if ($AutoSize) {
        $properties.AutoSize = $true
        $properties.AutoSizeMode = $AutoSizeMode
    }

    return New-Object System.Windows.Forms.Form -Property $properties
}

function New-UiPanel {
<#
.SYNOPSIS
    標準的なPanelを生成します。
#>
    [CmdletBinding()]
    param (
        [System.Windows.Forms.Padding]$Padding = $DEFAULT_PADDING,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN,
        [System.Drawing.Size]$Size
    )
    $properties = @{
        Padding = $Padding
        Margin = $Margin
    }
    if ($Size) {
        $properties.Size = $Size
    }
    return New-Object System.Windows.Forms.Panel -Property $properties
}

function New-UiFlowLayoutPanel {
<#
.SYNOPSIS
    標準的なFlowLayoutPanelを生成します。
#>
    [CmdletBinding()]
    param (
        [System.Windows.Forms.FlowDirection]$FlowDirection = [System.Windows.Forms.FlowDirection]::TopDown,
        [switch]$AutoSize,
        [System.Windows.Forms.AutoSizeMode]$AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowOnly,
        [System.Windows.Forms.Padding]$Padding = $DEFAULT_PADDING,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN,
        [System.Drawing.Size]$Size,
        [ScriptBlock]$Controls
    )
    $properties = @{
        FlowDirection = $FlowDirection
        Padding = $Padding
        Margin = $Margin
    }
    if ($AutoSize) {
        $properties.AutoSize = $true
        $properties.AutoSizeMode = $AutoSizeMode
    }
    if ($Size) {
        $properties.Size = $Size
    }

    $panel = New-Object System.Windows.Forms.FlowLayoutPanel -Property $properties

    if ($Controls) {
        # スクリプトブロック内の処理を実行し、返されたコントロールをパネルに追加
        & $Controls | ForEach-Object {
            if ($_ -is [System.Windows.Forms.Control]) {
                $panel.Controls.Add($_)
            }
        }
    }

    return $panel
}

function New-UiGroupBox {
<#
.SYNOPSIS
    標準的なGroupBoxを生成します。
    -AutoSize オプションを指定した場合、通常のAutoSize の設定に加えて MinimumSize がタイトル文字列に合わせて設定されます。
#>
    [CmdletBinding()]
    param (
        [string]$Text = "GroupBox",
        [System.Drawing.Font]$Font = $DEFAULT_FONT,
        [switch]$AutoSize,
        [System.Windows.Forms.AutoSizeMode]$AutoSizeMode = [System.Windows.Forms.AutoSizeMode]::GrowOnly,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN + $DEFAULT_PADDING,
        [ScriptBlock]$Controls
    )
    $properties = @{
        Text = $Text
        Font = $Font
        Margin = $Margin
    }

    if ($AutoSize) {
        $properties.AutoSize = $true
        $properties.AutoSizeMode = $AutoSizeMode
        $TitleSize = [System.Windows.Forms.TextRenderer]::MeasureText($Text, $Font)
        $properties.MinimumSize = [System.Drawing.Size]::new($TitleSize.Width + $GROUPBOX_TITLE_PADDING, 0)
    }

    $groupBox = New-Object System.Windows.Forms.GroupBox -Property $properties

    if ($Controls) {
        & $Controls | ForEach-Object {
            if ($_ -is [System.Windows.Forms.Control]) {
                $groupBox.Controls.Add($_)
            }
        }
    }

    return $groupBox
}


function New-UiSpacer {
<#
.SYNOPSIS
    指定した幅と高さを持つUIレイアウト用のスペーサーを生成します。
.DESCRIPTION
    Panelコントロールを使い、レイアウト内に指定したサイズの間隔を作成します。
    パラメータを省略した場合は、デフォルトのサイズが使用されます。
#>
    [CmdletBinding()]
    param (
        [int]$Height = $SPACER_HEIGHT_SMALL,
        [int]$Width = $SPACER_WIDTH_SMALL
    )
    $properties = @{
        Margin = [System.Windows.Forms.Padding]::Empty
        Size = [System.Drawing.Size]::new($Width, $Height)
    }
    return New-Object System.Windows.Forms.Panel -Property $properties
}



function New-UiButton {
<#
.SYNOPSIS
    標準的なボタンを生成します。
#>
    [CmdletBinding()]
    param (
        [string]$Text = "Button",
        [System.Drawing.Font]$Font = $DEFAULT_FONT,
        [System.Drawing.Size]$Size,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $properties = @{
        Text = $Text
        Font = $Font
        Margin = $Margin
        AutoSize = $true
        MinimumSize = $BUTTON_MIN_SIZE
    }
    if ($Size) {
        $properties.Size = $Size
    }
    
    return New-Object System.Windows.Forms.Button -Property $properties
}

function New-UiLabel {
<#
.SYNOPSIS
    標準的なラベルを生成します。
#>
    [CmdletBinding()]
    param (
        [string]$Text = "Label",
        [System.Drawing.Font]$Font = $DEFAULT_FONT,
        [switch]$AutoSize,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $properties = @{
        Text = $Text
        Font = $Font
        Margin = $Margin
    }
    if ($AutoSize) {
        $properties.AutoSize = $true
    }
    return New-Object System.Windows.Forms.Label -Property $properties
}

function New-UiTextBox {
<#
.SYNOPSIS
    標準的なテキストボックスを生成します。
#>
    [CmdletBinding()]
    param (
        [string]$Text = "",
        [System.Drawing.Font]$Font = $DEFAULT_FONT,
        [switch]$ReadOnly,
        [switch]$Multiline,
        [bool]$TabStop = $false,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $properties = @{
        Text = $Text
        Font = $Font
        Margin = $Margin
        TabStop = $TabStop
    }
    if ($ReadOnly) {
        $properties.ReadOnly = $true
    }
    if ($Multiline) {
        $properties.Multiline = $true
        $properties.ScrollBars = 'Vertical'
        $properties.WordWrap = $true
        $properties.AcceptsReturn = $true
    }
    return New-Object System.Windows.Forms.TextBox -Property $properties
}
    

function New-UiRadioButton {
<#
.SYNOPSIS
    標準的なラジオボタンを生成します。
#>
    [CmdletBinding()]
    param (
        [string]$Text = "RadioButton",
        [System.Drawing.Font]$Font = $DEFAULT_FONT,
        [string]$Name = $Text,
        [System.Windows.Forms.Padding]$Margin = $DEFAULT_MARGIN
    )
    $properties = @{
        Text = $Text
        Name = $Name
        Font = $Font
        AutoSize = $true
        Margin = $Margin
    }
    return New-Object System.Windows.Forms.RadioButton -Property $properties
}


function New-UIDataGridView {
<#
.SYNOPSIS
    汎用的な DataGridView コントロールを生成し、データバインディングまたは空行で初期化します。
.DESCRIPTION
    この関数は、PowerShellのパラメータセット機能を利用し、データコレクションからのバインディング (-FromData)
    または指定された数の空行 (-FromCount) のいずれかで DataGridView を初期化します。
    
    グリッドは、読み取り専用モード、リサイズ可否、ソート可否を独立したスイッチで柔軟に設定できます。
    安定したデータバインディングのため、-FromData に渡されたコレクションは内部で System.ComponentModel.BindingList に変換されます。
    Location や Dock など、呼び出し側で容易に設定可能なレイアウトプロパティは、関数のシンプルさを保つため意図的に除外されています。
#>
    [CmdletBinding(DefaultParameterSetName = 'FromData')]
    param(
        # --- 動作モード ---
        [switch]$ReadOnly,

        # --- データと列の指定 (排他的) ---
        [Parameter(ParameterSetName = 'FromData')]
        [System.Collections.IEnumerable]$FromData,

        [Parameter(ParameterSetName = 'FromCount')]
        [int]$FromCount = 0,

        # --- データと列の定義 ---
        [string[]]$Columns,

        # --- 基本的なレイアウト ---
        [System.Drawing.Size]$Size,

        # --- ユーザー操作の制御 (独立したオプション) ---
        [switch]$Resizable,
        [switch]$Sortable
    )

    # 1. DataGridView オブジェクトの作成と基本設定
    $properties = @{
        Margin = $DEFAULT_MARGIN
        Font = $DEFAULT_FONT
        AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill
        RowHeadersVisible = $false
        AllowUserToResizeRows = $Resizable.IsPresent
        AllowUserToResizeColumns = $Resizable.IsPresent
    }
    if ($Size) {
        $properties.Size = $Size
    }
    if ($ReadOnly) {
        $properties.ReadOnly = $true
        $properties.AllowUserToAddRows = $false
        $properties.AllowUserToDeleteRows = $false
        $properties.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::FullRowSelect
    } else {
        $properties.ReadOnly = $false
        $properties.AllowUserToAddRows = $true
        $properties.AllowUserToDeleteRows = $true
        $properties.SelectionMode = [System.Windows.Forms.DataGridViewSelectionMode]::CellSelect
    }

    $dataGridView = New-Object System.Windows.Forms.DataGridView -Property $properties

    # 2. パラメータセットに応じた処理
    switch ($PSCmdlet.ParameterSetName) {
        'FromData' {
            $dataGridView.AutoGenerateColumns = $true

            if ($FromData) {
                if ($FromData -is [System.ComponentModel.BindingList[object]]) {
                    $bindingList = $FromData
                } else {
                    $bindingList = New-Object System.ComponentModel.BindingList[object]
                    $FromData.ForEach({ $bindingList.Add($_) })
                }
                $dataGridView.DataSource = $bindingList
            }
        }
        'FromCount' {
            $dataGridView.AutoGenerateColumns = $false
            if ($Columns) {
                foreach ($colName in $Columns) {
                    $col = New-Object System.Windows.Forms.DataGridViewTextBoxColumn -Property @{ Name = $colName; HeaderText = $colName }
                    $dataGridView.Columns.Add($col)
                }
            }
            if ($FromCount -gt 0) {
                1..$FromCount | ForEach-Object { $dataGridView.Rows.Add() }
            }
        }
    }

    # 3. ソート可否の設定
    if (-not $Sortable.IsPresent) {
        $dataGridView.Columns | ForEach-Object {
            $_.SortMode = [System.Windows.Forms.DataGridViewColumnSortMode]::NotSortable
        }
    }

    # 4. オブジェクトを返す
    return $dataGridView
}


#endregion


# 公開する関数をエクスポート
Export-ModuleMember -Function New-UiForm, New-UiPanel, New-UiFlowLayoutPanel, New-UiGroupBox, New-UiSpacer, New-UiButton, New-UiLabel, New-UiTextBox, New-UiRadioButton, New-UiDataGridView
