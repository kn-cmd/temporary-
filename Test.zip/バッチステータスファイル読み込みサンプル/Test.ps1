﻿function Update-FileStatusList {
    <#
    .SYNOPSIS
        CSVデータを受け取り、ファイルの実在確認を行ってステータスと更新日時を付与します。
    .PARAMETER InputObject
        Import-Csv などから渡されるオブジェクト（パイプライン入力対応）。
    .PARAMETER PathColumn
        ファイルパスが記載されている列名（デフォルト: "Path"）。
    .PARAMETER StatusColumn
        書き換えるステータスの列名（デフォルト: "Status"）。
    .PARAMETER SuccessValue
        ファイルが存在する場合に設定するステータス値（デフォルト: "9"）。
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true, ValueFromPipeline = $true)]
        [PSCustomObject]$InputObject,

        [string]$PathColumn = "Path",
        [string]$StatusColumn = "Status",
        [string]$SuccessValue = "9"
    )

    process {
        # 指定された列名からパスを取得
        $targetPath = $InputObject.$PathColumn

        # パスが空でないか、かつファイルが存在するかチェック
        if (-not [string]::IsNullOrWhiteSpace($targetPath) -and (Test-Path -Path $targetPath)) {
            
            # --- ファイルが存在する場合 ---
            
            # 1. 更新日時を取得
            $item = Get-Item -Path $targetPath
            $dateStr = $item.LastWriteTime.ToString("yyyy/MM/dd HH:mm:ss")

            # 2. Statusを指定値で上書き (-Force)
            $InputObject | Add-Member -MemberType NoteProperty -Name $StatusColumn -Value $SuccessValue -Force

            # 3. LastWriteTimeを追加・上書き
            $InputObject | Add-Member -MemberType NoteProperty -Name "LastWriteTime" -Value $dateStr -Force
        }
        else {
            # --- ファイルが存在しない場合 ---
            
            # Status は何もしない（元の値を維持）

            # LastWriteTime 列を空文字で確保（列ズレ防止のため）
            $InputObject | Add-Member -MemberType NoteProperty -Name "LastWriteTime" -Value "" -Force
        }

        # 加工したオブジェクトを出力
        Write-Output $InputObject
    }
}


# CSV読み込みからパイプラインで渡す
$results = Import-Csv ".\filelist.csv" | Update-FileStatusList
$results | Format-Table -AutoSize



# 更新対象ステータス名が "CheckState" の場合
$results = Import-Csv ".\filelist.csv" | Update-FileStatusList -StatusColumn "CheckState"
$results | Format-Table -AutoSize
