# 例: .NET Framework 4.x の csc.exe を使用する場合
$cscPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$webExtensionsDllPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll" # csc.exeと同じディレクトリにあることが多い

# DLLをコンパイルするコマンド
& $cscPath /target:library /reference:$webExtensionsDllPath MyJsonProcessor.cs