# PowerShell 開発事例集 (PowerShell Development Case Studies)

### 目的

本資料は、PowerShellスクリプト開発において、規約の内容をより明確に理解しやすくするための参考資料として、良い例と悪い例を提示し、高品質かつメンテナンス性の高いコード作成に貢献することを目的とします。

---

## 第1章. 関数設計と再利用性

### 1.1. 単一責任の原則と関数の分離

**【一般論】**
各関数は一つの明確な目的を持つべきです。複雑な処理は、それぞれ独立した責任を持つ小さな関数に分割することで、コードの可読性、テスト容易性、再利用性が向上します。

**【良い例】**
*   データ取得とデータ加工の責任を分離する。
```powershell
# ユーザーの生データを取得する関数
function Get-UserDataRaw {
    param([string]$UserId)
    # ... データベースやAPIからデータを取得するロジック ...
    return [PSCustomObject]@{Id=$UserId; Name="John Doe"; Email="john.doe@example.com"}
}

# ユーザーの表示名を整形して取得する関数
function Get-UserDisplayName {
    param([string]$UserId)
    $userData = Get-UserDataRaw -UserId $UserId
    if ($userData) {
        return "$($userData.Name) <$($userData.Email)>"
    }
    return $null
}
```

**【悪い例】**
*   一つの関数でデータ取得と表示名の整形の両方を行う。
```powershell
# データ取得と表示名整形を兼ねる関数
function Get-UserDisplayAndRawDataBad {
    param([string]$UserId)
    # ... データベースやAPIからデータを取得するロジック ...
    $userData = [PSCustomObject]@{Id=$UserId; Name="John Doe"; Email="john.doe@example.com"}
    Write-Host "ユーザー表示名: $($userData.Name) <$($userData.Email)>"
    return $userData # 生データも返す
}
```

### 1.2. 命名規則 (Verb-Noun)

**【一般論】**
PowerShellの標準コマンドレットに倣い、関数名は `動詞-名詞` の形式で記述します。これにより、関数の目的が明確になり、他のPowerShellコマンドレットとの一貫性が保たれます。

**【良い例】**
*   `Get-ServiceStatus`: サービスの状態を「取得」する。
*   `Set-ConfigurationValue`: 設定値を「設定」する。
*   `Start-ProcessLog`: プロセスログを「開始」する。

**【悪い例】**
*   `GetServiceStatus`: 動詞-名詞形式ではない。
*   `ServiceStatus`: 名詞のみで動詞がない。
*   `ProcessLogStart`: 動詞が名詞の後ろにある。

### 1.3. スクリプトの構造

**【一般論】**
スクリプトは、関連する機能を関数としてまとめ、モジュールとして再利用できるように設計し、実行ロジックは関数定義とは別に、明確に区切られた実行ブロックに記述します。

**【良い例】**
```powershell
# region 設定
$LogFilePath = "C:\Logs\MyScript.log"
# endregion

# region 関数定義
function Write-Log {
    param([string]$Message)
    Add-Content -Path $LogFilePath -Value "$(Get-Date) : $Message"
}

function Process-Data {
    param([string]$Data)
    Write-Log -Message "Processing data: $Data"
    # ... データの処理ロジック ...
    return "Processed: $Data"
}
# endregion

# region メイン実行ブロック
if ($PSScriptRoot) { # スクリプトとして実行された場合のみ
    Write-Log -Message "Script started."
    $result = Process-Data -Data "Sample Input"
    Write-Log -Message "Result: $result"
    Write-Log -Message "Script finished."
}
# endregion
```

**【悪い例】**
*   関数定義と実行ロジックが混在している、または関数化されていない。
```powershell
# 設定とロジックが混在
$LogFilePath = "C:\Logs\MyScript.log"
Add-Content -Path $LogFilePath -Value "$(Get-Date) : Script started."

# 関数化されていない処理
$data = "Sample Input"
Add-Content -Path $LogFilePath -Value "$(Get-Date) : Processing data: $data"
# ... データの処理ロジック ...
$result = "Processed: $data"
Add-Content -Path $LogFilePath -Value "$(Get-Date) : Result: $result"
Add-Content -Path $LogFilePath -Value "$(Get-Date) : Script finished."
```

### 1.4. モジュールのインポートとパスの管理

**【一般論】**
スクリプトがカスタムモジュールに依存する場合、`Import-Module` を使用してモジュールをロードします。モジュールがスクリプトと同じディレクトリ、またはそのサブディレクトリにある場合は、`$PSScriptRoot` を活用して相対パスで指定することで、スクリプトの移植性を確保します。`-Force` パラメータは、モジュールが既にロードされている場合でも再ロードを強制し、開発中の変更を反映させるのに便利です。

**【良い例】**
```powershell
# スクリプトのパスを取得し、モジュールをインポート
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
Import-Module -Name "$PSScriptRoot\ADUtils" -Force

# インポートしたモジュール内の関数を使用
$testSamAccountName = "johndoe"
try {
    $displayName = Get-ADUserDisplayName -SamAccountName $testSamAccountName
    if ($displayName) {
        Write-Host "DisplayName: $displayName"
    }
} catch {
    Write-Error "エラーが発生しました: $($_.Exception.Message)"
}
```

### 1.5. regionによるモジュールの整理

**【一般論】**
モジュールファイル内では、`#region` を使ってコードの役割ごとにブロックを分けることで、可読性が大幅に向上します。特に、外部に公開する関数と、内部でのみ使用するヘルパー関数を分離することは、モジュールの使い方を理解する上で非常に有効です。

**【良い例】**
```powershell
#region 公開関数
# モジュールの利用者が直接呼び出す関数
function Get-FormattedData { ... }
#endregion

#region ヘルパー関数
# 公開関数から呼び出される内部的な処理
function Get-RawData { ... }
#endregion
```

---

## 第2章. パラメータと柔軟性

### 2.1. 明示的なパラメータ定義と型指定

**【一般論】**
関数のパラメータは `param()` ブロックで明示的に定義し、適切な型を指定することで、関数の利用方法を明確にし、予期せぬ入力エラーを防ぎます。必須パラメータには `[Parameter(Mandatory=$true)]` 属性を付与します。

**【良い例】**
*   パラメータの型と必須属性を明確にする。
```powershell
function Process-Item {
    param (
        [Parameter(Mandatory=$true, HelpMessage="処理対象のアイテムIDを指定します。")]
        [int]$ItemId, # 整数型で必須
        [string]$OutputPath = "C:\Temp" # 文字列型でデフォルト値あり
    )
    # ...
}
```

**【悪い例】**
*   パラメータを定義しない、または型指定がない。
```powershell
function Process-ItemBad {
    param ($ItemId, $OutputPath) # 型指定なし、必須属性なし
    # ...
}
```

### 2.2. デフォルト値の活用

**【一般論】**
オプションのパラメータには適切なデフォルト値を設定することで、関数の呼び出しを簡素化し、柔軟性を高めます。

**【良い例】**
*   `OutputPath` にデフォルト値を設定。
```powershell
function Export-Data {
    param (
        [string]$Data = "Default Data",
        [string]$OutputPath = "C:\Exports\output.txt" # デフォルトの出力パス
    )
    # ...
}
```

**【悪い例】**
*   オプションのパラメータにデフォルト値がなく、呼び出し元で毎回指定が必要になる。
```powershell
function Export-DataBad {
    param (
        [string]$Data,
        [string]$OutputPath # デフォルト値なし
    )
    # ...
}
```

### 2.3. コレクション型パラメータの扱い

**【一般論】**
コレクション型（配列など）のパラメータは、要素が空の場合の挙動を明確にします。例えば、空のコレクションが渡された場合は、デフォルトの動作を適用するか、特定の処理をスキップするなど、意図した挙動を定義します。

**【良い例】**
```powershell
function Process-Items {
    param (
        [string[]]$Items = @() # デフォルトは空の配列
    )
    if ($Items.Count -gt 0) {
        foreach ($item in $Items) {
            Write-Host "Processing item: $item"
        }
    } else {
        Write-Host "処理対象のアイテムがありません。デフォルト動作を実行します。"
    }
}
```

**【悪い例】**
*   空のコレクションが渡された場合の挙動が不明確、またはエラーになる可能性がある。
```powershell
function Process-ItemsBad {
    param (
        [string[]]$Items
    )
    # $Items が $null の場合や空の場合にエラーになる可能性
    foreach ($item in $Items) {
        Write-Host "Processing item: $item"
    }
}
```

---

## 第3章. エラー管理と堅牢性

### 3.1. エラーの伝播と上位レベルでの捕捉

**【一般論】**
低レベルの関数では、ビジネスロジック上のエラー（例: 検索対象が見つからない、無効な入力）は `throw` を使用してエラーをスローし、呼び出し元にエラー処理を委ねます。これにより、エラー処理ロジックが一元化され、各関数の責任が明確になります。

**【良い例】**
*   低レベル関数でエラーをスローし、上位レベルで捕捉・処理する。
```powershell
# 低レベル関数：ファイルが存在しない場合にエラーをスロー
function Get-FileContent {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        throw "ファイルが見つかりません: $Path"
    }
    return (Get-Content $Path)
}

# 上位レベル関数：エラーを捕捉し、ユーザーに通知
function Process-File {
    param([string]$FilePath)
    try {
        $content = Get-FileContent -Path $FilePath
        Write-Host "ファイル内容: $content"
    } catch {
        Write-Error "ファイルの処理中にエラーが発生しました: $($_.Exception.Message)"
    }
}
```

**【悪い例】**
*   低レベル関数で `Write-Error` を使用してしまい、呼び出し元がエラーをプログラム的に捕捉できない。
```powershell
# 低レベル関数：エラーをスローせずWrite-Errorで終了
function Get-FileContentBad {
    param([string]$Path)
    if (-not (Test-Path $Path)) {
        Write-Error "ファイルが見つかりません: $Path"
        return $null # エラーをスローしないため、処理が続行される可能性がある
    }
    return (Get-Content $Path)
}

# 上位レベル関数：try-catchしてもエラーを捕捉できない
function Process-FileBad {
    param([string]$FilePath)
    try {
        $content = Get-FileContentBad -Path $FilePath # Write-Errorはtry-catchで捕捉されない
        if ($content) {
            Write-Host "ファイル内容: $content"
        }
    } catch {
        # ここには到達しない
        Write-Host "エラーを捕捉しました (しかし実際には捕捉されない)"
    }
}
```

### 3.2. エラーメッセージの具体性

**【一般論】**
エラーメッセージは、問題の特定とデバッグを容易にするために、具体的で十分な情報を含むべきです。エラーが発生した関数名、原因、関連する変数などの情報を含めます。

**【良い例】**
```powershell
throw "ユーザー [$SamAccountName] が見つかりませんでした。検索フィルター: $searcher.Filter"
Write-Error "Get-UserDisplayName でエラーが発生しました。ユーザーID: $SamAccountName。詳細: $($_.Exception.Message)"
```

**【悪い例】**
*   情報が不足しており、問題の特定が困難。
```powershell
throw "エラーが発生しました。"
Write-Error "処理失敗。"
```

---

## 第4章. ドキュメントと可読性

### 4.1. SYNOPSISによる関数の概要説明

**【一般論】**
すべてのカスタム関数には、`<# .SYNOPSIS ... #>` 形式で関数の目的を簡潔かつ抽象的に記述します。これにより、`Get-Help` コマンドで関数の概要を素早く理解でき、コードの可読性と保守性が向上します。

**【良い例】**
```powershell
function Get-SystemInfo {
    <#
    .SYNOPSIS
    現在のシステム情報を取得し、PSCustomObjectとして返します。
    #>
    # ...
}
```

**【悪い例】**
*   SYNOPSISがない、または内容が不適切。
```powershell
function Get-SystemInfoBad {
    # SYNOPSISがない
    # ...
}
```

### 4.2. インラインコメントの活用

**【一般論】**
コードの意図や「なぜそのように実装されているのか」を説明するために、必要に応じてインラインコメントを使用します。冗長な「何をしているか」のコメントは避け、コードの可読性を損なわないようにします。

**【良い例】**
```powershell
# この処理は、特定の条件下でのみ実行されるため、パフォーマンスを考慮して遅延評価しています。
if ($condition) {
    # ...
}

# エラー処理は呼び出し元で行うため、ここではtry-catchを使用しない
$result = Some-FunctionThatThrowsError
```

**【悪い例】**
*   コードをそのまま説明するだけの冗長なコメント。
```powershell
$i = 0 # iを0に設定する
$i++ # iをインクリメントする
```

---

## 第5章. その他の実践

### 5.1. 出力形式 (Output Format)

**【一般論】**
関数は、結果を `Write-Host` で直接表示するのではなく、オブジェクト（例: `PSCustomObject`）として返却することを優先します。これにより、呼び出し元が結果をプログラム的に利用しやすくなります。`Write-Host` は、ユーザーへの情報表示のみに限定して使用します。

**【良い例】**
```powershell
function Get-ProcessInfo {
    param([string]$ProcessName)
    $process = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
    if ($process) {
        return [PSCustomObject]@{ 
            Name = $process.ProcessName
            Id = $process.Id
            CPU = $process.CPU
        }
    }
    return $null
}

# 呼び出し元で結果を利用
$info = Get-ProcessInfo -ProcessName "notepad"
if ($info) {
    Write-Host "プロセス名: $($info.Name), ID: $($info.Id)"
}
```

**【悪い例】**
*   関数内で `Write-Host` を多用し、結果をオブジェクトとして返さない。
```powershell
function Get-ProcessInfoBad {
    param([string]$ProcessName)
    $process = Get-Process -Name $ProcessName -ErrorAction SilentlyContinue
    if ($process) {
        Write-Host "プロセス名: $($process.ProcessName)"
        Write-Host "ID: $($process.Id)"
    }
    # オブジェクトを返さないため、呼び出し元で結果をプログラム的に利用できない
}
```

---

## 第6章. リソース管理 (Resource Management)

### 6.1. try-finallyによる確実なリソース解放

**【一般論】**
ファイルハンドルやデータベース接続、COMオブジェクトなど、使用後に明示的な解放（`Dispose()`）が必要なリソースを扱う場合、`try-finally` は不可欠です。`finally` ブロック内のコードは、`try` ブロックでエラーが発生しても、しなくても、必ず実行されることが保証されます。

**【良い例】**
```powershell
$stream = $null
try {
    $stream = [System.IO.File]::OpenRead("C:\data.txt")
    # ... ストリームを使った処理 ...
    # ここでエラーが発生しても...
} finally {
    # ...finallyブロックは必ず実行される
    if ($stream) {
        $stream.Dispose()
    }
}
```

**【悪い例】**
```powershell
# try-finallyを使わない場合
$stream = [System.IO.File]::OpenRead("C:\data.txt")
# ... ストリームを使った処理 ...
# もしこの行でエラーが発生すると、Dispose()が呼ばれず、リソースが解放されない
$stream.Dispose()
```