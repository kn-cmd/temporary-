﻿
Add-Type -AssemblyName System.Windows.Forms

#region Message Box

<#
.SYNOPSIS
    OKボタンのみを持つ通知用のメッセージボックスを表示します。
.EXAMPLE
    Show-UIMessage -Message "バックアップが正常に完了しました。" -IconType Info -Title "完了通知"
#>
function Show-UIMessage {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [string]$Title = "通知",
        [ValidateSet("Info", "Warn", "Error")]
        [string]$IconType = "Info"
    )

    $icon = switch ($IconType) {
        "Warn"  { [System.Windows.Forms.MessageBoxIcon]::Warning }
        "Error" { [System.Windows.Forms.MessageBoxIcon]::Error }
        default { [System.Windows.Forms.MessageBoxIcon]::Information }
    }

    [void][System.Windows.Forms.MessageBox]::Show($Message, $Title, "OK", $icon)
}

<#
.SYNOPSIS
    OK/Cancelボタンを持つ確認用のメッセージボックスを表示します。
.OUTPUTS
    [bool] - ユーザーが「OK」を選択した場合は $true、「キャンセル」を選択した場合は $false を返します。
.EXAMPLE
    if (Confirm-UIAction -Message "この操作は元に戻せません。続行しますか？" -IconType Warn) {
        Write-Host "処理を実行します。"
    }
#>
function Confirm-UIAction {
    [CmdletBinding()]
    [OutputType([bool])]
    param(
        [Parameter(Mandatory)]
        [string]$Message,
        [string]$Title = "確認",
        [ValidateSet("Info", "Warn", "Error")]
        [string]$IconType = "Warn"
    )

    $icon = switch ($IconType) {
        "Info"  { [System.Windows.Forms.MessageBoxIcon]::Information }
        "Error" { [System.Windows.Forms.MessageBoxIcon]::Error }
        default { [System.Windows.Forms.MessageBoxIcon]::Warning }
    }

    $result = [System.Windows.Forms.MessageBox]::Show($Message, $Title, "OKCancel", $icon)

    return ($result -eq [System.Windows.Forms.DialogResult]::OK)
}

#endregion

#region File Dialogs

<#
.SYNOPSIS
    ファイルを開くためのダイアログボックスを表示します。
.OUTPUTS
    [string] - 選択されたファイルの完全パス。キャンセルされた場合は空文字列。
.EXAMPLE
    $filePath = Show-OpenFile -Filter "テキストファイル (*.txt)|*.txt|すべてのファイル (*.*)|*.*"
    if ($filePath) {
        Get-Content $filePath
    }
#>
function Show-OpenFile {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [string]$InitialDirectory,
        [string]$Filter = "すべてのファイル (*.*)|*.*",
        [string]$Title = "ファイルを開く"
    )
    
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    
    $result = ""
    try {
        if ($PSBoundParameters.ContainsKey('InitialDirectory')) {
            $dialog.InitialDirectory = $InitialDirectory
        }
        $dialog.Filter = $Filter
        $dialog.Title = $Title
        $dialog.CheckFileExists = $true

        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $result = $dialog.FileName
        }
    }
    finally {
        $dialog.Dispose()
    }
    
    return $result
}

<#
.SYNOPSIS
    ファイルを保存するためのダイアログボックスを表示します。
.OUTPUTS
    [string] - 指定された保存ファイルの完全パス。キャンセルされた場合は空文字列。
.EXAMPLE
    $savePath = Show-SaveFile -Filter "テキストファイル (*.txt)|*.txt"
    if ($savePath) {
        "Hello, World!" | Out-File -FilePath $savePath
    }
#>
function Show-SaveFile {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [string]$InitialDirectory,
        [string]$Filter = "すべてのファイル (*.*)|*.*",
        [string]$Title = "名前を付けて保存",
        [bool]$OverwritePrompt = $true
    )
    
    $dialog = New-Object System.Windows.Forms.SaveFileDialog

    $result = ""
    try {
        if ($PSBoundParameters.ContainsKey('InitialDirectory')) {
            $dialog.InitialDirectory = $InitialDirectory
        }
        $dialog.Filter = $Filter
        $dialog.Title = $Title
        $dialog.OverwritePrompt = $OverwritePrompt

        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $result = $dialog.FileName
        }
    }
    finally {
        $dialog.Dispose()
    }

    return $result
}

<#
.SYNOPSIS
    フォルダを選択するためのダイアログボックスを表示します。
.OUTPUTS
    [string] - 選択されたフォルダの完全パス。キャンセルされた場合は空文字列。
.EXAMPLE
    $folderPath = Show-FolderBrowserDialog -Description "処理対象のフォルダを選択してください"
    if ($folderPath) {
        Get-ChildItem $folderPath
    }
#>
function Show-FolderBrowserDialog {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [string]$Description = "フォルダを選択してください",
        [string]$InitialDirectory
    )
    
    $dialog = New-Object System.Windows.Forms.FolderBrowserDialog
    
    $result = ""
    try {
        if ($PSBoundParameters.ContainsKey('InitialDirectory')) {
            $dialog.SelectedPath = $InitialDirectory
        }
        $dialog.Description = $Description

        if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
            $result = $dialog.SelectedPath
        }
    }
    finally {
        $dialog.Dispose()
    }
    
    return $result
}

#endregion
