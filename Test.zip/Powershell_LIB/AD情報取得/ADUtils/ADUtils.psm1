#Requires -Version 5.1

#region エラークラス
# Get-ADUserDisplayName -ThrowIfNotFound スイッチ使用時にスローされる専用の例外クラス。
class UserNotFoundException : System.Exception {
    UserNotFoundException([string]$Message) : base($Message) {}
}
#endregion

#region 公開関数
function Get-ADUserDisplayName {
    <#
    .SYNOPSIS
    指定されたsAMAccountNameを持つADユーザーの表示名（DisplayName）を取得します。

    .DESCRIPTION
    この関数は、Active Directoryからユーザーの表示名を取得します。
    ユーザーが見つからない場合、デフォルトの動作として$nullを返します。
    -ThrowIfNotFound スイッチを指定すると、見つからない場合にエラーをスローします。

    .NOTES
    -ThrowIfNotFound 使用時にスローされる例外は [UserNotFoundException] 型です。
    #>
    param (
        [Parameter(Mandatory=$true)]
        [string]$SamAccountName,

        [Parameter(Mandatory=$false)]
        [switch]$ThrowIfNotFound
    )

    $userEntry = $null
    $returnValue = $null

    try {
        # ヘルパー関数を呼び出して、ADから生のユーザーオブジェクトを取得する
        $userEntry = Get-ADUserRawData -SamAccountName $SamAccountName -PropertiesToLoad @("displayName")
        if ($userEntry) {
            $returnValue = $userEntry.Properties["displayName"].Value
        }
    } catch [UserNotFoundException] {
        # ユーザーが見つからない場合、呼び出し元の意図（-ThrowIfNotFound）に応じてエラーをスローするか、$nullを返すかを決定する
        if ($ThrowIfNotFound) {
            throw $_ # 元の例外情報を維持して再スロー
        }
    } catch {
        # 接続障害など、その他の予期せぬエラーは呼び出し元に通知する
        throw "Get-ADUserDisplayName で予期せぬエラーが発生しました: $($_.Exception.Message)"
    } finally {
        # COMオブジェクトは必ず解放する
        if ($userEntry) {
            $userEntry.Dispose()
        }
    }

    return $returnValue
}
#endregion

#region ヘルパー関数
function Get-ADUserRawData {
    <#
    .SYNOPSIS
    ADユーザーのDirectoryEntryオブジェクトを取得する内部ヘルパー関数。
    見つからない場合は UserNotFoundException をスローします。
    #>
    param (
        [Parameter(Mandatory=$true)]
        [string]$SamAccountName,
        [string[]]$PropertiesToLoad = @()
    )

    # 現在のドメイン情報からLDAPの検索パスを構築
    try {
        $currentDomain = [System.DirectoryServices.ActiveDirectory.Domain]::GetCurrentDomain()
        $domainDN = $currentDomain.GetDirectoryEntry().distinguishedName
    } catch {
        throw "ドメイン情報の取得に失敗しました。詳細: $($_.Exception.Message)"
    }
    if ([string]::IsNullOrWhiteSpace($domainDN)) {
        throw "ドメインに参加していないため、ドメイン情報を取得できませんでした。"
    }
    $ldapPath = "LDAP://$domainDN"

    # ADSIを利用してユーザーを検索
    $searcher = New-Object System.DirectoryServices.DirectorySearcher
    $searchRootEntry = New-Object System.DirectoryServices.DirectoryEntry($ldapPath)
    try {
        $searcher.SearchRoot = $searchRootEntry
        $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$SamAccountName))"
        $searcher.PropertiesToLoad.AddRange($PropertiesToLoad)
        $result = $searcher.FindOne()
    } finally {
        # 使用したCOMオブジェクトを解放
        if ($searcher) { $searcher.Dispose() }
        if ($searchRootEntry) { $searchRootEntry.Dispose() }
    }

    if ($result) {
        return $result.GetDirectoryEntry()
    } else {
        # 検索結果がなければ、ユーザー不存在として専用エラーをスローする
        throw [UserNotFoundException]::new("ユーザー [$SamAccountName] が見つかりませんでした。")
    }
}
#endregion

# モジュールとして利用可能な関数をエクスポート
Export-ModuleMember -Function 'Get-ADUserDisplayName'
