#Requires -Version 5.1

function Get-ADUserRawData {
    <#
    .SYNOPSIS
    スクリプト実行ユーザーと同じドメイン内で、指定されたsAMAccountNameを持つActive DirectoryユーザーのDirectoryEntryオブジェクトを取得します。
    ユーザーが見つからない場合はエラーをスローします。
    【注意】この関数が返すDirectoryEntryオブジェクトは、呼び出し元でDispose()する必要があります。
    #>
    param (
        [Parameter(Mandatory=$true)]
        [string]$SamAccountName,
        [string[]]$PropertiesToLoad = @() # 取得するプロパティを指定。空の場合はADのデフォルトプロパティを取得。
    )

    # 現在のドメイン情報を取得し、LDAP検索ルートを設定
    $adSystemInfo = New-Object -ComObject "ADSystemInfo"
    $domainDN = $adSystemInfo.DomainDNS
    $ldapPath = "LDAP://$domainDN"

    # ADSI DirectorySearcher を使用してユーザーを検索
    $searcher = New-Object System.DirectoryServices.DirectorySearcher
    $searchRootEntry = New-Object System.DirectoryServices.DirectoryEntry($ldapPath)
    try {
        $searcher.SearchRoot = $searchRootEntry
        $searcher.Filter = "(&(objectCategory=person)(objectClass=user)(sAMAccountName=$SamAccountName))"

        # 指定されたプロパティを検索対象に追加
        foreach ($prop in $PropertiesToLoad) {
            $searcher.PropertiesToLoad.Add($prop)
        }

        $result = $searcher.FindOne()
    } finally {
        # 使用したCOMオブジェクトを解放
        if ($searcher) { $searcher.Dispose() }
        if ($searchRootEntry) { $searchRootEntry.Dispose() }
    }

    if ($result) {
        $userEntry = $result.GetDirectoryEntry()
        return $userEntry
    } else {
        throw "ユーザー [$SamAccountName] が見つかりませんでした。"
    }
}

function Get-ADUserDisplayName {
    <#
    .SYNOPSIS
    指定されたsAMAccountNameを持つActive DirectoryユーザーのDisplayNameを取得します。
    #>
    param (
        [Parameter(Mandatory=$true)]
        [string]$SamAccountName
    )

    $userEntry = $null
    try {
        # 生のADユーザーデータを取得し、DisplayNameを抽出
        $userEntry = Get-ADUserRawData -SamAccountName $SamAccountName -PropertiesToLoad @("displayName")
        if ($userEntry) {
            # displayNameプロパティは常に単一の値を持つ
            return $userEntry.Properties["displayName"].Value
        } else {
            return $null # Get-ADUserRawDataがエラーをスローするため、通常ここには到達しない
        }
    } catch {
        # エラーを再スローして、呼び出し元に問題を通知する
        throw "Get-ADUserDisplayName でエラーが発生しました: $($_.Exception.Message)"
    } finally {
        # 取得したDirectoryEntryオブジェクトを解放
        if ($userEntry) {
            $userEntry.Dispose()
        }
    }
}

# モジュールとして利用可能な関数をエクスポート
Export-ModuleMember -Function 'Get-ADUserRawData', 'Get-ADUserDisplayName'
