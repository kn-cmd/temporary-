#Requires -Version 5.1

<#
.SYNOPSIS
ADHelperモジュールの関数をテストするためのスクリプト。
#>

# スクリプトのパスを取得し、モジュールをインポート
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
Import-Module -Name "$PSScriptRoot\ADUtils" -Force

# --- テスト実行部分 --- 
# ここでテストしたいユーザーのSAMAccountNameを指定してください。
$testSamAccountName = "johndoe" 

try {
    $displayName = Get-ADUserDisplayName -SamAccountName $testSamAccountName

    if ($displayName) {
        Write-Host "`n--- ユーザー [$testSamAccountName] の情報 ---"
        Write-Host "DisplayName: $displayName"
    } else {
        Write-Warning "ユーザー [$testSamAccountName] の DisplayName を取得できませんでした。"
    }
} catch {
    Write-Error "テスト実行中にエラーが発生しました: $($_.Exception.Message)"
}

