#Requires -Version 5.1

<#
.SYNOPSIS
ADHelperモジュールの関数をテストするためのスクリプト。
#>

# スクリプトのパスを取得し、モジュールをインポート
$PSScriptRoot = Split-Path -Parent -Path $MyInvocation.MyCommand.Definition
Import-Module -Name "$PSScriptRoot\ADUtils" -Force

# --- テスト実行部分 --- 
# ここでテストしたいユーザーのSAMAccountNameを指定してください。
$testSamAccountName = "johndoe" 

try {
    $displayName = Get-ADUserDisplayName -SamAccountName $testSamAccountName

    if ($displayName) {
        Write-Host "`n--- ユーザー [$testSamAccountName] の情報 ---"
        Write-Host "DisplayName: $displayName"
    } else {
        Write-Warning "ユーザー [$testSamAccountName] の DisplayName を取得できませんでした。"
    }
} catch {
    Write-Error "テスト実行中にエラーが発生しました: $($_.Exception.Message)"
}

# --- Get-ADUserRawData のテスト例 ---
# こちらはDisposeが必要なため、取り扱いに注意
Write-Host "`n--- Get-ADUserRawData のテスト ---"
$rawUser = $null
try {
    $rawUser = Get-ADUserRawData -SamAccountName $testSamAccountName -PropertiesToLoad @("mail", "title")
    if($rawUser) {
        Write-Host "Mail: $($rawUser.Properties['mail'].Value)"
        Write-Host "Title: $($rawUser.Properties['title'].Value)"
    }
} catch {
    Write-Error "Get-ADUserRawData のテスト中にエラーが発生しました: $($_.Exception.Message)"
} finally {
    if ($rawUser) {
        $rawUser.Dispose()
        Write-Host "($rawUser オブジェクトを解放しました)"
    }
}
