import subprocess
import os
from pathlib import Path

def create_test_file(path, content_bytes):
    Path(path).write_bytes(content_bytes)

def run_tool(args):
    result = subprocess.run(['python', 'fixedlength_to_csv.py'] + args, capture_output=True, text=True)
    return result

def test_all():
    input_file = "test_input.dat"
    output_file = "test_output.csv"
    
    # 1. 正常系 & トリム & 改行コード確認
    # レコード1: "ITEM1     "(10), "VALUE1    "(10) -> 合計20
    # レコード2: "  ITEM2   "(10), "  VALUE2  "(10) -> 合計20
    content = b"ITEM1     VALUE1    " + b"  ITEM2     VALUE2  "
    create_test_file(input_file, content)
    
    print("--- Test 1: Default (No Trim, CRLF) ---")
    run_tool([input_file, output_file, "-l", "10", "10", "-n", "CRLF"])
    out_content = Path(output_file).read_bytes()
    print(f"Output bytes: {out_content}")
    assert b"ITEM1     ,VALUE1    \r\n" in out_content
    
    print("--- Test 2: Trim & LF ---")
    run_tool([input_file, output_file, "-l", "10", "10", "-n", "LF", "--trim"])
    out_content = Path(output_file).read_bytes()
    print(f"Output bytes: {out_content}")
    assert b"ITEM1,VALUE1\n" in out_content
    assert b"ITEM2,VALUE2\n" in out_content

    # 2. 不完全な終端のテスト
    # 合計20バイト必要なのに、最後に5バイト余計なデータがある場合
    content_incomplete = content + b"EXTRA" 
    create_test_file(input_file, content_incomplete)
    
    print("--- Test 3: Incomplete Ending (ignore) ---")
    run_tool([input_file, output_file, "-l", "10", "10", "-i", "ignore"])
    out_content = Path(output_file).read_bytes()
    # 最後の5バイトは無視され、2レコードのみ出力されるはず
    assert out_content.count(b"\n") == 2
    print("OK: Ignored extra bytes.")

    print("--- Test 4: Incomplete Ending (error) ---")
    res = run_tool([input_file, output_file, "-l", "10", "10", "-i", "error"])
    print(f"Error output: {res.stderr}")
    assert "不完全なレコード" in res.stderr
    print("OK: Caught error.")

    print("--- Test 5: Incomplete Ending (fill) ---")
    run_tool([input_file, output_file, "-l", "10", "10", "-i", "fill", "--trim"])
    out_content = Path(output_file).read_bytes()
    print(f"Output bytes: {out_content}")
    # 3レコード目として "EXTRA" + "     " (5spaces) -> trimされて "EXTRA", "" になるはず
    assert b"EXTRA," in out_content
    print("OK: Filled and processed last record.")

    # 後片付け
    for f in [input_file, output_file]:
        if os.path.exists(f): os.remove(f)

if __name__ == "__main__":
    test_all()
    print("\nAll tests passed successfully!")
