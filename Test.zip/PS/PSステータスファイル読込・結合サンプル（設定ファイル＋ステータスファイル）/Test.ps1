﻿# ============================================
# Join-LeftObject 関数定義 (シンプル版)
# ============================================

function Join-LeftObject {
    [CmdletBinding()]
    param(
        # 左側のデータ（Import-Csv の結果などを想定）
        [Parameter(Mandatory=$true)]
        [PSObject[]]$LeftObject,

        # 右側のデータ（Import-Csv の結果などを想定）
        [Parameter(Mandatory=$true)]
        [PSObject[]]$RightObject,

        # 結合キーとなるプロパティ名
        [Parameter(Mandatory=$true)]
        [string]$JoinKey,

        # 右側のデータから追加したいプロパティ名
        [Parameter(Mandatory=$true)]
        [string[]]$RightColumns,

        # 対応するデータがない場合のデフォルト値
        [string]$NullValue = ""
    )
    
    # 1. 右側のデータをハッシュテーブルに格納（高速検索のため）
    $RightDataMap = @{}
    foreach ($obj in $RightObject) {
        $RightDataMap[$obj.$JoinKey] = $obj
    }

    # 2. 結合に使用する Select-Object のプロパティ配列を動的に作成
    $SelectProps = @()
    $SelectProps += "*" # 左側の全てのプロパティ

    foreach ($col in $RightColumns) {
        $SelectProps += @{
            Name       = $col
            Expression = { 
                $key = $_.$JoinKey
                $RightRow = $RightDataMap[$key]
                if ($RightRow) { 
                    $RightRow.$col 
                } else { 
                    $NullValue 
                }
            }
        }
    }

    # 3. 結合を実行し、結果を返す
    $LeftObject | Select-Object $SelectProps
}

# --- 実行例 ---
# サンプルCSV作成は省略 (以前のコードを参照)
$LeftSideData  = Import-Csv -Path '.\LeftTable.csv'
$RightSideData = Import-Csv -Path '.\RightTable.csv'

$Result = Join-LeftObject `
    -LeftObject $LeftSideData `
    -RightObject $RightSideData `
    -JoinKey 'ID' `
    -RightColumns @("Age", "City") `
    -NullValue "(N/A)"

$Result | Format-Table -AutoSize
