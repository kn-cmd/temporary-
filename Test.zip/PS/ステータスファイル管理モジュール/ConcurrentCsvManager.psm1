﻿Add-Type -AssemblyName Microsoft.VisualBasic

#region Exception Classes
class SchemaValidationException : System.Exception {
    SchemaValidationException([string]$message) : base($message) {}
}

class DuplicateKeyException : System.Exception {
    DuplicateKeyException([string]$message) : base($message) {}
}

class OptimisticLockingException : System.Exception {
    OptimisticLockingException([string]$message) : base($message) {}
}

class LockTimeoutException : System.Exception {
    LockTimeoutException([string]$message) : base($message) {}
}
#endregion

#region Private Functions
#
# モジュール内部で使用されるヘルパー関数。
#

function Invoke-InternalFileLock {
<#
.SYNOPSIS
    ファイルに対してリトライロジック付きのロックを取得します。
.DESCRIPTION
    指定されたファイルパスに対して、指定されたモードとアクセス権でファイルストリームを開きます。
    ロックの取得に失敗した場合は、指定された回数だけリトライします。
    ダーティリードが許可されている読み取りアクセスの場合は、共有ロックの種類を調整します。
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$SessionObject,

        [Parameter(Mandatory = $true)]
        [System.IO.FileMode]$FileMode,

        [Parameter(Mandatory = $true)]
        [System.IO.FileAccess]$FileAccess,

        [Parameter(Mandatory = $false)]
        [switch]$AllowDirtyRead
    )

    # 初期化
    $filePath = $SessionObject.FilePath
    $maxRetries = $SessionObject.MaxRetries
    $retryIntervalMs = $SessionObject.RetryIntervalMs

    $fileStream = $null
    $retries = 0

    # ロック取得リトライ
    while ($retries -le $maxRetries) {
        try {
            # --- ロック種別の決定 ---
            $fileShare = [System.IO.FileShare]::None # デフォルトは排他ロック

            if ($AllowDirtyRead.IsPresent -and ($FileAccess -eq [System.IO.FileAccess]::Read)) {
                $fileShare = [System.IO.FileShare]::ReadWrite # 読み取り時にダーティリードを許可
            } elseif (-not $AllowDirtyRead.IsPresent -and ($FileAccess -eq [System.IO.FileAccess]::Read)) {
                $fileShare = [System.IO.FileShare]::Read # 読み取り時に書き込みのみ禁止
            }
            
            # --- ファイルストリームの作成 ---
            $fileStream = New-Object System.IO.FileStream($filePath, $FileMode, $FileAccess, $fileShare)
            
            return $fileStream # ロック取得成功
        }
        catch [System.IO.IOException] {
            # --- ロック失敗時のリトライ処理 ---
            $retries++
            if ($retries -le $maxRetries) {
                Start-Sleep -Milliseconds $retryIntervalMs
            } else {
                throw (New-Object LockTimeoutException("Failed to acquire file lock for '$filePath' after $($maxRetries+1) attempts."))
            }
        }
        catch {
            # --- その他の例外処理 ---
            throw
        }
    }
}

#endregion

#region Public Functions
#
# モジュールによってエクスポートされるPublic関数。
#

function New-CsvManagerSession {
<#
.SYNOPSIS
    CSVファイルを操作するための新しいセッションを初期化します。
.DESCRIPTION
    指定されたCSVファイルパスと列定義を使用して、セッションオブジェクトを作成します。
    ファイルが存在しない場合は、ヘッダー行を含む新しいCSVファイルを作成します。
    ファイルが既に存在する場合は、ヘッダーが指定された列定義と一致するかを検証します。
    この関数は、後続のデータ操作関数 (Get-CsvData, Invoke-CsvUpsert) で使用するセッションオブジェクトを返します。
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$FilePath,

        [Parameter(Mandatory = $true)]
        [string[]]$Columns,

        [System.Text.Encoding]$Encoding = (New-Object System.Text.UTF8Encoding($false)),

        [int]$MaxRetries = 10,

        [int]$RetryIntervalMs = 100
    )

    # セッションオブジェクト作成
    $sessionObject = [PSCustomObject]@{
        FilePath        = $FilePath
        Columns         = $Columns
        Encoding        = $Encoding
        MaxRetries      = $MaxRetries
        RetryIntervalMs = $RetryIntervalMs
    }

    $fileStream = $null
    $reader = $null
    $writer = $null

    try {
        # ファイルロックとストリーム初期化
        $fileStream = Invoke-InternalFileLock `
            -SessionObject $sessionObject `
            -FileMode ([System.IO.FileMode]::OpenOrCreate) `
            -FileAccess ([System.IO.FileAccess]::ReadWrite)

        $reader = New-Object System.IO.StreamReader($fileStream, $sessionObject.Encoding)
        $writer = New-Object System.IO.StreamWriter($fileStream, $sessionObject.Encoding)
        $writer.AutoFlush = $true
            
        # ヘッダーの作成または検証
        if ($fileStream.Length -eq 0) {
            # --- 新規ファイルの場合、ヘッダーを書き込む ---
            $writer.WriteLine(($sessionObject.Columns -join ','))
            $writer.Flush()
        }
        else {
            # --- 既存ファイルの場合、ヘッダーを検証 ---
            $fileStream.Seek(0, [System.IO.SeekOrigin]::Begin)

            $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($reader)
            $parser.SetDelimiters(',')
            $parser.HasFieldsEnclosedInQuotes = $true
            $parser.TrimWhiteSpace = $true
            $existingHeaders = $parser.ReadFields()

            if ($existingHeaders.Count -ne $sessionObject.Columns.Count) {
                throw (New-Object SchemaValidationException("既存のCSVファイル '$($sessionObject.FilePath)' のヘッダー列数が指定された列数と一致しません。既存: $($existingHeaders.Count), 指定: $($sessionObject.Columns.Count)。"))
            }

            for ($i = 0; $i -lt $existingHeaders.Count; $i++) {
                if ($existingHeaders[$i] -ne $sessionObject.Columns[$i]) {
                    throw (New-Object SchemaValidationException("既存のCSVファイル '$($sessionObject.FilePath)' のヘッダーが一致しません。期待値: '$($sessionObject.Columns[$i])', 実際: '$($existingHeaders[$i])' (列 $($i+1))。"))
                }
            }
        }
    }
    finally {
        # リソース解放
        if ($writer) { $writer.Dispose() }
        if ($reader) { $reader.Dispose() }
        if ($fileStream) { $fileStream.Dispose() }
    }

    return $sessionObject
}

function Get-CsvData {
<#
.SYNOPSIS
    CSVファイルからデータを取得します。
.DESCRIPTION
    セッションオブジェクトを使用してCSVファイルからデータを読み込みます。
    -Filter パラメータで指定された条件に一致する行をフィルタリングできます。
    -Unique スイッチを指定すると、結果が一意である（単一のレコードである）ことを検証します。
    -AllowDirtyRead スイッチを使用すると、ロック中のファイルからコミットされていないデータを読み取る（ダーティリード）ことができます。
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$SessionObject,

        [hashtable]$Filter,

        [switch]$Unique,

        [switch]$AllowDirtyRead
    )

    $columns = $SessionObject.Columns
    $filteredRecords = [System.Collections.Generic.List[psobject]]::new()

    $fileStream = $null
    $reader = $null

    try {
        # ファイルロックとストリーム初期化
        $fileStream = Invoke-InternalFileLock `
            -SessionObject $SessionObject `
            -FileMode ([System.IO.FileMode]::Open) `
            -FileAccess ([System.IO.FileAccess]::Read) `
            -AllowDirtyRead:$AllowDirtyRead.IsPresent

        $reader = New-Object System.IO.StreamReader($fileStream, $SessionObject.Encoding)
        
        # データ読み込みとフィルタリング
        if ($fileStream.Length -eq 0) {
            return # ファイルが空の場合は何も返さない
        }

        $reader.ReadLine() | Out-Null # ヘッダー行をスキップ

        $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($reader)
        $parser.SetDelimiters(',')
        $parser.HasFieldsEnclosedInQuotes = $true
        $parser.TrimWhiteSpace = $true

        while (-not $parser.EndOfData) {
            $values = $parser.ReadFields()

            # --- PSCustomObjectの作成 ---
            $row = [ordered]@{}
            for ($i = 0; $i -lt $columns.Count; $i++) {
                $value = if ($i -lt $values.Length) { $values[$i] } else { "" }
                $row[($columns[$i]).Trim()] = $value
            }
            $record = [PSCustomObject]$row

            # --- フィルタ条件の評価 ---
            $match = $true
            if ($Filter) {
                foreach ($key in $Filter.Keys) {
                    if ($record.PSObject.Properties.Name -contains $key) {
                        if ($record.$key -ne $Filter.$key) {
                            $match = $false
                            break
                        }
                    } else {
                        $match = $false # フィルタキーがカラムに存在しない
                        break
                    }
                }
            }

            if ($match) {
                $filteredRecords.Add($record)
            }
        }
    }
    finally {
        # リソース解放
        if ($reader) { $reader.Dispose() }
        if ($fileStream) { $fileStream.Dispose() }
    }

    # Uniqueスイッチの処理
    if ($Unique.IsPresent) {
        if ($filteredRecords.Count -eq 1) {
            return $filteredRecords[0]
        } elseif ($filteredRecords.Count -gt 1) {
            throw (New-Object DuplicateKeyException("Get-CsvData -Unique: フィルタ条件に一致するレコードが複数見つかりました。ファイル: $($SessionObject.FilePath), フィルタ: $($Filter | Out-String)."))
        } else {
            return $null
        }
    }

    return $filteredRecords
}

function Invoke-CsvUpsert {
<#
.SYNOPSIS
    CSVファイル内のデータを更新または挿入（Upsert）します。
.DESCRIPTION
    -KeyColumns で指定されたキーを使用して、CSVファイル内の既存のレコードを検索します。
    一致するレコードが見つかった場合は、-Data で指定された値でレコードを更新します。
    一致するレコードが見つからない場合は、新しいレコードとして挿入します。
    -Unique スイッチは、キーに一致するレコードが複数存在しないことを保証します。
    -Assume パラメータを使用すると、更新前のレコードの状態を検証する楽観的ロックを実行できます。
#>
    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [PSCustomObject]$SessionObject,

        [hashtable]$Data,

        [Parameter(Mandatory = $true)]
        [string[]]$KeyColumns,

        [switch]$Unique,

        [hashtable]$Assume
    )

    $columns = $SessionObject.Columns
    $records = [System.Collections.Generic.List[psobject]]::new()

    $fileStream = $null
    $reader = $null
    $writer = $null

    try {
        # ファイルロックとストリーム初期化
        $fileStream = Invoke-InternalFileLock `
            -SessionObject $SessionObject `
            -FileMode ([System.IO.FileMode]::OpenOrCreate) `
            -FileAccess ([System.IO.FileAccess]::ReadWrite)

        $reader = New-Object System.IO.StreamReader($fileStream, $SessionObject.Encoding)
        $writer = New-Object System.IO.StreamWriter($fileStream, $SessionObject.Encoding)
        $writer.AutoFlush = $true

        # 既存データのメモリへのロード
        if ($fileStream.Length -gt 0) {
            $reader.ReadLine() | Out-Null # ヘッダー行を読み飛ばす

            $parser = New-Object Microsoft.VisualBasic.FileIO.TextFieldParser($reader)
            $parser.SetDelimiters(',')
            $parser.HasFieldsEnclosedInQuotes = $true
            $parser.TrimWhiteSpace = $true

            while (-not $parser.EndOfData) {
                $values = $parser.ReadFields()
                $row = [ordered]@{}
                for ($i = 0; $i -lt $columns.Count; $i++) {
                    $value = if ($i -lt $values.Length) { $values[$i] } else { "" }
                    $row[($columns[$i]).Trim()] = $value
                }
                $records.Add([PSCustomObject]$row)
            }
        }

        # 更新/挿入レコードの準備
        $newRecordDataObject = [ordered]@{}
        foreach ($col in $columns) {
            $newRecordDataObject[$col] = "" # 全カラムを空文字で初期化
        }
        foreach ($key in $Data.Keys) {
            if ($newRecordDataObject.Contains($key)) {
                $newRecordDataObject[$key] = ($Data.$key -as [string]) # Dataの内容で上書き
            }
        }
        $newRecordData = [PSCustomObject]$newRecordDataObject

        # レコードの検索、更新、または挿入
        $matchingRecords = [System.Collections.Generic.List[psobject]]::new()
        $recordFound = $false

        for ($i = 0; $i -lt $records.Count; $i++) {
            $currentRecord = $records[$i]
            
            # --- キーの一致確認 ---
            $keyMatch = $true
            foreach ($keyCol in $KeyColumns) {
                if (-not ($currentRecord.PSObject.Properties.Name -contains $keyCol) -or $currentRecord.$keyCol -ne $Data.$keyCol) {
                    $keyMatch = $false
                    break
                }
            }

            if ($keyMatch) {
                $matchingRecords.Add($currentRecord)
                $recordFound = $true

                # --- 楽観的ロックのチェック ---
                if ($Assume) {
                    foreach ($assumeKey in $Assume.Keys) {
                        if (-not ($currentRecord.PSObject.Properties.Name -contains $assumeKey) -or $currentRecord.$assumeKey -ne $Assume.$assumeKey) {
                            throw (New-Object OptimisticLockingException("楽観的ロックのチェックに失敗しました。レコードのキー: '$($currentRecord.$KeyColumns[0])'。ファイル: $($SessionObject.FilePath)。前提条件: $($Assume | Out-String), 現在値: $($currentRecord | Out-String)。"))
                        }
                    }
                }

                # --- レコードの部分更新 ---
                foreach ($col in $columns) {
                    if (-not $Data.ContainsKey($col)) { # $Dataにないカラムは既存の値を維持
                        $newRecordData.$col = $currentRecord.$col
                    }
                }
                $records[$i] = $newRecordData # レコードを置き換え
            }
        }

        # Unique制約の検証
        if ($Unique.IsPresent -and $matchingRecords.Count -gt 1) {
            throw (New-Object DuplicateKeyException("Invoke-CsvUpsert -Unique: キー '$($KeyColumns -join ',')' に一致するレコードが複数見つかりました。ファイル: $($SessionObject.FilePath), データ: $($Data | Out-String)."))
        }

        # 新規レコードの追加
        if (-not $recordFound) {
            $records.Add($newRecordData)
        }

        # ファイルへの書き戻し
        $fileStream.SetLength(0)
        $fileStream.Seek(0, [System.IO.SeekOrigin]::Begin)
        
        # --- ヘッダーの書き込み ---
        $writer.WriteLine(($SessionObject.Columns -join ','))

        # --- データ行の書き込み ---
        $csvDataRows = $records | ConvertTo-Csv -NoTypeInformation | Select-Object -Skip 1

        foreach ($line in $csvDataRows) {
            $writer.WriteLine($line)
        }
    }
    finally {
        # リソース解放
        if ($writer) { $writer.Dispose() }
        if ($reader) { $reader.Dispose() }
        if ($fileStream) { $fileStream.Dispose() }
    }
    
    return $null
}

#endregion

# Export the public functions
Export-ModuleMember -Function New-CsvManagerSession, Get-CsvData, Invoke-CsvUpsert