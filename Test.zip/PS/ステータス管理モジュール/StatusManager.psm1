﻿<#
.SYNOPSIS
    ステータス定義および操作ルール管理モジュール。
.DESCRIPTION
    システム内のステータス値と操作許可ルールを一元管理し、シングルトンオブジェクトとして提供します。
#>

# ==============================================================================
# 1. 内部クラス定義
# ==============================================================================

<#
.SYNOPSIS
    汎用ステータス定義クラス。
.DESCRIPTION
    ステータスの「コード値」と「表示名」を保持します。
#>
class StatusItem {
    [string] $Code
    [string] $DisplayName

    StatusItem([string]$code, [string]$displayName) {
        $this.Code = $code
        $this.DisplayName = $displayName
    }

    [string] ToString() { return "[$($this.Code)] $($this.DisplayName)" }
}

<#
.SYNOPSIS
    操作ルール定義クラス。
.DESCRIPTION
    操作が許可されるステータスリストを保持し、判定ロジックを提供します。
#>
class UserAction {
    [string[]] $AllowedCodes

    UserAction([StatusItem[]]$statuses) {
        $this.AllowedCodes = $statuses.Code
    }

    # 指定されたコードが許可リストに含まれるか判定
    [bool] IsAllowed([string]$code) {
        if ([string]::IsNullOrEmpty($code)) { return $false }
        return $this.AllowedCodes -contains $code
    }
}

# ==============================================================================
# 2. インスタンス生成 (データ定義)
# ==============================================================================

# ユーザ操作ステータス (StatusItem で作成)
$OpDefs = [ordered]@{
    Idle       = [StatusItem]::new('OP-0000', '待機中')
    Inputting  = [StatusItem]::new('OP-0010', '入力中')
    Confirming = [StatusItem]::new('OP-0020', '確認中')
    Submitted  = [StatusItem]::new('OP-1000', '申請済み')
    Cancelled  = [StatusItem]::new('OP-8000', 'キャンセル')
}

# システムジョブステータス (StatusItem で作成)
$JobDefs = [ordered]@{
    None      = [StatusItem]::new('JOB-0000', '未作成')
    Queued    = [StatusItem]::new('JOB-0010', '待機中')
    Running   = [StatusItem]::new('JOB-0100', '実行中')
    Succeeded = [StatusItem]::new('JOB-1000', '正常終了')
    Failed    = [StatusItem]::new('JOB-9999', '異常終了')
}

# 操作ルール定義
$ActionDefs = [ordered]@{
    # 申請: 入力中, 確認中
    Submit = [UserAction]::new(@($OpDefs.Inputting, $OpDefs.Confirming))
    
    # キャンセル: 入力中, 確認中, 申請済み
    Cancel = [UserAction]::new(@($OpDefs.Inputting, $OpDefs.Confirming, $OpDefs.Submitted))
    
    # 再編集: 確認中
    Edit   = [UserAction]::new(@($OpDefs.Confirming))
}

# 統合オブジェクト (シングルトン)
$StatusManagerInstance = [PSCustomObject]@{
    Operation = [PSCustomObject]$OpDefs
    Job       = [PSCustomObject]$JobDefs
    Actions   = [PSCustomObject]$ActionDefs
}

# ------------------------------------------------------------------------------
# 4. 公開関数
# ------------------------------------------------------------------------------

<#
.SYNOPSIS
    ステータス管理オブジェクトを取得します。
.DESCRIPTION
    Operation, Job, Actions を含む統合オブジェクトを返します。
#>
function Get-StatusManager {
    return $StatusManagerInstance
}

Export-ModuleMember -Function Get-StatusManager
