# GitOperator VBA クラスモジュール

`GitOperator` は、Microsoft Excel VBA から Git コマンドラインツールを操作するためのラッパークラスモジュールです。これにより、VBAプロジェクト内でGitリポジトリのクローン、更新、コミット、プッシュといった操作を自動化できます。

## 目次

1.  [特徴](#1-特徴)
2.  [前提条件](#2-前提条件)
3.  [インストール](#3-インストール)
4.  [使用方法](#4-使用方法)
    *   [GitOperator クラスの設定](#gitoperator-クラスの設定)
    *   [主なメソッド](#主なメソッド)
    *   [Pull(Optional ByVal branch As String = "main")](#pulloptional-byval-branch-as-string--main)
    *   [Add(Optional ByVal filePath As String = ".")](#addoptional-byval-filepath-as-string--)
    *   [エラーハンドリング](#エラーハンドリング)
    *   [セキュリティ (Git Credential Manager)](#セキュリティ-git-credential-manager)
5.  [クラスメンバ (プロパティ/メソッド)](#5-クラスメンバ-プロパティメソッド)
6.  [注意点](#6-注意点)
7.  [ライセンス](#7-ライセンス)

## 1. 特徴

*   **Gitコマンドの抽象化**: VBAから直接 `git` コマンドを実行するための簡潔なインターフェースを提供します。
*   **一時ディレクトリ管理**: リポジトリのクローン時に一時ディレクトリを自動で作成し、クラス終了時に安全に削除します。既存のリポジトリを操作する場合は `WorkingRepoPath` プロパティを使用します。
*   **堅牢なエラーハンドリング**: Gitコマンドの標準出力、標準エラー、終了コードを捕捉し、VBAのエラー機構 (`Err.Raise`) を通じて詳細なエラー情報を提供します。
*   **タイムアウト設定**: 各Gitコマンドの実行タイムアウトをミリ秒単位で設定可能です。
*   **認証**: Gitコマンドラインツールが提供する資格情報ヘルパー（例: Git Credential Manager for Windows）を利用して認証を行います。
*   **高いメンテナンス性**: 明示的な `Me.` の使用と抽象的なコメントにより、コードの可読性と保守性を高めています。

## 2. 前提条件

本モジュールを利用するには、以下の環境が整っている必要があります。

*   **Microsoft Excel**: VBAコードを実行可能な環境。

*   **Git リポジトリ**: 操作対象のGitリポジトリへのアクセス権限。

*   **Gitのインストール**: `git.exe` が実行環境にインストールされていること。

*   **資格情報ヘルパーの設定**: Gitコマンドラインツールの認証メカニズムに対応する資格情報ヘルパーが適切に設定されていること。


## 3. インストール

1.  **VBAエディタを開く**: Excelブックを開き、`Alt + F11` を押してVBAエディタを起動します。
2.  **クラスモジュールのインポート**:
    *   `VBAProject` ツリーから任意のプロジェクト（例: `ThisWorkbook`）を選択します。
    *   「ファイル」→「ファイルのインポート」を選択し、`GitOperator.cls` ファイル（このクラスモジュールのコードを `.cls` 拡張子で保存したもの）をインポートします。
    *   または、「挿入」→「クラスモジュール」で新しいクラスモジュールを作成し、名前を `GitOperator` に変更後、提供されたコードをコピー＆ペーストします。
3.  **標準モジュールの作成**:
    *   「挿入」→「標準モジュール」で新しい標準モジュールを作成します。
    *   提供された使用例コード（`TestGitOperationsWithClassLatest` サブプロシージャなど）をコピー＆ペーストします。
4.  **Gitのインストール**: まだPCにGitがインストールされていない場合は、[Git公式ウェブサイト](https://git-scm.com/downloads) からダウンロードしてインストールしてください。

## 4. 使用方法

### GitOperator クラスの設定

標準モジュールや他のプロシージャから `GitOperator` クラスをインスタンス化し、必要なプロパティを設定します。

```vba
Dim gitOp As GitOperator
Set gitOp = New GitOperator

' Git実行ファイルのパスを設定 (例: C:\Program Files\Git\bin\git.exe)
gitOp.GitPath = "C:\Program Files\Git\bin\git.exe"

' GitLabリポジトリのURLを設定 (クローンまたはプッシュする場合に必要)
gitOp.GitLabRepoUrl = "https://gitlab.com/your_group/your_repo.git"

' 既存のリポジトリを操作する場合、そのパスを設定
' gitOp.WorkingRepoPath = "C:\path\to\your\existing\repo"

' コマンドのタイムアウトを設定 (ミリ秒単位、デフォルトは300000ms = 5分)
' gitOp.CommandTimeoutMs = 600000 ' 10分に設定する場合
```

### 主なメソッド

| メソッド名          | 説明                                                                                                 |
| :------------------ | :--------------------------------------------------------------------------------------------------- |
| `Clone(branch, Optional destinationPath)` | リモートリポジトリをローカルの一時ディレクトリ、または指定された `destinationPath` にクローンします。クローンされたリポジリのパスを返します。失敗した場合はエラーを発生させます。`destinationPath` が指定され、かつそのパスが空でない場合はエラーとなります。`destinationPath` が指定されない場合、クラス内部の一時ディレクトリは常にクリーンアップされ、リポジトリが再クローンされます。|
| `Pull(branch)`      | ローカルリポジリをリモートの最新の状態にプルします。成功時はエラーを発生しません。                 |
| `Add(filePath)`     | 指定されたファイル（またはすべての変更）をステージングエリアに追加します。成功時はエラーを発生しません。|
| `Commit(message)`   | ステージングされた変更をコミットします。成功時はエラーを発生しません。                               |
| `Push(branch)`      | コミットされた変更をリモートリポジリにプッシュします。成功時はエラーを発生しません。               |

### エラーハンドリング

すべてのパブリックメソッドは、Gitコマンドの実行に失敗した場合にVBAのエラー (`Err.Raise`) を発生させます。呼び出し元のコードでは `On Error GoTo` を使用してエラーを捕捉し、`Err.Description` に含まれる詳細な情報（Gitの標準エラー出力など）を利用して適切な処理を行うことができます。

```vba
On Error GoTo ErrorHandler

' Git操作コード

CleanUp:
    Set gitOp = Nothing ' クラスインスタンスを解放し、一時ディレクトリを自動削除
    Exit Call

ErrorHandler:
    MsgBox "エラーが発生しました: " & Err.Description & vbCrLf & _
           "終了コード: " & gitOp.LastExitCode, vbCritical
    Resume CleanUp
```

### セキュリティ (Git Credential Manager)

`GitOperator` は、Gitコマンドラインツールが提供する資格情報ヘルパー（例: Git Credential Manager for Windows）を利用することを強く推奨します。これにより、VBAコード内でPersonal Access Token (PAT) を直接扱う必要がなくなり、セキュリティが大幅に向上します。

*   **Git Credential Manager for Windows の利用**: 最も安全な方法です。Gitクライアント側に設定することで、VBAコードがPATを直接扱う必要がなくなります。一度認証情報を保存すれば、以降のGit操作は自動的に認証されます。
*   **PATの直接利用はサポートされていません**: 以前のバージョンでサポートされていた `GitLabPat` プロパティは削除されました。PATを直接コードに埋め込んだり、外部ファイルから読み込んだりする方法はセキュリティリスクが高いため、資格情報ヘルパーの利用を強く推奨します。

## 5. クラスメンバ (プロパティ/メソッド)

### プロパティ

*   `GitPath As String`: Git実行ファイルのフルパス。
*   `GitLabRepoUrl As String`: 操作対象のGitLabリポジトリのHTTPS URL。
*   `WorkingRepoPath As String`: 既存のGitリポジトリのパス。このプロパティを設定すると、`Pull`, `Add`, `Commit`, `Push` メソッドは、`LocalRepoPath` よりもこのパスを優先して操作対象とします。
*   `LocalRepoPath As String` (Read-only): クローンされたローカルリポジトリの一時パス。
*   `CommandTimeoutMs As Long`: Gitコマンド実行のタイムアウト時間（ミリ秒）。デフォルトは300000ms (5分)。
*   `LastStandardOutput As String` (Read-only): 最後に実行されたGitコマンドの標準出力。
*   `LastStandardError As String` (Read-only): 最後に実行されたGitコマンドの標準エラー出力。
*   `LastExitCode As Long` (Read-only): 最後に実行されたGitコマンドの終了コード。

### メソッド

*   `Clone(Optional ByVal branch As String = "main", Optional ByVal destinationPath As String = "") As String`: リポジトリをクローン。成功した場合、クローンされたリポジトリのパスを返します。
*   `Pull(Optional ByVal branch As String = "main")`: リポジトリをプル。
*   `Add(Optional ByVal filePath As String = ".")`: ファイルをステージング。
*   `Commit(ByVal message As String)`: 変更をコミット。
*   `Push(Optional ByVal branch As String = "main")`: 変更をプッシュ。

## 6. 注意点
*   **Gitのパス指定**: `git.exe` へのパスがシステムの環境変数 (PATH) に通っていない場合は、`GitPath` プロパティにそのフルパスを設定する必要があります。
*   **`WScript.Shell.Exec` の依存**: コマンドの実行には `WScript.Shell` オブジェクトの `Exec` メソッドを使用しています。この機能がブロックされている環境では動作しません。
*   **一時ディレクトリの利用**: リポジリのクローンは一時ディレクトリ (`%TEMP%` 以下) に行われます。十分なディスクスペースがあることを確認してください。また、クラスインスタンスの解放 (`Set gitOp = Nothing`) が適切に行われない場合、一時ディレクトリが残り続ける可能性があります。
*   **WorkingRepoPath の利用**: `WorkingRepoPath` プロパティを設定した場合、Git操作はそのパスに対して行われます。このパスは既存のGitリポジトリである必要があります。
*   **WorkingRepoPath と一時ディレクトリの切り替え**: `WorkingRepoPath` プロパティを設定すると、`Pull`, `Add`, `Commit`, `Push` メソッドはそのパスを優先して使用します。`WorkingRepoPath` を空白 (`""`) に設定し直すと、これらのメソッドは自動的に `LocalRepoPath` (初期化時に作成される一時ディレクトリ) を操作対象とします。これにより、既存のリポジトリと一時クローンリポジトリの間で柔軟に作業対象を切り替えることができます。
*   **競合解決の制限**: Gitの `pull` や `push` 実行時にリモートリポジトリとの競合 (コンフリクト) が発生した場合、本モジュールは自動的な解決機能を提供しません。エラーが返され、手動での解決が必要となります。

## 7. ライセンス

このモジュールは自由に利用、変更、配布いただけます。
