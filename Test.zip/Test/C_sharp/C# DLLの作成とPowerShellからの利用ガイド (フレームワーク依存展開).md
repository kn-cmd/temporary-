
## C# DLLの作成とPowerShellからの利用ガイド (フレームワーク依存展開)

### 概要

このガイドでは、C#で作成したクラスライブラリ（DLL）をWindows環境でPowerShellから利用する方法を解説します。特に、`csc.exe` コマンドラインツールを使ってDLLをコンパイルし、そのDLLがシステムにインストールされている.NET Frameworkに依存する「フレームワーク依存展開 (Framework-dependent deployment)」のアプローチを取ります。DLLは引数を受け取り、現在の実行日時と合わせてJSON形式の文字列として返します。

### 前提 (Prerequisites)

この手順を進めるためには、以下の環境が整っている必要があります。

*   **Windows オペレーティングシステム:** Windows 7以降のバージョンを想定しています。
*   **.NET Frameworkのインストール:** Windows環境に`.NET Framework 4.x`（例: 4.0, 4.5, 4.8など）がインストールされていること。これは多くのWindows環境で標準的にインストールされています。PowerShellもこのフレームワーク上で動作します。
*   **PowerShell:** Windowsに標準で搭載されているPowerShell（バージョン5.1以降を推奨）が利用可能であること。
*   **`csc.exe` と `System.Web.Extensions.dll`:**
    *   `csc.exe` (C#コンパイラ) は、`.NET Framework` のインストールディレクトリ（例: `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\`）内に存在します。
    *   `System.Web.Extensions.dll` (JSONシリアライザを含む) も、通常同じディレクトリまたはGAC (Global Assembly Cache) 内に存在します。

### 目的 (Purpose)

このアプローチを取る主な目的は以下の通りです。

1.  **既存のC#ロジックの再利用:** 複雑なデータ処理、特定のアルゴリズム、または外部APIとの連携など、C#で実装された強力なビジネスロジックをPowerShellスクリプトから簡単に呼び出して利用すること。
2.  **パフォーマンスの向上:** PowerShellスクリプトだけでは処理速度が不足する場合、ボトルネックとなる部分をコンパイル済みのC# DLLにオフロードし、パフォーマンスを向上させること。
3.  **機密性の高いロジックの隠蔽:** PowerShellスクリプトの一部をバイナリ形式のDLLにすることで、ソースコードを直接読まれることを難しくし、ロジックの解析難易度を上げること（ただし、完全な難読化や解析不可能化は困難です）。
4.  **構造化された出力の受け渡し:** C#側で生成した複雑なデータ構造をJSON形式で標準出力に返し、PowerShell側でそれをオブジェクトとして容易に解析・利用すること。
5.  **配布と管理の簡素化:** 特に.NET Framework環境では、DLLが小さく、ランタイムがOSに組み込まれているか、広く普及しているため、配布が比較的容易です。

### 手順

---

#### **ステップ1: C#ソースコードの作成 (`MyJsonProcessor.cs`)**

`MyJsonProcessor.cs`という名前で以下のC#コードファイルを作成します。このコードは、引数で受け取った文字列と現在の実行日時を格納した匿名オブジェクトをJSON形式にシリアライズして返します。

```csharp
using System;
using System.Web.Script.Serialization; // JSONシリアライザのために System.Web.Extensions.dll を参照します

namespace MyProcessor
{
    /// <summary>
    /// 指定された入力値と現在の実行日時を含むJSON文字列を生成するクラスです。
    /// </summary>
    public class JsonGenerator
    {
        /// <summary>
        /// 入力値とDLLが実行された日時を含むJSON文字列を返します。
        /// </summary>
        /// <param name="input">処理する文字列データ。</param>
        /// <returns>入力値と実行日時、ステータスを含むJSON文字列。</returns>
        public string GetProcessedJson(string input)
        {
            // 結果を格納するための匿名オブジェクトを作成
            var resultObject = new
            {
                Input = input,
                ExecutionDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), // 日付時刻を任意のフォーマットで文字列化
                Status = "Success"
            };

            // JavaScriptSerializer を使用してオブジェクトをJSON文字列にシリアライズします。
            // JavaScriptSerializer は .NET Framework 3.5 以降で利用可能です。
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(resultObject);
        }
    }
}
```

**コードの解説:**
*   `System.Web.Script.Serialization.JavaScriptSerializer`: このクラスは、.NET Frameworkで利用可能なJSONシリアライザです。使用するには、`System.Web.Extensions.dll` への参照が必要です。
*   `DateTime.Now.ToString(...)`: 現在の日付と時刻を指定されたフォーマットで文字列に変換しています。
*   匿名オブジェクト: `new { ... }` 構文で、一時的にデータを保持するオブジェクトを定義しています。

---

#### **ステップ2: DLLのコンパイル (csc.exe を使用)**

`MyJsonProcessor.cs` ファイルをDLLとしてコンパイルします。この際、`csc.exe` に特定のオプションと参照DLLのパスを指定します。

1.  **`csc.exe` と `System.Web.Extensions.dll` のパスを確認:**
    これらのファイルは、通常、以下のいずれかのパスにあります（あなたの環境の.NET FrameworkのバージョンやOSのビット数によって異なります）。

    *   **64ビットOSの場合の一般的なパス:** `C:\Windows\Microsoft.NET\Framework64\v4.0.30319\`
    *   **32ビットOSの場合の一般的なパス:** `C:\Windows\Microsoft.NET\Framework\v4.0.30319\`
    （`v4.0.30319` は.NET Framework 4.0以降のバージョンを示すことが多いです。より新しいバージョンのディレクトリが存在すれば、それを使用しても構いません。）

2.  **コマンドプロンプトまたはPowerShellを開く:**
    `MyJsonProcessor.cs` ファイルを保存したディレクトリに移動し、そこでコマンドプロンプトまたはPowerShellを開きます。

3.  **DLLをコンパイルするコマンドを実行:**
    以下のコマンドを実行してDLLをコンパイルします。**`$cscPath` と `$webExtensionsDllPath` は、あなたの環境に合わせて正確に調整してください。**

    ```powershell
    # --- 環境に合わせてパスを調整してください ---
    # csc.exe のフルパス
    $cscPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
    # System.Web.Extensions.dll のフルパス (csc.exeと同じディレクトリにあることが多い)
    $webExtensionsDllPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\System.Web.Extensions.dll"
    # --------------------------------------------

    # DLLをコンパイルするコマンド
    # `&` 演算子は、変数に格納された外部コマンドをPowerShellで実行するために使用します。
    & $cscPath /target:library /reference:$webExtensionsDllPath MyJsonProcessor.cs
    ```

    *   `/target:library` (または `/t:library`): コンパイルの結果として実行可能ファイル (`.exe`) ではなく、クラスライブラリ (`.dll`) を生成することを指定します。
    *   `/reference:$webExtensionsDllPath`: `MyJsonProcessor.cs` のコードが `System.Web.Extensions.dll` 内のクラス（`JavaScriptSerializer`）を使用しているため、そのDLLを参照としてコンパイラに指定します。これにより、`MyJsonProcessor.dll` のマニフェストに`System.Web.Extensions.dll` への依存関係が記録されます。
    *   `MyJsonProcessor.cs`: コンパイル対象のC#ソースファイルです。

    コンパイルが成功すると、`MyJsonProcessor.dll` というファイルが現在のディレクトリに生成されます。

---

#### **ステップ3: PowerShellスクリプトの作成と実行**

以下の内容のPowerShellスクリプト（例: `TestProcessor.ps1`）を作成します。このスクリプトは、コンパイルしたDLLをロードし、その中のクラスをインスタンス化してメソッドを呼び出し、返されたJSON文字列をPowerShellオブジェクトとして利用します。

```powershell
# --- DLLファイルのパスを指定 ---
# この例では MyJsonProcessor.dll が TestProcessor.ps1 と同じディレクトリにあると仮定しています。
# 実際には、DLLの配置場所に合わせてパスを調整してください。
$dllDirectory = Split-Path $MyInvocation.MyCommand.Definition
$dllPath = Join-Path $dllDirectory "MyJsonProcessor.dll"
# -----------------------------

Write-Host "C# DLLのロードを試行中..."

# DLLをPowerShellの現在のセッションにロードします。
# Add-Type コマンドレットは、アセンブリをロードし、その中の型を利用できるようにします。
try {
    Add-Type -LiteralPath $dllPath
    Write-Host "DLL '$dllPath' が正常にロードされました。"
}
catch {
    Write-Error "DLLのロード中にエラーが発生しました: $($_.Exception.Message)"
    Write-Error "DLLのパス: $dllPath"
    Write-Error "エラーの詳細: $($_.Exception | Format-List -Force | Out-String)"
    exit 1
}

# DLL内の MyProcessor.JsonGenerator クラスのインスタンスを作成します。
# New-Object コマンドレットは、.NETオブジェクトの新しいインスタンスを作成するために使用されます。
$jsonGenerator = New-Object MyProcessor.JsonGenerator

# DLLのメソッドに渡す入力文字列を定義します。
$inputString = "PowerShellからDLLへ送る重要なデータ"

Write-Host "`nDLLメソッドの呼び出し中..."

# DLLの GetProcessedJson メソッドを呼び出し、JSON文字列の結果を受け取ります。
try {
    $jsonResult = $jsonGenerator.GetProcessedJson($inputString)
    Write-Host "`n--- DLLからの生のJSON出力 ---"
    Write-Host $jsonResult
}
catch {
    Write-Error "DLLメソッドの呼び出し中にエラーが発生しました: $($_.Exception.Message)"
    Write-Error "エラーの詳細: $($_.Exception | Format-List -Force | Out-String)"
    exit 1
}

# 受け取ったJSON文字列をPowerShellオブジェクトに変換します。
# ConvertFrom-Json コマンドレットは、JSON形式の文字列をPowerShellのカスタムオブジェクトに変換します。
try {
    $jsonObject = $jsonResult | ConvertFrom-Json
    Write-Host "`n--- PowerShellオブジェクトに変換後 ---"
    $jsonObject | Format-List # 変換されたオブジェクトを見やすく表示
}
catch {
    Write-Error "JSONの解析中にエラーが発生しました。生のJSONデータが不正である可能性があります。"
    Write-Error "生のJSON出力: $jsonResult"
    Write-Error "エラーメッセージ: $($_.Exception.Message)"
    exit 1
}

# 変換されたPowerShellオブジェクトのプロパティにアクセスする例
Write-Host "`n--- オブジェクトプロパティへのアクセス ---"
Write-Host "入力された値: $($jsonObject.Input)"
Write-Host "実行日時: $($jsonObject.ExecutionDateTime)"
Write-Host "ステータス: $($jsonObject.Status)"

Write-Host "`nC# DLLとの連携処理が完了しました。"
```

4.  **PowerShellスクリプトの実行:**
    `TestProcessor.ps1` を保存したディレクトリでPowerShellを開き、以下のコマンドを実行します。

    ```powershell
    .\TestProcessor.ps1
    ```

**期待される出力例:**

```
C# DLLのロードを試行中...
DLL 'C:\Path\To\Your\DLL\MyJsonProcessor.dll' が正常にロードされました。

DLLメソッドの呼び出し中...

--- DLLからの生のJSON出力 ---
{"Input":"PowerShellからDLLへ送る重要なデータ","ExecutionDateTime":"2025-09-26 14:35:12","Status":"Success"}

--- PowerShellオブジェクトに変換後 ---

Input           : PowerShellからDLLへ送る重要なデータ
ExecutionDateTime : 2025-09-26 14:35:12
Status          : Success

--- オブジェクトプロパティへのアクセス ---
入力された値: PowerShellからDLLへ送る重要なデータ
実行日時: 2025-09-26 14:35:12
ステータス: Success

C# DLLとの連携処理が完了しました。
```
（日付と時刻は実行時に応じて変化します）

### 補足情報 (Additional Notes)

#### 1. `&` (呼び出し演算子) について

PowerShellスクリプトのコマンドの先頭にある `&` は、**「呼び出し演算子 (Call operator)」**です。これは、変数に格納されたコマンドのパスや名前を、PowerShellに「実行すべきコマンド」として認識させるために使用されます。今回の例では、`$cscPath` に`csc.exe`のフルパスが格納されているため、`& $cscPath` とすることで `csc.exe` を正しく実行できます。

#### 2. DLLの内容 (`System.Web.Script.Serialization.JavaScriptSerializer` との関連)

あなたが作成する `MyJsonProcessor.dll` に、`System.Web.Script.Serialization.JavaScriptSerializer` の**実装コードが直接含まれるわけではありません**。`MyJsonProcessor.dll` の内部には、`System.Web.Extensions.dll` への**依存関係の情報（メタデータ）**が記録されます。

実行時、PowerShellが `MyJsonProcessor.dll` をロードし、`JavaScriptSerializer` クラスを使用しようとすると、.NETランタイムはその依存関係情報に基づいて、システムにインストールされている`System.Web.Extensions.dll` を探し、そこから `JavaScriptSerializer` の機能を利用します。このため、**DLLが動作するためには、参照している `System.Web.Extensions.dll` と適切なバージョンの.NET Frameworkが環境に存在している必要があります。**これが「フレームワーク依存展開」の特徴です。

#### 3. 32ビットOS/64ビットOSでの動作 (Any CPU)

`csc.exe` でDLLをコンパイルする際、特に指定がなければデフォルトで**「Any CPU」**としてコンパイルされます。これは、DLLの内部コードがCPUアーキテクチャに依存しない中間言語 (IL) で記述されることを意味します。

*   DLLが32ビットプロセス（例: 32ビットOS上のPowerShell、または64ビットOS上の32ビットPowerShell）によってロードされた場合、.NETランタイムのJIT (Just-In-Time) コンパイラがILを32ビットのネイティブコードに変換して実行します。
*   DLLが64ビットプロセス（例: 64ビットOS上の64ビットPowerShell）によってロードされた場合、JITコンパイラがILを64ビットのネイティブコードに変換して実行します。

したがって、**特別な理由（P/Invokeで特定のアーキテクチャのネイティブDLLを呼び出すなど）がない限り、この手順で作成されたDLLは、32ビットOSと64ビットOSのどちらのPowerShell環境でも動作します。**

#### 4. エラーハンドリング

本資料のPowerShellスクリプトには`try-catch`ブロックが含まれており、DLLのロード失敗、メソッド呼び出し時のエラー、JSON解析エラーなど、さまざまな段階での問題に対応できるようにしています。実運用では、これらのエラーメッセージを適切にログに記録したり、ユーザーに分かりやすく通知したりするロジックをさらに追加することが重要です。

#### 5. モダンな.NET (Core / 5以降) との比較

このガイドでは、`csc.exe` の直接利用と`.NET Framework` の `System.Web.Extensions.dll` を使用しましたが、現代のC#開発では通常、`.NET (Core / 5以降)` をターゲットとし、`dotnet CLI` (`dotnet new classlib` と `dotnet build`) を使用してDLLをビルドするのが推奨されます。

*   モダンな.NETでは、JSONシリアライズには `System.Text.Json` が標準で組み込まれており、外部の参照DLL (`System.Web.Extensions.dll`) は不要です。
*   モダンな.NET Framework依存展開DLLは、実行される環境に、ターゲットとするバージョンの.NETランタイムがインストールされている必要があります。

---