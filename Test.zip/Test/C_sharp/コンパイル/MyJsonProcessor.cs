using System;
using System.Web.Script.Serialization; // この名前空間は System.Web.Extensions.dll に含まれます。

namespace MyProcessor
{
    public class JsonGenerator
    {
        /// <summary>
        /// 指定された入力値と現在の実行日時を含むJSON文字列を返します。
        /// </summary>
        /// <param name="input">処理する入力文字列。</param>
        /// <returns>入力値と実行日時を含むJSON文字列。</returns>
        public string GetProcessedJson(string input)
        {
            // 結果を格納する匿名オブジェクトを作成
            var resultObject = new
            {
                Input = input,
                ExecutionDateTime = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss"), // 日付時刻を文字列としてフォーマット
                Status = "Success"
            };

            // JavaScriptSerializer を使用してオブジェクトをJSON文字列にシリアライズ
            // JavaScriptSerializer は .NET Framework 3.5 以降で利用可能です。
            JavaScriptSerializer serializer = new JavaScriptSerializer();
            return serializer.Serialize(resultObject);
        }
    }
}